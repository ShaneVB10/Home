import os

os.environ.setdefault("TOURNAMENT_HTTPS", "1")
from server import create_app

application = create_app()

