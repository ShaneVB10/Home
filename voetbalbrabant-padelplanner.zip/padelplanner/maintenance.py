import argparse
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def package(output):
    output = Path(output).resolve()
    files = [ROOT / name for name in ("server.py", "wsgi.py", "maintenance.py", "requirements.txt", "README.md")]
    for folder in ("templates", "static", "tests"):
        files.extend(path for path in (ROOT / folder).rglob("*") if path.is_file() and "__pycache__" not in path.parts)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "x", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, Path("padelplanner") / path.relative_to(ROOT))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    package(args.output)
    print("Installatiepakket gemaakt zonder accounts of toernooidata.")

