import tempfile
import unittest
from werkzeug.security import generate_password_hash

from server import create_app


class TournamentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.app = create_app(self.temp.name, testing=True)
        self.client = self.app.test_client()
        with self.app.app_context():
            self.app.db().execute("INSERT INTO users(username,password) VALUES (?,?)", ("shane", generate_password_hash("test-password-2026")))
            self.app.db().commit()

    def tearDown(self):
        self.temp.cleanup()

    def login(self):
        response = self.client.post("/login", data={"username":"shane", "password":"test-password-2026"})
        self.assertEqual(response.status_code, 302)
        with self.client.session_transaction() as session:
            self.csrf = session["csrf"]

    def post(self, path, data):
        return self.client.post(path, data={"csrf":self.csrf, **data})

    def tournament(self):
        response = self.post("/admin/toernooi", {"name":"Brabantse Padelcup", "event_date":"2027-06-12", "location":"Breda", "group_count":"2", "fields":"2", "match_minutes":"30", "break_minutes":"5", "start_time":"10:00"})
        self.assertEqual(response.status_code, 302)
        return int(response.headers["Location"].rstrip("/").split("/")[-1])

    def add_teams(self, key):
        for index, club in enumerate(("SV Terheijden 1", "Baronie", "JEKA", "Unitas'30"), 1):
            response = self.post(f"/admin/toernooi/{key}/team", {"name":club, "player_one":f"Speler {index}A", "player_two":f"Speler {index}B", "contact":f"club{index}@example.test"})
            self.assertEqual(response.status_code, 302)

    def test_private_admin_and_csrf(self):
        self.assertEqual(self.client.get("/admin").status_code, 302)
        self.login()
        self.assertEqual(self.client.get("/admin").status_code, 200)
        self.assertEqual(self.client.post("/admin/toernooi", data={}).status_code, 403)

    def test_generate_schedule_results_standings_and_publish(self):
        self.login(); key = self.tournament(); self.add_teams(key)
        response = self.post(f"/admin/toernooi/{key}/genereren", {})
        self.assertEqual(response.status_code, 302)
        with self.app.app_context():
            db = self.app.db()
            self.assertEqual(db.execute("SELECT COUNT(*) FROM groups").fetchone()[0], 2)
            self.assertEqual(db.execute("SELECT COUNT(*) FROM matches").fetchone()[0], 2)
            match = db.execute("SELECT * FROM matches ORDER BY id LIMIT 1").fetchone()
            match_id = match["id"]
            kickoff = match["kickoff"]
        self.assertEqual(kickoff, "2027-06-12T10:00")
        response = self.post(f"/admin/wedstrijd/{match_id}/uitslag", {"set1_home":"6", "set1_away":"4", "set2_home":"6", "set2_away":"3", "set3_home":"", "set3_away":""})
        self.assertEqual(response.status_code, 302)
        with self.app.app_context():
            match = self.app.db().execute("SELECT * FROM matches WHERE id=?", (match_id,)).fetchone()
            self.assertEqual((match["score_home"], match["score_away"], match["note"]), (2,0,"6-4, 6-3"))
        self.client.post("/logout", data={"csrf":self.csrf})
        self.assertEqual(self.client.get(f"/toernooi/{key}").status_code, 404)
        self.login()
        self.post(f"/admin/toernooi/{key}/publiceren", {})
        self.client.post("/logout", data={"csrf":self.csrf})
        page = self.client.get(f"/toernooi/{key}")
        self.assertEqual(page.status_code, 200)
        html = page.get_data(as_text=True)
        self.assertIn("SV Terheijden 1", html)
        self.assertIn("6-4, 6-3", html)
        self.assertNotIn("club1@example.test", html)

    def test_invalid_set_and_no_regeneration_after_result(self):
        self.login(); key = self.tournament(); self.add_teams(key); self.post(f"/admin/toernooi/{key}/genereren", {})
        with self.app.app_context():
            match_id = self.app.db().execute("SELECT id FROM matches LIMIT 1").fetchone()[0]
        self.post(f"/admin/wedstrijd/{match_id}/uitslag", {"set1_home":"6", "set1_away":"6"})
        with self.app.app_context():
            self.assertIsNone(self.app.db().execute("SELECT score_home FROM matches WHERE id=?", (match_id,)).fetchone()[0])
        self.post(f"/admin/wedstrijd/{match_id}/uitslag", {"set1_home":"6", "set1_away":"2"})
        before = self.client.get(f"/admin/toernooi/{key}").get_data(as_text=True)
        self.post(f"/admin/toernooi/{key}/genereren", {})
        after = self.client.get(f"/admin/toernooi/{key}").get_data(as_text=True)
        self.assertIn("Het schema kan niet opnieuw", after)
        self.assertIn('value="6"', before)
        self.assertIn('value="2"', before)


if __name__ == "__main__":
    unittest.main()
