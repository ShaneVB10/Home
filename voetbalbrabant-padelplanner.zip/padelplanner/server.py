"""Padel tournament planner for VoetbalBrabant with a private admin area."""
import argparse
import functools
import os
import secrets
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash


def create_app(data_dir=None, testing=False):
    app = Flask(__name__)
    root = Path(data_dir or os.environ.get("TOURNAMENT_DATA", Path(__file__).parent / "data"))
    root.mkdir(parents=True, exist_ok=True)
    app.config.update(
        DATABASE=root / "tournaments.db",
        SECRET_KEY=os.environ.get("TOURNAMENT_SECRET", secrets.token_hex(32)),
        TESTING=testing,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("TOURNAMENT_HTTPS") == "1",
    )

    def db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys=ON")
        return g.db

    @app.teardown_appcontext
    def close(_error=None):
        connection = g.pop("db", None)
        if connection:
            connection.close()

    with app.app_context():
        db().executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, password TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tournaments(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, event_date TEXT NOT NULL, location TEXT NOT NULL,
          group_count INTEGER NOT NULL, fields INTEGER NOT NULL, match_minutes INTEGER NOT NULL,
          break_minutes INTEGER NOT NULL, start_time TEXT NOT NULL, points_win INTEGER NOT NULL DEFAULT 3,
          points_draw INTEGER NOT NULL DEFAULT 1, published INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS teams(
          id INTEGER PRIMARY KEY, tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
          name TEXT NOT NULL, player_one TEXT NOT NULL, player_two TEXT NOT NULL,
          contact TEXT NOT NULL DEFAULT '', seed INTEGER NOT NULL DEFAULT 0,
          UNIQUE(tournament_id,name));
        CREATE TABLE IF NOT EXISTS groups(
          id INTEGER PRIMARY KEY, tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
          name TEXT NOT NULL, position INTEGER NOT NULL, UNIQUE(tournament_id,name));
        CREATE TABLE IF NOT EXISTS group_teams(
          group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
          team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
          PRIMARY KEY(group_id,team_id), UNIQUE(team_id));
        CREATE TABLE IF NOT EXISTS matches(
          id INTEGER PRIMARY KEY, tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
          group_id INTEGER REFERENCES groups(id) ON DELETE CASCADE, stage TEXT NOT NULL DEFAULT 'poule',
          round_no INTEGER NOT NULL DEFAULT 1, home_id INTEGER REFERENCES teams(id), away_id INTEGER REFERENCES teams(id),
          kickoff TEXT NOT NULL, field_no INTEGER NOT NULL, score_home INTEGER, score_away INTEGER,
          set1_home INTEGER, set1_away INTEGER, set2_home INTEGER, set2_away INTEGER,
          set3_home INTEGER, set3_away INTEGER, note TEXT NOT NULL DEFAULT '',
          CHECK(score_home IS NULL OR score_home>=0),
          CHECK(score_away IS NULL OR score_away>=0));
        """)
        db().commit()

    app.db = db

    @app.before_request
    def current_user():
        g.user = None
        if session.get("user_id"):
            g.user = db().execute("SELECT id,username FROM users WHERE id=?", (session["user_id"],)).fetchone()

    @app.after_request
    def security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        if request.path.startswith("/admin"):
            response.headers["Cache-Control"] = "no-store"
        return response

    def csrf():
        token = session.setdefault("csrf", secrets.token_urlsafe(24))
        return token

    app.jinja_env.globals["csrf_token"] = csrf

    def admin_required(fn):
        @functools.wraps(fn)
        def wrapped(*args, **kwargs):
            if not g.user:
                return redirect(url_for("login", next=request.path))
            if request.method == "POST" and not secrets.compare_digest(request.form.get("csrf", ""), session.get("csrf", "")):
                abort(403)
            return fn(*args, **kwargs)
        return wrapped

    def tournament(key):
        row = db().execute("SELECT * FROM tournaments WHERE id=?", (key,)).fetchone()
        if not row:
            abort(404)
        return row

    def standings(group_id, config):
        teams = [dict(r) for r in db().execute("""
          SELECT t.id,t.name FROM teams t JOIN group_teams gt ON gt.team_id=t.id
          WHERE gt.group_id=? ORDER BY t.name""", (group_id,))]
        table = {t["id"]: dict(**t, played=0, won=0, drawn=0, lost=0, sf=0, sa=0, games_for=0, games_against=0, points=0) for t in teams}
        for match in db().execute("SELECT * FROM matches WHERE group_id=? AND score_home IS NOT NULL AND score_away IS NOT NULL", (group_id,)):
            home, away = table.get(match["home_id"]), table.get(match["away_id"])
            if not home or not away:
                continue
            home["played"] += 1; away["played"] += 1
            home["sf"] += match["score_home"]; home["sa"] += match["score_away"]
            away["sf"] += match["score_away"]; away["sa"] += match["score_home"]
            for number in (1, 2, 3):
                hg, ag = match[f"set{number}_home"], match[f"set{number}_away"]
                if hg is not None and ag is not None:
                    home["games_for"] += hg; home["games_against"] += ag
                    away["games_for"] += ag; away["games_against"] += hg
            if match["score_home"] > match["score_away"]:
                home["won"] += 1; away["lost"] += 1; home["points"] += config["points_win"]
            elif match["score_home"] < match["score_away"]:
                away["won"] += 1; home["lost"] += 1; away["points"] += config["points_win"]
            else:
                home["drawn"] += 1; away["drawn"] += 1
                home["points"] += config["points_draw"]; away["points"] += config["points_draw"]
        rows = list(table.values())
        for row in rows:
            row["sd"] = row["sf"] - row["sa"]
            row["game_difference"] = row["games_for"] - row["games_against"]
        rows.sort(key=lambda r: (-r["points"], -r["sd"], -r["game_difference"], -r["games_for"], r["name"].casefold()))
        return rows

    def tournament_data(key, require_published=False):
        item = tournament(key)
        if require_published and not item["published"] and not g.user:
            abort(404)
        groups = []
        for group in db().execute("SELECT * FROM groups WHERE tournament_id=? ORDER BY position", (key,)):
            group = dict(group)
            group["standings"] = standings(group["id"], item)
            group["matches"] = [dict(r) for r in db().execute("""
              SELECT m.*,h.name home_name,a.name away_name FROM matches m
              LEFT JOIN teams h ON h.id=m.home_id LEFT JOIN teams a ON a.id=m.away_id
              WHERE m.group_id=? ORDER BY m.kickoff,m.field_no,m.id""", (group["id"],))]
            groups.append(group)
        matches = [dict(r) for r in db().execute("""
          SELECT m.*,h.name home_name,a.name away_name,g.name group_name FROM matches m
          LEFT JOIN teams h ON h.id=m.home_id LEFT JOIN teams a ON a.id=m.away_id
          LEFT JOIN groups g ON g.id=m.group_id WHERE m.tournament_id=?
          ORDER BY m.kickoff,m.field_no,m.id""", (key,))]
        teams = [dict(r) for r in db().execute("SELECT * FROM teams WHERE tournament_id=? ORDER BY seed,name", (key,))]
        return item, groups, matches, teams

    @app.get("/")
    def index():
        rows = db().execute("SELECT * FROM tournaments WHERE published=1 OR ? ORDER BY event_date DESC,created DESC", (bool(g.user),)).fetchall()
        return render_template("index.html", tournaments=rows)

    @app.get("/toernooi/<int:key>")
    def public_tournament(key):
        item, groups, matches, teams = tournament_data(key, True)
        return render_template("tournament.html", tournament=item, groups=groups, matches=matches, teams=teams)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            row = db().execute("SELECT * FROM users WHERE username=?", (request.form.get("username", "").strip(),)).fetchone()
            if row and check_password_hash(row["password"], request.form.get("password", "")):
                session.clear(); session["user_id"] = row["id"]; session["csrf"] = secrets.token_urlsafe(24)
                destination = request.args.get("next", "")
                return redirect(destination if destination.startswith("/") and not destination.startswith("//") else url_for("admin"))
            flash("Gebruikersnaam of wachtwoord klopt niet.", "error")
        return render_template("login.html")

    @app.post("/logout")
    @admin_required
    def logout():
        session.clear()
        return redirect(url_for("index"))

    @app.get("/admin")
    @admin_required
    def admin():
        rows = db().execute("SELECT t.*,(SELECT COUNT(*) FROM teams WHERE tournament_id=t.id) team_count,(SELECT COUNT(*) FROM matches WHERE tournament_id=t.id) match_count FROM tournaments t ORDER BY event_date DESC").fetchall()
        return render_template("admin.html", tournaments=rows)

    @app.post("/admin/toernooi")
    @admin_required
    def create_tournament():
        try:
            name = request.form["name"].strip()
            event_date = datetime.strptime(request.form["event_date"], "%Y-%m-%d").date().isoformat()
            datetime.strptime(request.form["start_time"], "%H:%M")
            values = (name, event_date, request.form.get("location", "").strip(), int(request.form["group_count"]),
                      int(request.form["fields"]), int(request.form["match_minutes"]), int(request.form["break_minutes"]), request.form["start_time"])
            if not name or not 1 <= values[3] <= 16 or not 1 <= values[4] <= 20 or not 5 <= values[5] <= 120 or not 0 <= values[6] <= 60:
                raise ValueError
        except (KeyError, ValueError):
            flash("Controleer de toernooigegevens.", "error")
            return redirect(url_for("admin"))
        key = db().execute("INSERT INTO tournaments(name,event_date,location,group_count,fields,match_minutes,break_minutes,start_time,created) VALUES (?,?,?,?,?,?,?,?,strftime('%s','now'))", values).lastrowid
        db().commit()
        return redirect(url_for("manage_tournament", key=key))

    @app.get("/admin/toernooi/<int:key>")
    @admin_required
    def manage_tournament(key):
        item, groups, matches, teams = tournament_data(key)
        return render_template("manage.html", tournament=item, groups=groups, matches=matches, teams=teams)

    @app.post("/admin/toernooi/<int:key>/team")
    @admin_required
    def add_team(key):
        tournament(key)
        name = request.form.get("name", "").strip()
        player_one = request.form.get("player_one", "").strip()
        player_two = request.form.get("player_two", "").strip()
        if not name or not player_one or not player_two:
            flash("Vul de voetbalvereniging en beide spelers in.", "error")
        else:
            try:
                seed = db().execute("SELECT COALESCE(MAX(seed),0)+1 FROM teams WHERE tournament_id=?", (key,)).fetchone()[0]
                db().execute("INSERT INTO teams(tournament_id,name,player_one,player_two,contact,seed) VALUES (?,?,?,?,?,?)",
                             (key, name, player_one, player_two, request.form.get("contact", "").strip(), seed))
                db().commit()
            except sqlite3.IntegrityError:
                flash("Dit team staat al in het toernooi.", "error")
        return redirect(url_for("manage_tournament", key=key))

    def round_robin(team_ids):
        ids = list(team_ids)
        if len(ids) % 2:
            ids.append(None)
        rounds = []
        for round_no in range(len(ids) - 1):
            games = []
            for i in range(len(ids) // 2):
                home, away = ids[i], ids[-1-i]
                if home is not None and away is not None:
                    games.append((home, away) if round_no % 2 == 0 else (away, home))
            rounds.append(games)
            ids = [ids[0], ids[-1], *ids[1:-1]]
        return rounds

    @app.post("/admin/toernooi/<int:key>/genereren")
    @admin_required
    def generate(key):
        item = tournament(key)
        teams = db().execute("SELECT id FROM teams WHERE tournament_id=? ORDER BY seed,name", (key,)).fetchall()
        if len(teams) < item["group_count"] * 2:
            flash("Voeg minimaal twee teams per poule toe.", "error")
            return redirect(url_for("manage_tournament", key=key))
        if db().execute("SELECT 1 FROM matches WHERE tournament_id=? AND score_home IS NOT NULL", (key,)).fetchone():
            flash("Het schema kan niet opnieuw worden gemaakt nadat uitslagen zijn ingevuld.", "error")
            return redirect(url_for("manage_tournament", key=key))
        db().execute("DELETE FROM matches WHERE tournament_id=?", (key,))
        db().execute("DELETE FROM groups WHERE tournament_id=?", (key,))
        group_ids = []
        for position in range(item["group_count"]):
            name = f"Poule {chr(65+position)}"
            group_ids.append(db().execute("INSERT INTO groups(tournament_id,name,position) VALUES (?,?,?)", (key, name, position)).lastrowid)
        buckets = [[] for _ in group_ids]
        direction = 1
        position = 0
        for team in teams:
            buckets[position].append(team["id"])
            if len(group_ids) > 1:
                if position == len(group_ids)-1 and direction == 1: direction = -1
                elif position == 0 and direction == -1: direction = 1
                else: position += direction
        for group_id, members in zip(group_ids, buckets):
            db().executemany("INSERT INTO group_teams(group_id,team_id) VALUES (?,?)", [(group_id, team) for team in members])
        start = datetime.strptime(f"{item['event_date']} {item['start_time']}", "%Y-%m-%d %H:%M")
        slot = timedelta(minutes=item["match_minutes"] + item["break_minutes"])
        scheduled = 0
        max_rounds = max(len(round_robin(bucket)) for bucket in buckets)
        for round_no in range(max_rounds):
            games = []
            for group_id, members in zip(group_ids, buckets):
                rounds = round_robin(members)
                if round_no < len(rounds):
                    games.extend((group_id, home, away) for home, away in rounds[round_no])
            for group_id, home, away in games:
                kickoff = start + slot * (scheduled // item["fields"])
                field_no = scheduled % item["fields"] + 1
                db().execute("INSERT INTO matches(tournament_id,group_id,round_no,home_id,away_id,kickoff,field_no) VALUES (?,?,?,?,?,?,?)",
                             (key, group_id, round_no+1, home, away, kickoff.strftime("%Y-%m-%dT%H:%M"), field_no))
                scheduled += 1
        db().commit()
        flash(f"{scheduled} wedstrijden verdeeld over {len(group_ids)} poules.", "success")
        return redirect(url_for("manage_tournament", key=key))

    @app.post("/admin/wedstrijd/<int:match_id>/uitslag")
    @admin_required
    def result(match_id):
        match = db().execute("SELECT * FROM matches WHERE id=?", (match_id,)).fetchone()
        if not match:
            abort(404)
        try:
            sets = []
            for number in (1, 2, 3):
                raw_home, raw_away = request.form.get(f"set{number}_home", "").strip(), request.form.get(f"set{number}_away", "").strip()
                if not raw_home and not raw_away:
                    continue
                if not raw_home or not raw_away:
                    raise ValueError
                home_games, away_games = int(raw_home), int(raw_away)
                if not 0 <= home_games <= 99 or not 0 <= away_games <= 99 or home_games == away_games:
                    raise ValueError
                sets.append((home_games, away_games))
            if not sets:
                raise ValueError
            home, away = sum(h > a for h, a in sets), sum(a > h for h, a in sets)
        except (KeyError, ValueError):
            flash("Vul per gespeelde set twee verschillende, geldige scores in.", "error")
        else:
            padded = sets + [(None, None)] * (3-len(sets))
            note = ", ".join(f"{h}-{a}" for h, a in sets)
            db().execute("""UPDATE matches SET score_home=?,score_away=?,set1_home=?,set1_away=?,
              set2_home=?,set2_away=?,set3_home=?,set3_away=?,note=? WHERE id=?""",
              (home, away, *padded[0], *padded[1], *padded[2], note, match_id)); db().commit()
        return redirect(url_for("manage_tournament", key=match["tournament_id"]) + "#wedstrijd-" + str(match_id))

    @app.post("/admin/toernooi/<int:key>/publiceren")
    @admin_required
    def publish(key):
        item = tournament(key)
        db().execute("UPDATE tournaments SET published=? WHERE id=?", (0 if item["published"] else 1, key)); db().commit()
        flash("Openbare pagina bijgewerkt.", "success")
        return redirect(url_for("manage_tournament", key=key))

    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", nargs="?", default="serve", choices=("serve", "create-admin"))
    parser.add_argument("--username")
    args = parser.parse_args()
    application = create_app()
    if args.command == "create-admin":
        import getpass
        username = (args.username or input("Gebruikersnaam: ")).strip()
        password = getpass.getpass("Wachtwoord (minimaal 12 tekens): ")
        if len(password) < 12:
            raise SystemExit("Gebruik minimaal 12 tekens.")
        with application.app_context():
            application.db().execute("INSERT INTO users(username,password) VALUES (?,?)", (username, generate_password_hash(password)))
            application.db().commit()
        print("Beheerder aangemaakt.")
    else:
        application.run(port=int(os.environ.get("PORT", "8002")), debug=False)
