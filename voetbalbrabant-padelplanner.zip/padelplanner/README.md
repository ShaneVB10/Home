# VoetbalBrabant Padeltoernooiplanner

Een zelfstandige Flask-website voor padeltoernooien waarin ieder koppel een voetbalvereniging vertegenwoordigt.

## Functies

- meerdere padeltoernooien;
- verenigingskoppels met speler 1, speler 2 en een privé-contactveld;
- automatische verdeling over poules;
- automatisch wedstrijdschema over beschikbare padelbanen;
- instelbare wedstrijdduur en wisseltijd;
- uitslagen per set;
- live poulestanden op punten, setsaldo, gamesaldo en gewonnen games;
- openbare programma-, uitslagen- en standenpagina;
- besloten beheeromgeving zonder openbare registratie.

Een vereniging met meerdere koppels kan worden ingevoerd als bijvoorbeeld `SV Terheijden 1` en `SV Terheijden 2`.

## Lokaal installeren

```bash
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python server.py create-admin --username beheerder
.venv/bin/python server.py
```

Open daarna `http://127.0.0.1:8002`. Stel op hosting een vaste, geheime `TOURNAMENT_SECRET` in. De database staat standaard in `data/tournaments.db`; bewaar deze map bij elke update en maak er dagelijkse privéback-ups van.

## PythonAnywhere

Gebruik `wsgi.py` als WSGI-entrypoint en wijs het projectpad naar deze map. Maak eerst via een Bash-console een beheerder aan. Pak een update nooit uit over de map `data` zonder vooraf een back-up te maken.

