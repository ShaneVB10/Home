"""Encrypted, authenticated backups for physically separated tenant directories."""
import argparse
import base64
import os
import secrets
import sqlite3
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from maintenance import backup

MAGIC=b'TEAMDOSSIER-BACKUP-1\n'
CHUNK=1024*1024


def key_from_environment():
    raw=os.environ.get('TEAM_BACKUP_KEY','')
    try:key=base64.urlsafe_b64decode(raw.encode())
    except Exception as exc:raise ValueError('TEAM_BACKUP_KEY is geen geldige base64-sleutel.') from exc
    if len(key)!=32:raise ValueError('TEAM_BACKUP_KEY moet exact 32 willekeurige bytes bevatten.')
    return key


def encrypt(source,target,key):
    source,target=Path(source),Path(target)
    if target.exists():raise FileExistsError(target)
    nonce=secrets.token_bytes(12);encryptor=Cipher(algorithms.AES(key),modes.GCM(nonce)).encryptor()
    descriptor=os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    try:
        with source.open('rb') as incoming,os.fdopen(descriptor,'wb') as outgoing:
            outgoing.write(MAGIC+nonce)
            while chunk:=incoming.read(CHUNK):outgoing.write(encryptor.update(chunk))
            outgoing.write(encryptor.finalize());outgoing.write(encryptor.tag);outgoing.flush();os.fsync(outgoing.fileno())
    except Exception:
        target.unlink(missing_ok=True);raise


def decrypt(source,target,key):
    source,target=Path(source),Path(target)
    if target.exists():raise FileExistsError(target)
    with source.open('rb') as incoming:
        if incoming.read(len(MAGIC))!=MAGIC:raise ValueError('Dit is geen Teamdossier-back-up.')
        nonce=incoming.read(12);incoming.seek(-16,os.SEEK_END);tag=incoming.read(16)
        end=incoming.tell()-16;incoming.seek(len(MAGIC)+12)
        decryptor=Cipher(algorithms.AES(key),modes.GCM(nonce,tag)).decryptor()
        descriptor=os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        try:
            with os.fdopen(descriptor,'wb') as outgoing:
                remaining=end-incoming.tell()
                while remaining:
                    chunk=incoming.read(min(CHUNK,remaining));remaining-=len(chunk);outgoing.write(decryptor.update(chunk))
                outgoing.write(decryptor.finalize());outgoing.flush();os.fsync(outgoing.fileno())
        except Exception:
            target.unlink(missing_ok=True);raise


def platform_tenants(database):
    with sqlite3.connect(database) as connection:
        connection.row_factory=sqlite3.Row
        return [dict(r) for r in connection.execute("SELECT slug,name,status FROM tenants WHERE status IN ('active','suspended') ORDER BY slug")]


def backup_all(platform_database,tenant_root,output_dir,key):
    tenant_root,output_dir=Path(tenant_root).resolve(),Path(output_dir).resolve()
    if output_dir==tenant_root or output_dir.is_relative_to(tenant_root):raise ValueError('Bewaar externe back-ups buiten de klantdatamap.')
    output_dir.mkdir(parents=True,exist_ok=True,mode=0o700)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');results=[]
    for tenant in platform_tenants(platform_database):
        source=(tenant_root/tenant['slug']).resolve()
        if not source.is_relative_to(tenant_root):raise ValueError('Ongeldige klantmap.')
        target=output_dir/f"{tenant['slug']}-{stamp}.tdbk"
        with tempfile.TemporaryDirectory() as folder:
            plain=Path(folder)/'backup.zip';backup(source,plain);encrypt(plain,target,key)
        results.append(target)
    return results


def verify_file(source,key):
    with tempfile.TemporaryDirectory() as folder:
        plain=Path(folder)/'backup.zip';decrypt(source,plain,key)
        with zipfile.ZipFile(plain) as archive:
            if archive.testzip() is not None or 'data/teams.db' not in archive.namelist():raise ValueError('Back-uparchief is beschadigd of onvolledig.')
            with archive.open('data/teams.db') as handle:
                if handle.read(16)!=b'SQLite format 3\x00':raise ValueError('Database in back-up is ongeldig.')


def restore_to_new_directory(source,output,key):
    output=Path(output).resolve()
    if output.exists():raise FileExistsError('Herstel uitsluitend naar een nieuwe, lege map.')
    parent=output.parent;parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with tempfile.TemporaryDirectory() as folder:
        plain=Path(folder)/'backup.zip';decrypt(source,plain,key)
        with zipfile.ZipFile(plain) as archive:
            if archive.testzip() is not None:raise ValueError('Back-uparchief is beschadigd.')
            for member in archive.infolist():
                destination=(output/member.filename).resolve()
                if not destination.is_relative_to(output):raise ValueError('Onveilig pad in back-up.')
            output.mkdir(mode=0o700)
            try:archive.extractall(output)
            except Exception:
                # Deliberately leave a failed new restore visible for manual inspection.
                raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('generate-key')
    all_parser=sub.add_parser('backup-all');all_parser.add_argument('--platform-db',required=True);all_parser.add_argument('--tenant-root',required=True);all_parser.add_argument('--output-dir',required=True)
    verify=sub.add_parser('verify');verify.add_argument('--file',required=True)
    restore=sub.add_parser('restore');restore.add_argument('--file',required=True);restore.add_argument('--output',required=True)
    args=parser.parse_args()
    if args.command=='generate-key':print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode())
    else:
        key=key_from_environment()
        if args.command=='backup-all':
            paths=backup_all(args.platform_db,args.tenant_root,args.output_dir,key)
            for path in paths:verify_file(path,key);print(f'Geverifieerd: {path.name}')
        elif args.command=='verify':verify_file(args.file,key);print('Back-up is authentiek en leesbaar.')
        else:restore_to_new_directory(args.file,args.output,key);print('Hersteld naar nieuwe map. Controleer de gegevens voordat je deze in productie gebruikt.')
