# Productie-installatie op een Nederlandse VPS

Dit document is bedoeld voor een systeembeheerder. Gebruik Ubuntu LTS, een afzonderlijke Linux-gebruiker `teamdossier`, firewallregels voor uitsluitend SSH/HTTP/HTTPS en automatische beveiligingsupdates.

1. Plaats de applicatie in `/opt/teamdossier/app` en maak een virtualenv in `/opt/teamdossier/venv`.
2. Installeer `requirements.txt`, Nginx, FFmpeg en FFprobe.
3. Maak `/var/lib/teamdossier/platform`, `/var/lib/teamdossier/tenants`, `/var/log/teamdossier` en een externe/gemounte `/var/backups/teamdossier`, eigendom van de servicegebruiker en niet leesbaar voor andere gebruikers.
4. Kopieer `teamdossier.env.example` naar `/etc/teamdossier.env`, zet rechten op `0600` en vul alle secrets en contractgegevens in. Bewaar `TEAM_BACKUP_KEY` ook buiten de VPS in een wachtwoordkluis.
5. Maak de platformbeheerder met `saas.py create-platform-admin`.
6. Configureer DNS-records voor `teamdossier.nl`, `www` en wildcard `*` naar het VPS-adres.
7. Vraag via een DNS-challenge een certificaat aan voor `teamdossier.nl` en `*.teamdossier.nl`. Controleer automatische vernieuwing.
8. Installeer de Nginx- en systemd-bestanden. Test eerst `nginx -t`, start daarna de app en de back-uptimer.
9. Controleer HTTPS, HSTS, een testklant, blokkeren/activeren, auditlogs, bestandsrechten en een hersteltest naar een nieuwe map.
10. Kopieer versleutelde `.tdbk`-bestanden automatisch naar een tweede leverancier of opslaglocatie met versiebeheer/retentie. Een back-up op alleen dezelfde VPS beschermt niet tegen verlies van de VPS.

Een bestaande enkele Teamdossier-installatie wordt niet automatisch als klant geïmporteerd. Maak een doelomgeving, stop schrijfacties, maak een volledige back-up, herstel naar de nieuwe klantmap en valideer accounts, bestanden en seizoenen voordat DNS wordt omgezet.

De meegeleverde privacyverklaring en verwerkersovereenkomst zijn concepten. Vul leveranciers, locaties, termijnen, contactgegevens en contractafspraken in en laat ze juridisch controleren vóór commerciële ingebruikname.
