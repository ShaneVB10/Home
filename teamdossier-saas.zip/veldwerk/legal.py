import os


def legal_context():
    return dict(
        provider=os.environ.get('TEAM_LEGAL_NAME','Teamdossier.nl'),
        address=os.environ.get('TEAM_LEGAL_ADDRESS','[Vul correspondentieadres in]'),
        email=os.environ.get('TEAM_PRIVACY_EMAIL','[Vul privacy-e-mailadres in]'),
        association='[Vul voetbalvereniging in]',
        base_domain=os.environ.get('TEAM_BASE_DOMAIN','teamdossier.nl'),
        subprocessors=os.environ.get('TEAM_SUBPROCESSORS','[Vul hosting-, e-mail-, betaal- en back-upleveranciers in]'),
        version='Concept 1.0 · 9 november 2026')
