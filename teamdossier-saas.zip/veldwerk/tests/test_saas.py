import base64
import secrets
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from cryptography.exceptions import InvalidTag
from werkzeug.security import generate_password_hash
from werkzeug.test import Client
from werkzeug.wrappers import Response

from saas import TenantDispatcher, create_platform_app
from saas_backup import backup_all, restore_to_new_directory, verify_file


class SaaSTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();root=Path(self.temp.name)
        self.platform=create_platform_app(root/'platform',root/'tenants',testing=True)
        with self.platform.app_context():
            self.platform.db().execute('INSERT INTO platform_users(username,password) VALUES (?,?)',('owner',generate_password_hash('platform-test-password')))
            self.platform.db().commit()
        self.client=self.platform.test_client()
        self.client.post('/eigenaar/inloggen',data={'username':'owner','password':'platform-test-password'})
        with self.client.session_transaction() as session:self.csrf=session['platform_csrf']
        self.root=root

    def tearDown(self):
        self.temp.cleanup()

    def tenant(self,slug,name,password='temporary-password-2026'):
        response=self.client.post('/eigenaar/klanten',data={'csrf':self.csrf,'slug':slug,'name':name,'plan':'Club','trial_until':'','password':password})
        self.assertEqual(response.status_code,302)
        return password

    def test_separate_databases_host_routing_and_audit(self):
        alpha_password=self.tenant('club-alpha','Voetbalvereniging Alpha')
        beta_password=self.tenant('club-beta','Voetbalvereniging Beta')
        self.assertTrue((self.root/'tenants/club-alpha/teams.db').is_file())
        self.assertTrue((self.root/'tenants/club-beta/teams.db').is_file())
        dispatcher=TenantDispatcher(self.platform,self.root/'tenants','example.test',testing=True)
        alpha=Client(dispatcher,Response,use_cookies=True);beta=Client(dispatcher,Response,use_cookies=True)
        login=alpha.post('/api/login',json={'username':'beheerder','password':alpha_password},headers={'Host':'club-alpha.example.test'})
        self.assertEqual(login.status_code,200);csrf=alpha.get('/api/me',headers={'Host':'club-alpha.example.test'}).json['csrf']
        self.assertEqual(alpha.post('/api/teams',json={'name':'Alpha 1'},headers={'Host':'club-alpha.example.test','X-CSRF-Token':csrf}).status_code,200)
        beta_login=beta.post('/api/login',json={'username':'beheerder','password':beta_password},headers={'Host':'club-beta.example.test'})
        self.assertEqual(beta_login.status_code,200);beta_csrf=beta.get('/api/me',headers={'Host':'club-beta.example.test'}).json['csrf']
        self.assertEqual(beta.get('/api/dashboard',headers={'Host':'club-beta.example.test'}).json['teams'],[])
        self.assertEqual(alpha.get('/api/dashboard',headers={'Host':'club-alpha.example.test'}).json['teams'][0]['name'],'Alpha 1')
        audit=alpha.get('/api/audit',headers={'Host':'club-alpha.example.test'}).json['rows']
        self.assertTrue(any(row['path']=='/api/teams' and row['username']=='beheerder' for row in audit))
        unknown=Client(dispatcher,Response).get('/',headers={'Host':'unknown.example.test'})
        self.assertEqual(unknown.status_code,404)
        for app in dispatcher.apps.values():app.analysis_workers.shutdown(wait=True)

    def test_suspended_tenant_is_unavailable(self):
        self.tenant('club-gamma','Voetbalvereniging Gamma')
        with self.platform.app_context():
            self.platform.db().execute("UPDATE tenants SET status='suspended' WHERE slug='club-gamma'");self.platform.db().commit()
        dispatcher=TenantDispatcher(self.platform,self.root/'tenants','example.test',testing=True)
        response=Client(dispatcher,Response).get('/',headers={'Host':'club-gamma.example.test'})
        self.assertEqual(response.status_code,404)

    def test_encrypted_backup_verification_wrong_key_and_safe_restore(self):
        self.tenant('club-delta','Voetbalvereniging Delta')
        key=secrets.token_bytes(32);output=self.root/'external-backups'
        paths=backup_all(self.root/'platform/platform.db',self.root/'tenants',output,key)
        self.assertEqual(len(paths),1);self.assertNotIn(b'SQLite format 3',paths[0].read_bytes())
        verify_file(paths[0],key)
        with self.assertRaises(InvalidTag):verify_file(paths[0],secrets.token_bytes(32))
        restored=self.root/'restore-check';restore_to_new_directory(paths[0],restored,key)
        self.assertTrue((restored/'data/teams.db').is_file())
        with self.assertRaises(FileExistsError):restore_to_new_directory(paths[0],restored,key)

    def test_https_headers_legal_roles_and_no_kvk(self):
        self.tenant('club-epsilon','Voetbalvereniging Epsilon')
        dispatcher=TenantDispatcher(self.platform,self.root/'tenants','example.test',testing=True)
        with patch.dict('os.environ',{'TEAM_HTTPS':'1','TEAM_ENFORCE_HTTPS':'1'}):
            https_client=Client(dispatcher,Response)
            insecure=https_client.get('/privacy',base_url='http://club-epsilon.example.test')
            self.assertEqual(insecure.status_code,308);self.assertTrue(insecure.location.startswith('https://'))
            response=https_client.get('/privacy',base_url='https://club-epsilon.example.test')
        self.assertEqual(response.status_code,200)
        text=response.get_data(as_text=True)
        self.assertIn('Voetbalvereniging Epsilon',text);self.assertNotIn('KvK',text)
        self.assertIn('max-age=31536000',response.headers['Strict-Transport-Security'])
        self.assertIn('verwerkingsverantwoordelijke',text)
        for app in dispatcher.apps.values():app.analysis_workers.shutdown(wait=True)


if __name__=='__main__':unittest.main()
