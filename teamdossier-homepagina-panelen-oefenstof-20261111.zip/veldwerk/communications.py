"""Private internal messages plus optional SMTP/IMAP mailbox integration."""
import email
import email.policy
import imaplib
import os
import re
import smtplib
import ssl
import time
from email.message import EmailMessage

from flask import abort,g,jsonify,request

EMAIL=re.compile(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')

def register_communications(app,db,protect,require,permitted,team_allowed,text):
    with app.app_context():
        db().execute('''CREATE TABLE IF NOT EXISTS mail_messages(id INTEGER PRIMARY KEY,direction TEXT NOT NULL,
          status TEXT NOT NULL,from_address TEXT NOT NULL DEFAULT '',to_address TEXT NOT NULL DEFAULT '',subject TEXT NOT NULL,
          body TEXT NOT NULL,team_id INTEGER REFERENCES teams(id),player_id INTEGER REFERENCES players(id),user_id INTEGER,
          external_id TEXT UNIQUE,created REAL NOT NULL,updated REAL NOT NULL)''');db().commit()
        db().execute('''CREATE TABLE IF NOT EXISTS helpdesk_tickets(id INTEGER PRIMARY KEY,subject TEXT NOT NULL,body TEXT NOT NULL,
          status TEXT NOT NULL,response TEXT NOT NULL DEFAULT '',requester_id INTEGER NOT NULL,requester_name TEXT NOT NULL,
          created REAL NOT NULL,updated REAL NOT NULL)''');db().commit()

    def configured():return all(os.environ.get(k) for k in ('TEAM_SMTP_HOST','TEAM_SMTP_USER','TEAM_SMTP_PASSWORD','TEAM_MAIL_FROM'))
    def visible(row):
        if row['direction']=='notification' and g.user['role']!='admin':return False
        if row['team_id'] is not None and not team_allowed(row['team_id']):return False
        if g.user['role']=='player':return row['direction']=='internal' and row['player_id']==g.user['player_id']
        return True

    @app.get('/api/mail')
    @protect
    def mailbox():
        require('training');rows=[dict(r) for r in db().execute('SELECT * FROM mail_messages ORDER BY created DESC,id DESC') if visible(r)]
        tickets=[dict(r) for r in db().execute('SELECT * FROM helpdesk_tickets ORDER BY updated DESC,id DESC') if g.user['role']=='admin' or r['requester_id']==g.user['id']]
        return jsonify(rows=rows,tickets=tickets,smtp_configured=configured(),imap_configured=all(os.environ.get(k) for k in ('TEAM_IMAP_HOST','TEAM_IMAP_USER','TEAM_IMAP_PASSWORD')),address=os.environ.get('TEAM_MAIL_FROM',''))

    @app.post('/api/mail')
    @protect
    def save_mail():
        require('training',True)
        if g.user['role']=='player':abort(403,'Alleen staf kan berichten opstellen.')
        p=request.get_json();action=str(p.get('action','draft'));key=int(p.get('id') or 0)
        if action not in ('draft','send','internal'):abort(400,'Kies concept, intern bericht of verzenden.')
        team_id=int(p['team_id']) if p.get('team_id') else None
        if team_id is not None and not team_allowed(team_id):abort(403,'Geen toegang tot dit team.')
        player_id=int(p['player_id']) if p.get('player_id') else None
        to_address=str(p.get('to_address','')).strip().lower()
        if action=='send' and not EMAIL.fullmatch(to_address):abort(400,'Vul een geldig e-mailadres in.')
        subject=text(p,'subject');body=text(p,'body',10000);now=time.time()
        direction='internal' if action=='internal' else 'draft';status='opgeslagen'
        if action=='send':
            if not configured():abort(503,'E-mail is nog niet gekoppeld. Vul de SMTP-instellingen op de server in.')
            message=EmailMessage();message['From']=os.environ['TEAM_MAIL_FROM'];message['To']=to_address;message['Subject']=subject;message.set_content(body)
            host=os.environ['TEAM_SMTP_HOST'];port=int(os.environ.get('TEAM_SMTP_PORT','465'))
            if os.environ.get('TEAM_SMTP_TLS','ssl')=='starttls':
                with smtplib.SMTP(host,port,timeout=20) as client:client.starttls(context=ssl.create_default_context());client.login(os.environ['TEAM_SMTP_USER'],os.environ['TEAM_SMTP_PASSWORD']);client.send_message(message)
            else:
                with smtplib.SMTP_SSL(host,port,timeout=20,context=ssl.create_default_context()) as client:client.login(os.environ['TEAM_SMTP_USER'],os.environ['TEAM_SMTP_PASSWORD']);client.send_message(message)
            direction='sent';status='verzonden'
        values=(direction,status,os.environ.get('TEAM_MAIL_FROM',''),to_address,subject,body,team_id,player_id,g.user['id'],now)
        if key:
            old=db().execute("SELECT * FROM mail_messages WHERE id=? AND direction='draft'",(key,)).fetchone()
            if not old or not visible(old):abort(404,'Concept niet gevonden.')
            db().execute('UPDATE mail_messages SET direction=?,status=?,from_address=?,to_address=?,subject=?,body=?,team_id=?,player_id=?,user_id=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO mail_messages(direction,status,from_address,to_address,subject,body,team_id,player_id,user_id,created,updated) VALUES (?,?,?,?,?,?,?,?,?,?,?)',(*values,now)).lastrowid
        db().commit();return jsonify(ok=True,id=key,status=status)

    @app.post('/api/mail/sync')
    @protect
    def sync_mail():
        require('training',True)
        needed=('TEAM_IMAP_HOST','TEAM_IMAP_USER','TEAM_IMAP_PASSWORD')
        if not all(os.environ.get(k) for k in needed):abort(503,'Inkomende e-mail is nog niet gekoppeld. Vul de IMAP-instellingen op de server in.')
        count=0
        with imaplib.IMAP4_SSL(os.environ['TEAM_IMAP_HOST'],int(os.environ.get('TEAM_IMAP_PORT','993'))) as client:
            client.login(os.environ['TEAM_IMAP_USER'],os.environ['TEAM_IMAP_PASSWORD']);client.select('INBOX')
            status,ids=client.search(None,'UNSEEN')
            if status!='OK':abort(502,'Inbox kon niet worden gelezen.')
            for identifier in ids[0].split()[-50:]:
                status,payload=client.fetch(identifier,'(RFC822)')
                if status!='OK' or not payload or not isinstance(payload[0],tuple):continue
                message=email.message_from_bytes(payload[0][1],policy=email.policy.default);external=message.get('Message-ID') or f'imap-{identifier.decode()}'
                if db().execute('SELECT 1 FROM mail_messages WHERE external_id=?',(external,)).fetchone():continue
                body=''
                part=message.get_body(preferencelist=('plain',)) if hasattr(message,'get_body') else None
                if part:
                    try:body=part.get_content()
                    except Exception:body=''
                db().execute('INSERT INTO mail_messages(direction,status,from_address,to_address,subject,body,external_id,created,updated) VALUES (?,?,?,?,?,?,?,?,?)',('inbox','ontvangen',str(message.get('From',''))[:300],str(message.get('To',''))[:300],str(message.get('Subject','(geen onderwerp)'))[:300],body[:10000],external,time.time(),time.time()));count+=1
            db().commit()
        return jsonify(ok=True,count=count)

    @app.post('/api/mail/<int:key>/delete')
    @protect
    def delete_mail(key):
        require('training');row=db().execute('SELECT * FROM mail_messages WHERE id=?',(key,)).fetchone()
        if not row or not visible(row):abort(404,'Bericht niet gevonden.')
        db().execute('DELETE FROM mail_messages WHERE id=?',(key,));db().commit();return jsonify(ok=True)

    @app.post('/api/mail/<int:key>/read')
    @protect
    def read_mail(key):
        require('training');row=db().execute('SELECT * FROM mail_messages WHERE id=?',(key,)).fetchone()
        if not row or not visible(row):abort(404,'Bericht niet gevonden.')
        db().execute("UPDATE mail_messages SET status='gelezen',updated=? WHERE id=?",(time.time(),key));db().commit();return jsonify(ok=True)

    @app.post('/api/helpdesk')
    @protect
    def helpdesk_create():
        require('training');p=request.get_json();now=time.time();key=db().execute('INSERT INTO helpdesk_tickets(subject,body,status,response,requester_id,requester_name,created,updated) VALUES (?,?,\'open\',\'\',?,?,?,?)',(text(p,'subject'),text(p,'body',5000),g.user['id'],g.user['username'],now,now)).lastrowid;db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/helpdesk/<int:key>')
    @protect
    def helpdesk_update(key):
        require('training');row=db().execute('SELECT * FROM helpdesk_tickets WHERE id=?',(key,)).fetchone()
        if not row:abort(404,'Helpdeskvraag niet gevonden.')
        if g.user['role']!='admin':abort(403,'Alleen de beheerder kan antwoorden.')
        p=request.get_json();status=str(p.get('status','beantwoord'))
        if status not in ('open','beantwoord','gesloten'):abort(400,'Kies een geldige status.')
        db().execute('UPDATE helpdesk_tickets SET response=?,status=?,updated=? WHERE id=?',(text(p,'response',5000,False),status,time.time(),key));db().commit();return jsonify(ok=True)

    @app.post('/api/helpdesk/<int:key>/delete')
    @protect
    def helpdesk_delete(key):
        require('training');row=db().execute('SELECT * FROM helpdesk_tickets WHERE id=?',(key,)).fetchone()
        if not row or g.user['role']!='admin' and row['requester_id']!=g.user['id']:abort(404,'Helpdeskvraag niet gevonden.')
        db().execute('DELETE FROM helpdesk_tickets WHERE id=?',(key,));db().commit();return jsonify(ok=True)

    def summary():
        if not permitted('training'):return {'mail_unread':0}
        unread=sum(1 for r in db().execute("SELECT * FROM mail_messages WHERE status IN ('ontvangen','nieuw')") if visible(r))
        tickets=db().execute("SELECT count(*) FROM helpdesk_tickets WHERE status='open'").fetchone()[0] if g.user['role']=='admin' else db().execute("SELECT count(*) FROM helpdesk_tickets WHERE requester_id=? AND status!='gesloten'",(g.user['id'],)).fetchone()[0]
        return {'mail_unread':unread+tickets}
    return summary

