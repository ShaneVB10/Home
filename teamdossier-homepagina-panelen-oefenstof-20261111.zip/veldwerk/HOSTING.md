# De volledige website installeren

Het websitepakket bevat de homepagina, login, teambeheer, spelersprofielen, videobibliotheek, videomomenten, ontwikkeloverzicht, accountbeheer, clubinstellingen en hulp. Het bevat geen bestaande accounts, wachtwoorden, database, video's of Python-omgeving.

De nieuwe versie bevat ook zes teamtaakmappen, centrale zoekfunctie, gedeeltelijke toegang per onderdeel/team, oefenstof, wedstrijdpresentaties en een programma/uitslagen/stand-pagina voor het 1e en 2e elftal. De Voetbal.nl-verwijzingen en CSV-import werken zonder API; automatische synchronisatie is nog niet aangesloten.

De volgende uitbreiding voegt trainingsplanning, aanwezigheid, selecties/opstellingen, individuele ontwikkelplannen en rapporten toe. Video’s kunnen nu zonder teamfunctie en zonder teamtaak worden opgeslagen. Het nieuwe bronbestand `planning.py` en `static/planning.js`/`planning.css` moeten bij het bijwerken worden meegenomen. De applicatie voegt de benodigde tabellen en kolommen toe zonder bestaande accounts of bestanden te verwijderen. Nieuwe rechten staan bij bestaande aangepaste rollen standaard uit; schakel ze als beheerder in via Toegangsbeheer.

Spelersfoto’s en het wijzigen van bestaande beoordelingen zijn ook toegevoegd. Installeer bij deze update opnieuw `requirements.txt` (`.venv/bin/python -m pip install -r requirements.txt`) en herlaad daarna de webapp; fotobewerking gebruikt Pillow. Bewaar de hele datamap, inclusief `data/photos/`. Het back-upcommando neemt ook de geregistreerde foto’s mee. Voer back-ups bij voorkeur uit wanneer niemand bestanden of foto’s vervangt.

## De app activeren op je telefoon

De PWA-bestanden zitten in het websitepakket. Kopieer bij een update ook `static/pwa.js`, `pwa.css`, `sw.js`, `manifest.webmanifest`, `offline.html`, `offline.css` en de map `static/icons/`. Werk `server.py` en de HTML-template mee bij: Flask biedt de serviceworker aan op **`/sw.js`** en het manifest op **`/manifest.webmanifest`**. Er is geen extra dependency of abonnement nodig voor de PWA zelf. Bestaande opslag- en verwerkingslimieten van de hosting blijven gelden.

Na **Reload** in PythonAnywhere:

1. Open je eigen website via **HTTPS** en vernieuw de pagina.
2. Kies **Teamdossier.nl als app installeren** voor installatiehulp of een browserprompt.
3. Op iPhone: Safari → deelknop → **Zet op beginscherm** → **Voeg toe**. Op Android: Chrome → menu → **App installeren / Toevoegen aan startscherm**.
4. Open het nieuwe Teamdossier.nl-icoon en log in met je bestaande account.

Je hoeft niets in een appwinkel te publiceren. De manifest- en serviceworkerroute moeten rechtstreeks HTTP 200 geven; zet geen statische mapping voor de hele datamap of root aan. API's, foto's en video's blijven achter de bestaande rechtencontrole. De PWA-cache bevat alleen de openbare offline-melding en haar eigen CSS/icoon. Er is geen offline dashboard of offline toegang tot opgeslagen teamgegevens. Bij een nieuwe serviceworkerversie vraagt de app om vernieuwen, zodat je eerst wijzigingen kunt opslaan. De echte installatie op je eigen iPhone/Android wordt na plaatsing op hosting gecontroleerd; de ontwikkelomgeving valideert manifest, registratie, cachegedrag en browserbediening.

## Een grote PowerPoint toevoegen

Directe presentatie-upload ondersteunt PDF en `.pptx` tot 25 MB. Een `.pptx` van 317 MB is te groot voor deze uploadfunctie en kan ook door de hosting worden geweigerd. Gebruik dan:

1. Upload de presentatie naar je eigen OneDrive of Google Drive.
2. Stel kijktoegang in voor de bedoelde trainers/spelers.
3. Kopieer de HTTPS-kijklink.
4. Kies in Teamdossier.nl **Wedstrijdpresentaties → Presentatie toevoegen**.
5. Laat het bestandveld leeg (gebruik zo nodig **Gekozen bestand wissen**) en plak de link in het linkveld.

De presentatie blijft bij de externe dienst; Teamdossier.nl bewaart de verwijzing. Met alleen de Teamdossier.nl-accountrechten kan de externe dienst niet worden afgeschermd: controleer ook daar de deelinstellingen. Een HTML-foutmelding van PythonAnywhere wordt nu leesbaar getoond met de HTTP-code. Bij 413 is het verzoek te groot; bij 500/502/503/504 kan het Error log de precieze serveroorzaak geven.

## Lokaal starten

Pak het ZIP-bestand uit en open een terminal in de map `veldwerk`:

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python server.py create-admin --username beheerder
.venv/bin/python server.py
```

Op Windows gebruik je `.venv\Scripts\python` in plaats van `.venv/bin/python`. De beheerder kiest het eerste wachtwoord via verborgen terminalinvoer; er is geen standaardaccount. FFmpeg en FFprobe moeten beschikbaar zijn om video's te uploaden en analyseren. Zonder deze programma's blijven accounts, teams en observaties bruikbaar.

## PythonAnywhere of andere WSGI-hosting

De WSGI-ingang is voorbereid, maar de website is niet naar een hostingaccount geplaatst of daar getest. Controleer de actuele opslag-, upload-, CPU- en proceslimieten van het gekozen abonnement. Gratis hosting is bedoeld voor een kleine proefversie, niet voor een grote Veo-bibliotheek of voortdurende analyse.

1. Upload en pak de broncode uit in je eigen account.
2. Maak via een Bash-console een virtualenv met een ondersteunde Python-versie (3.12+) en installeer `requirements.txt`.
3. Maak via die console je beheerdersaccount aan met `server.py create-admin`. Gebruik de virtualenv-Python en geef het wachtwoord niet mee als commandoregelargument.
4. Maak een Python/Flask-webapp met handmatige WSGI-configuratie en wijs de virtualenv toe.
5. Plaats in het WSGI-configuratiebestand van je host:

```python
import os
import sys

project_dir = '/home/JOUW_GEBRUIKERSNAAM/veldwerk'
sys.path.insert(0, project_dir)
os.environ['TEAM_DATA'] = project_dir + '/data'
os.environ['TEAM_HTTPS'] = '1'
os.environ['TEAM_ANALYSIS_MODE'] = 'deferred'

from wsgi import application
```

6. Vervang het projectpad door je echte pad. Activeer HTTPS voor het subdomein van je host en herlaad de webapp. `Secure`-cookies vereisen HTTPS.
7. Test de homepagina, inloggen, accountuitgifte en het aanmaken van een team. Controleer dat een bezoeker zonder login het dashboard niet krijgt en een speler geen beelden van anderen kan openen.

Je hoeft statische bestanden niet apart te publiceren: Flask bedient `/static/`. Publiceer de map `data` nooit als statische map. De videoroute controleert per verzoek de accountrechten.

### Videoanalyse op gedeelde hosting

`wsgi.py` gebruikt standaard `TEAM_ANALYSIS_MODE=deferred`: uploads worden in de database klaargezet, niet in een onbetrouwbare achtergrondthread van de webserver. Als FFprobe beschikbaar is, kunnen video's na upload al worden afgespeeld. Verwerk de wachtrij via een console of ondersteunde taakplanner:

```sh
TEAM_DATA=/home/JOUW_GEBRUIKERSNAAM/veldwerk/data .venv/bin/python server.py analyse-pending
```

Automatisch uitvoeren vereist een taakplanner of worker die jouw abonnement ondersteunt. De gratis variant biedt die mogelijkheid mogelijk niet. Gebruik één wachtrijverwerker tegelijk. De lokale ontwikkelserver gebruikt standaard `background` en start analyses automatisch. Een productie-installatie met meer processen vraagt een echte werkqueue. Wissel niet naar `background` op een host die achtergrondthreads niet ondersteunt.

De analyse meet technische beeldgegevens, geen voetbalacties of rugnummers. Veo-import en voetbalinhoudelijke herkenning zijn nog niet gekoppeld.

## Back-ups en updates

Maak een lokale back-up voordat je een update plaatst:

```sh
.venv/bin/python server.py backup --output /een/prive/map/veldwerk-backup.zip
```

Deze opdracht maakt een consistente SQLite-kopie en neemt alle door de database gebruikte video's mee. Het bestand bevat gevoelige teamgegevens en wachtwoordhashes: bewaar het privé, buiten publiek bereik. Voor herstel: stop de website en worker, bewaar de huidige datamap, en pak de back-up uit in de installatiemap zodat `data/teams.db` en `data/videos/` worden hersteld. Herstart en controleer rechten, accounts en video's.

Installeer een nieuwe versie door code en statische bestanden bij te werken; behoud je volledige `data`-map. Nieuwe bestanden `permissions.py`, `extensions.py` en `static/library.js`/`library.css` moeten ook worden meegenomen. Bij de eerste start voegt de applicatie ontbrekende tabellen en het rechtenveld toe; bestaande accounts en hun basisrechten blijven behouden. Installeer dependencies opnieuw en voer de tests uit met tijdelijke testdata. Herlaad daarna de webapp. Automatisch deployen is nog niet ingesteld: daarvoor ontbreken hostingtoegang, een releasekanaal en een terugvalprocedure die op die host is getest.

Back-ups nemen nu ook de geregistreerde bestanden uit `data/presentations/` mee. Behoud bij updates en herstel dus de volledige `data`-map, niet alleen de database en video's.

De repository bevat CI voor tests en Dependabot voor voorgestelde dependency-updates. Deze werken pas nadat de bestanden naar GitHub zijn gepusht en de functies zijn ingeschakeld. Ze publiceren de website niet automatisch.


## Update met seizoenen en medische staf

Maak vóór het vervangen van bestanden een volledige privéback-up. Bewaar bij uitpakken de bestaande map `veldwerk/data` inclusief database, video's, presentaties en foto's. Pak de nieuwe broncode-ZIP uit over de applicatiebestanden, gebruik je bestaande virtualenv, installeer `requirements.txt` en kies **Web → Reload**. De eerste start voegt seizoen- en medische tabellen toe en behoudt bestaande registraties. Een nieuwe broncode-ZIP is geen databack-up.

Controleer na Reload het gekozen seizoen en de spelers/beelden. Stel medische toegang voor stafaccounts expliciet in via **Toegangsbeheer**; bestaande trainers krijgen deze niet automatisch. Eerder gearchiveerde seizoenen blijven leesbaar via de seizoenskeuze bovenaan. Vergeet niet ook de nieuwe Python-bestanden `seasons.py`, `fast_planning.py`, `care.py` en nieuwe statische bestanden mee te uploaden als je handmatig afzonderlijke bestanden bijwerkt.

## Hosting voor meerdere verenigingen

Gebruik op een VPS `saas_wsgi.py` in plaats van `wsgi.py`. Hiervoor zijn wildcard-DNS, een wildcard HTTPS-certificaat, Nginx, een WSGI-server, vaste secrets, een externe back-uplocatie en monitoring nodig. Een eenvoudige PythonAnywhere-webapp met één domein is bedoeld voor de bestaande enkele omgeving en is geen volledige SaaS-productieopstelling. Zie README.md voor variabelen, klantenscheiding en versleutelde back-ups.

## Docker: dezelfde app bij meer hostingpartijen

De applicatie hoeft niet naar een andere programmeertaal te worden om te verhuizen. Met Docker draait dezelfde gecontroleerde Python-app op iedere VPS of containerdienst die Docker ondersteunt.

```bash
cd veldwerk
export TEAM_BASE_DOMAIN=teamdossier.nl
export TEAM_PLATFORM_SECRET="maak-hier-een-lange-willekeurige-geheime-waarde"
docker compose -f deploy/docker-compose.yml up -d --build
```

De container luistert lokaal op `127.0.0.1:8000`. Plaats Nginx of de proxy van de hostingpartij ervoor voor HTTPS en `*.teamdossier.nl`. De Docker-volumes bewaren het platform en alle afgescheiden klantomgevingen bij een nieuwe containerrelease. Maak ook van deze volumes dagelijkse back-ups.
