import time,uuid
from pathlib import Path
from flask import abort,g,jsonify,request,send_file
CATEGORIES=('Beleidsplan','Visieplan','Training','Wedstrijdselectie','Ontwikkelplan','Statistieken & rapporten','Overig');EXTENSIONS={'.pdf','.docx','.xlsx','.pptx','.txt','.csv'}
def register_documents(app,db,protect,require,permitted,team_allowed,text):
    root=app.config['DATA']/'club_documents';root.mkdir(exist_ok=True,mode=0o700)
    with app.app_context():db().execute('''CREATE TABLE IF NOT EXISTS club_documents(id TEXT PRIMARY KEY,title TEXT NOT NULL,category TEXT NOT NULL,team_id INTEGER REFERENCES teams(id),player_id INTEGER REFERENCES players(id),note TEXT NOT NULL,filename TEXT NOT NULL,original_name TEXT NOT NULL,created_by INTEGER NOT NULL,created REAL NOT NULL,season_id INTEGER NOT NULL DEFAULT 1)''');db().commit()
    def allowed(row):return row['team_id'] is None or team_allowed(row['team_id'])
    def links(values):
        category=str(values.get('category',''));team_id=int(values['team_id']) if values.get('team_id') else None;player_id=int(values['player_id']) if values.get('player_id') else None
        if category not in CATEGORIES:abort(400,'Kies een geldige documentcategorie.')
        if team_id is not None and not team_allowed(team_id):abort(403,'Geen toegang tot dit team.')
        if player_id is not None:
            player=db().execute('SELECT team_id FROM season_players WHERE season_id=? AND player_id=?',(g.season_id,player_id)).fetchone()
            if not player or not team_allowed(player['team_id']) or team_id is not None and player['team_id']!=team_id:abort(400,'De speler valt niet binnen het gekozen team.')
        return category,team_id,player_id
    @app.post('/api/club-documents')
    @protect
    def upload_document():
        require('presentations',True);category,team_id,player_id=links(request.form)
        upload=request.files.get('file');suffix=Path(upload.filename).suffix.lower() if upload else ''
        if not upload or suffix not in EXTENSIONS:abort(400,'Gebruik PDF, Word, Excel, PowerPoint, TXT of CSV.')
        key=uuid.uuid4().hex;filename=key+suffix;path=root/filename
        try:
            upload.save(path)
            if path.stat().st_size>25*1024*1024:abort(400,'Maximaal 25 MB per document.')
            db().execute('INSERT INTO club_documents VALUES (?,?,?,?,?,?,?,?,?,?,?)',(key,text(request.form,'title'),category,team_id,player_id,text(request.form,'note',3000,False),filename,Path(upload.filename).name[:255],g.user['id'],time.time(),g.season_id));db().commit()
        except Exception:path.unlink(missing_ok=True);raise
        return jsonify(ok=True,id=key)
    @app.post('/api/club-documents/<key>')
    @protect
    def update_document(key):
        require('presentations',True);row=db().execute('SELECT * FROM club_documents WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not row or not allowed(row):abort(404,'Document niet gevonden.')
        payload=request.get_json();category,team_id,player_id=links(payload)
        db().execute('UPDATE club_documents SET title=?,category=?,team_id=?,player_id=?,note=? WHERE id=?',(text(payload,'title'),category,team_id,player_id,text(payload,'note',3000,False),key));db().commit()
        return jsonify(ok=True)
    @app.get('/club-documents/<key>')
    @protect
    def download_document(key):
        require('presentations');row=db().execute('SELECT * FROM club_documents WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not row or not allowed(row):abort(404,'Document niet gevonden.')
        return send_file(root/row['filename'],as_attachment=True,download_name=row['original_name'])
    @app.post('/api/club-documents/<key>/delete')
    @protect
    def delete_document(key):
        require('presentations',True);row=db().execute('SELECT * FROM club_documents WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not row or not allowed(row):abort(404,'Document niet gevonden.')
        db().execute('DELETE FROM club_documents WHERE id=?',(key,));db().commit();(root/row['filename']).unlink(missing_ok=True);return jsonify(ok=True)
    def summary():
        rows=[]
        if permitted('presentations'):
            for row in db().execute('SELECT * FROM club_documents WHERE season_id=? ORDER BY created DESC',(g.season_id,)):
                if allowed(row):item=dict(row);item.pop('filename');rows.append(item)
        return {'club_documents':rows,'document_categories':CATEGORIES}
    return summary
