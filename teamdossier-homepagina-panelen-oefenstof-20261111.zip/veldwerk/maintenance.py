"""Portable source packaging and consistent, private data backups."""
import argparse
import os
import sqlite3
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def package(output):
    output = Path(output).resolve()
    files = [ROOT / name for name in ('server.py', 'permissions.py', 'extensions.py', 'planning.py', 'seasons.py', 'fast_planning.py', 'care.py', 'exercise_catalog.py', 'smart_match.py', 'club_suite.py', 'communications.py', 'business.py', 'documents.py', 'player_tracking.py', 'legal.py', 'saas.py', 'saas_wsgi.py', 'saas_backup.py', 'deployment_check.py', 'wsgi.py', 'maintenance.py', 'requirements.txt', 'README.md', 'HOSTING.md')]
    for folder in ('templates', 'static', 'tests', 'deploy'):
        files.extend(p for p in (ROOT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation preserves any existing package.
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, Path('veldwerk') / path.relative_to(ROOT))


def backup(data_dir, output):
    data_dir, output = Path(data_dir).resolve(), Path(output).resolve()
    if output.is_relative_to(data_dir):
        raise ValueError('Bewaar de back-up buiten de datamap.')
    if not (data_dir / 'teams.db').is_file():
        raise ValueError('Database niet gevonden.')
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temp:
        snapshot = Path(temp) / 'teams.db'
        with sqlite3.connect(data_dir / 'teams.db') as source, sqlite3.connect(snapshot) as target:
            source.backup(target)
        with sqlite3.connect(snapshot) as db:
            video_files = [row[0] for row in db.execute('SELECT filename FROM videos')]
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            documents = [r[0] for r in db.execute("SELECT filename FROM presentations WHERE filename != ''")] if 'presentations' in tables else []
            player_columns={r[1] for r in db.execute('PRAGMA table_info(players)')}
            photos=[r[0] for r in db.execute("SELECT photo FROM players WHERE photo != ''")] if 'photo' in player_columns else []
            staff_columns={r[1] for r in db.execute('PRAGMA table_info(staff)')} if 'staff' in tables else set()
            staff_photos=[r[0] for r in db.execute("SELECT photo FROM staff WHERE photo != ''")] if 'photo' in staff_columns else []
            club_documents=[r[0] for r in db.execute("SELECT filename FROM club_documents WHERE filename != ''")] if 'club_documents' in tables else []
        # Validate every referenced file before writing an archive.
        for filename in video_files:
            path = (data_dir / 'videos' / filename).resolve()
            if not path.is_relative_to(data_dir / 'videos') or not path.is_file():
                raise ValueError('Een videobestand ontbreekt; back-up afgebroken.')
        for filename in documents:
            path = (data_dir / 'presentations' / filename).resolve()
            if not path.is_relative_to(data_dir / 'presentations') or not path.is_file():
                raise ValueError('Een presentatie ontbreekt; back-up afgebroken.')
        for filename in photos:
            path=(data_dir/'photos'/filename).resolve()
            if not path.is_relative_to(data_dir/'photos') or not path.is_file():
                raise ValueError('Een spelersfoto ontbreekt; back-up afgebroken.')
        for filename in staff_photos:
            path=(data_dir/'staff_photos'/filename).resolve()
            if not path.is_relative_to(data_dir/'staff_photos') or not path.is_file():
                raise ValueError('Een staffoto ontbreekt; back-up afgebroken.')
        for filename in club_documents:
            path=(data_dir/'club_documents'/filename).resolve()
            if not path.is_relative_to(data_dir/'club_documents') or not path.is_file():
                raise ValueError('Een clubdocument ontbreekt; back-up afgebroken.')
        descriptor = os.open(output, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(descriptor, 'wb') as handle:
            with zipfile.ZipFile(handle, 'w', zipfile.ZIP_DEFLATED) as archive:
                archive.write(snapshot, 'data/teams.db')
                for filename in video_files:
                    archive.write(data_dir / 'videos' / filename, Path('data/videos') / filename)
                for filename in documents:
                    archive.write(data_dir / 'presentations' / filename, Path('data/presentations') / filename)
                for filename in photos:
                    archive.write(data_dir/'photos'/filename,Path('data/photos')/filename)
                for filename in staff_photos:
                    archive.write(data_dir/'staff_photos'/filename,Path('data/staff_photos')/filename)
                for filename in club_documents:
                    archive.write(data_dir/'club_documents'/filename,Path('data/club_documents')/filename)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    package(args.output)
    print('Websitepakket gemaakt zonder accounts, wachtwoorden of videodata.')
