import io
import json
import unittest

import test_server as fixtures


class SmartMatchTests(unittest.TestCase):
    setUpClass=classmethod(fixtures.TeamTests.setUpClass.__func__)
    tearDownClass=classmethod(fixtures.TeamTests.tearDownClass.__func__)
    setUp=fixtures.TeamTests.setUp
    tearDown=fixtures.TeamTests.tearDown
    login=fixtures.TeamTests.login
    post=fixtures.TeamTests.post
    seed_video=fixtures.TeamTests.seed_video

    def test_veo_setup_link_import_review_and_player_privacy(self):
        self.seed_video('wedstrijd',1,None,'match');self.login()
        response=self.post('/api/integrations/veo',{'mode':'export','account_label':'SV Test'})
        self.assertEqual(response.status_code,200,response.json)
        self.assertEqual(self.post('/api/smart-analysis/source',{'video_id':'wedstrijd','url':'https://app.veo.co/matches/voorbeeld'}).status_code,200)
        csv_data=('start;eind;rugnummer;actie;teamtaak;teamfunctie;betrouwbaarheid\n'
                  '12,5;20;10;Diepteloop;Kansen creëren;Aanvallen;88\n').encode()
        response=self.client.post('/api/smart-analysis/import',data={'video_id':'wedstrijd','file':(io.BytesIO(csv_data),'events.csv')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,200,response.json);self.assertEqual(response.json['count'],1);self.assertEqual(response.json['unmatched'],0)
        dashboard=self.client.get('/api/dashboard').json;item=dashboard['analysis_suggestions'][0]
        self.assertEqual(item['player_id'],2);self.assertEqual(dashboard['veo_integration']['account_label'],'SV Test')
        self.assertNotIn('token',json.dumps(dashboard['veo_integration']).lower())
        self.assertEqual(self.post(f"/api/smart-analysis/suggestions/{item['id']}",{'status':'goedgekeurd'}).status_code,200)
        self.assertEqual(len(self.client.get('/api/dashboard').json['moments']),1)
        self.login('player');player_data=self.client.get('/api/dashboard').json
        self.assertEqual(player_data['analysis_suggestions'],[]);self.assertEqual(player_data['video_sources'],[])

    def test_manual_live_match_and_read_only_trainer(self):
        self.login();payload={'team_id':1,'date':'2026-11-14T14:30','home':'SV Test','away':'Tegenstander','status':'live','score_home':2,'score_away':1,'minute':67}
        response=self.post('/api/matches/manual',payload);self.assertEqual(response.status_code,200,response.json)
        row=self.client.get('/api/dashboard').json['fixtures'][0]
        self.assertEqual((row['status'],row['minute'],row['score_home']),('live',67,2));self.assertEqual(row['source'],'Handmatig')
        self.login('coach');self.assertEqual(self.post('/api/matches/manual',payload).status_code,403)

    def test_exercise_diagram_is_validated_and_builtin_is_read_only(self):
        self.login();created=self.post('/api/exercises',{'title':'Eigen vorm','description':'Beschrijving','minutes':20}).json['id']
        diagram={'field':'half','items':[{'type':'player-red','x':20,'y':30},{'type':'ball','x':23,'y':30},{'type':'pass','x':23,'y':30,'x2':60,'y2':55},{'type':'dribble','x':25,'y':40,'x2':70,'y2':65}]}
        self.assertEqual(self.post('/api/exercises/diagram',{'id':created,'diagram':diagram}).status_code,200)
        saved=next(e for e in self.client.get('/api/dashboard').json['exercises'] if e['id']==created)
        self.assertEqual(json.loads(saved['diagram']),diagram)
        invalid={'field':'full','items':[{'type':'cone','x':101,'y':10}]}
        self.assertEqual(self.post('/api/exercises/diagram',{'id':created,'diagram':invalid}).status_code,400)
        catalog=self.client.get('/api/exercise-catalog?age=O8').json['rows']
        self.assertEqual(self.post('/api/exercises/diagram',{'id':catalog[0]['id'],'diagram':diagram}).status_code,403)
        copied=self.post(f'/api/exercises/{created}/duplicate',{});self.assertEqual(copied.status_code,200,copied.json)
        duplicate_id=copied.json['id'];duplicate=next(e for e in self.client.get('/api/dashboard').json['exercises'] if e['id']==duplicate_id)
        self.assertTrue(duplicate['title'].startswith('Kopie · '));self.assertEqual(json.loads(duplicate['diagram']),diagram)
        self.assertEqual(self.post(f'/api/exercises/{duplicate_id}/delete',{}).status_code,200)

    def test_connection_crud_is_admin_only_and_does_not_accept_credentials_in_url(self):
        self.login();payload={'name':'Officiële uitslagen','kind':'uitslagen','purpose':'Programma en standen','endpoint':'https://api.example.test/scores','active':True,'team_ids':[1,2]}
        created=self.post('/api/connections',payload);self.assertEqual(created.status_code,200,created.json);key=created.json['id']
        row=self.client.get('/api/dashboard').json['connections'][0];self.assertEqual(row['team_ids'],[1,2])
        self.assertEqual(self.post(f'/api/connections/{key}/test',{}).status_code,200)
        self.assertEqual(self.post('/api/connections',{**payload,'endpoint':'https://user:secret@example.test/scores'}).status_code,400)
        self.login('coach');self.assertEqual(self.post('/api/connections',{**payload,'name':'Verboden'}).status_code,403)
        self.login();self.assertEqual(self.post(f'/api/connections/{key}/delete',{}).status_code,200)
        self.assertEqual(self.client.get('/api/dashboard').json['connections'],[])


if __name__=='__main__':unittest.main()
