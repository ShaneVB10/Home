"""Host-based SaaS control plane with one physical data directory per customer."""
import argparse
import functools
import os
import re
import secrets
import sqlite3
import threading
import time
from datetime import date,datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from legal import legal_context
from server import create_app

ROOT=Path(__file__).resolve().parent
SLUG=re.compile(r'^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$')


def create_platform_app(platform_dir=None, tenant_root=None, testing=False):
    app=Flask(__name__,template_folder='templates',static_folder='static')
    platform=Path(platform_dir or os.environ.get('TEAM_PLATFORM_DATA',ROOT/'platform_data')).resolve()
    tenants=Path(tenant_root or os.environ.get('TEAM_TENANT_ROOT',ROOT/'tenant_data')).resolve()
    platform.mkdir(parents=True,exist_ok=True,mode=0o700);tenants.mkdir(parents=True,exist_ok=True,mode=0o700)
    app.config.update(SECRET_KEY=os.environ.get('TEAM_PLATFORM_SECRET',secrets.token_hex(32)),
        DATABASE=platform/'platform.db',TENANT_ROOT=tenants,TESTING=testing,
        SESSION_COOKIE_NAME='teamdossier_platform',SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SECURE=os.environ.get('TEAM_HTTPS')=='1',SESSION_COOKIE_SAMESITE='Strict')
    if os.environ.get('TEAM_BASE_DOMAIN'):
        app.config['TRUSTED_HOSTS']=[os.environ['TEAM_BASE_DOMAIN'],'www.'+os.environ['TEAM_BASE_DOMAIN'],'localhost','127.0.0.1']

    def db():
        if 'platform_db' not in g:
            g.platform_db=sqlite3.connect(app.config['DATABASE'],timeout=20)
            g.platform_db.row_factory=sqlite3.Row
        return g.platform_db
    app.db=db

    @app.teardown_appcontext
    def close(_error=None):
        connection=g.pop('platform_db',None)
        if connection:connection.close()

    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS platform_users(id INTEGER PRIMARY KEY,username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS tenants(id INTEGER PRIMARY KEY,slug TEXT NOT NULL UNIQUE,name TEXT NOT NULL,
          plan TEXT NOT NULL,status TEXT NOT NULL,trial_until TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS platform_audit(id INTEGER PRIMARY KEY,created REAL NOT NULL,user_id INTEGER,
          username TEXT NOT NULL,method TEXT NOT NULL,path TEXT NOT NULL,status INTEGER NOT NULL,request_id TEXT NOT NULL);
        ''');db().commit()

    @app.before_request
    def load_user():
        g.request_id=secrets.token_hex(16);g.platform_user=None
        if os.environ.get('TEAM_ENFORCE_HTTPS')=='1' and not request.is_secure:
            if request.method in ('GET','HEAD'):return redirect('https://'+request.host+request.full_path.rstrip('?'),code=308)
            abort(400,'Gebruik een beveiligde HTTPS-verbinding.')
        if session.get('platform_user'):
            g.platform_user=db().execute('SELECT id,username FROM platform_users WHERE id=? AND active=1',(session['platform_user'],)).fetchone()

    @app.after_request
    def secure(response):
        response.headers['X-Content-Type-Options']='nosniff';response.headers['X-Frame-Options']='DENY'
        response.headers['Referrer-Policy']='same-origin';response.headers['X-Request-ID']=g.get('request_id',secrets.token_hex(16))
        response.headers['Content-Security-Policy']="default-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        if os.environ.get('TEAM_HTTPS')=='1':response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
        if request.method=='POST':
            user=g.get('platform_user')
            db().execute('INSERT INTO platform_audit(created,user_id,username,method,path,status,request_id) VALUES (?,?,?,?,?,?,?)',
                (time.time(),user['id'] if user else None,user['username'] if user else '',request.method,request.path,response.status_code,response.headers['X-Request-ID']))
            db().commit()
        return response

    def csrf():return session.setdefault('platform_csrf',secrets.token_urlsafe(24))
    app.jinja_env.globals['platform_csrf']=csrf

    def owner(fn):
        @functools.wraps(fn)
        def wrapped(*args,**kwargs):
            if not g.platform_user:return redirect(url_for('platform_login',next=request.path))
            if request.method=='POST' and not secrets.compare_digest(request.form.get('csrf',''),session.get('platform_csrf','')):abort(403)
            return fn(*args,**kwargs)
        return wrapped

    @app.get('/')
    def platform_home():return render_template('saas_home.html',legal=legal_context())

    @app.route('/eigenaar/inloggen',methods=('GET','POST'))
    def platform_login():
        if request.method=='POST':
            row=db().execute('SELECT * FROM platform_users WHERE username=? AND active=1',(request.form.get('username','').strip(),)).fetchone()
            if row and check_password_hash(row['password'],request.form.get('password','')):
                session.clear();session['platform_user']=row['id'];session['platform_csrf']=secrets.token_urlsafe(24)
                destination=request.args.get('next','')
                return redirect(destination if destination.startswith('/') and not destination.startswith('//') else url_for('platform_dashboard'))
            flash('Inloggen mislukt.','error')
        return render_template('saas_login.html',legal=legal_context())

    @app.post('/eigenaar/uitloggen')
    @owner
    def platform_logout():session.clear();return redirect(url_for('platform_home'))

    @app.get('/eigenaar')
    @owner
    def platform_dashboard():
        rows=[dict(r) for r in db().execute('SELECT * FROM tenants ORDER BY created DESC')]
        for row in rows:
            folder=tenants/row['slug'];row['bytes']=sum(p.stat().st_size for p in folder.rglob('*') if p.is_file()) if folder.exists() else 0
        audit=[dict(r) for r in db().execute('SELECT * FROM platform_audit ORDER BY id DESC LIMIT 50')]
        for row in audit:row['created_text']=datetime.fromtimestamp(row['created'],ZoneInfo('Europe/Amsterdam')).strftime('%d-%m-%Y %H:%M:%S')
        leads=[dict(r) for r in db().execute('SELECT * FROM business_leads ORDER BY created DESC LIMIT 100')]
        return render_template('saas_dashboard.html',tenants=rows,audit=audit,leads=leads,legal=legal_context())

    @app.post('/eigenaar/klanten')
    @owner
    def create_tenant():
        slug=request.form.get('slug','').strip().lower();name=request.form.get('name','').strip();password=request.form.get('password','')
        plan=request.form.get('plan','Starter');trial=request.form.get('trial_until','')
        if not SLUG.fullmatch(slug) or slug in ('www','admin','api','static','test'):
            flash('Gebruik 3–40 kleine letters/cijfers; een koppelteken mag in het midden.','error');return redirect(url_for('platform_dashboard'))
        if not name or len(name)>120 or len(password)<12 or plan not in ('Starter','Trainer','Club'):
            flash('Controleer klantnaam, pakket en wachtwoord (minimaal 12 tekens).','error');return redirect(url_for('platform_dashboard'))
        try:
            if trial:date.fromisoformat(trial)
        except ValueError:
            flash('Ongeldige einddatum proefperiode.','error');return redirect(url_for('platform_dashboard'))
        folder=(tenants/slug).resolve()
        if not folder.is_relative_to(tenants):abort(400)
        try:
            now=time.time();db().execute('INSERT INTO tenants(slug,name,plan,status,trial_until,created,updated) VALUES (?,?,?,?,?,?,?)',(slug,name,plan,'provisioning',trial,now,now));db().commit()
        except sqlite3.IntegrityError:
            db().rollback();flash('Deze klantcode bestaat al.','error');return redirect(url_for('platform_dashboard'))
        try:
            tenant_app=create_app(folder,testing=testing,tenant_slug=slug)
            with tenant_app.app_context():
                tenant_app.db().execute("INSERT INTO users(username,password,role) VALUES (?,?, 'admin')",('beheerder',generate_password_hash(password)))
                tenant_app.db().execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('club_name',?)",(name,));tenant_app.db().commit()
            tenant_app.analysis_workers.shutdown(wait=True)
            db().execute("UPDATE tenants SET status='active',updated=? WHERE slug=?",(time.time(),slug));db().commit()
        except Exception:
            db().execute("UPDATE tenants SET status='suspended',updated=? WHERE slug=?",(time.time(),slug));db().commit()
            app.logger.exception('Klantomgeving kon niet volledig worden ingericht')
            flash('De klant is geblokkeerd aangemaakt omdat de inrichting mislukte. Controleer het serverlog.','error');return redirect(url_for('platform_dashboard'))
        flash(f'Klantomgeving {slug} aangemaakt. Geef het tijdelijke wachtwoord veilig door.','success')
        return redirect(url_for('platform_dashboard'))

    @app.post('/eigenaar/klanten/<int:key>/status')
    @owner
    def tenant_status(key):
        row=db().execute('SELECT * FROM tenants WHERE id=?',(key,)).fetchone()
        if not row:abort(404)
        status=request.form.get('status')
        if status not in ('active','suspended'):abort(400)
        db().execute('UPDATE tenants SET status=?,updated=? WHERE id=?',(status,time.time(),key));db().commit()
        flash('Klantstatus bijgewerkt.','success');return redirect(url_for('platform_dashboard'))

    @app.get('/privacy')
    def privacy():return render_template('legal_privacy.html',legal=legal_context())

    @app.get('/verwerkersovereenkomst')
    def dpa():return render_template('legal_dpa.html',legal=legal_context())

    from business import register_business
    register_business(app,db)

    return app


class TenantDispatcher:
    def __init__(self,platform_app,tenant_root=None,base_domain=None,testing=False):
        self.platform=platform_app;self.root=Path(tenant_root or platform_app.config['TENANT_ROOT']).resolve()
        self.base=(base_domain or os.environ.get('TEAM_BASE_DOMAIN','localhost')).lower().split(':')[0]
        self.testing=testing;self.apps={};self.lock=threading.Lock()

    def tenant(self,slug):
        row=None
        with self.platform.app_context():row=self.platform.db().execute('SELECT * FROM tenants WHERE slug=?',(slug,)).fetchone()
        if not row or row['status']!='active':return None
        if row['trial_until'] and row['trial_until']<date.today().isoformat():return None
        with self.lock:
            if slug not in self.apps:self.apps[slug]=create_app(self.root/slug,testing=self.testing,recover_jobs=True,tenant_slug=slug)
            return self.apps[slug]

    def __call__(self,environ,start_response):
        host=environ.get('HTTP_HOST','').lower().split(':')[0]
        if host in (self.base,'www.'+self.base,'localhost','127.0.0.1'):
            return self.platform(environ,start_response)
        suffix='.'+self.base
        if host.endswith(suffix):
            slug=host[:-len(suffix)]
            app=self.tenant(slug) if SLUG.fullmatch(slug) else None
            if app:return app(environ,start_response)
        body='Klantomgeving niet gevonden of tijdelijk niet actief.'.encode()
        start_response('404 Not Found',[('Content-Type','text/plain; charset=utf-8'),('Content-Length',str(len(body))),('Cache-Control','no-store')])
        return [body]


def build_application(testing=False,platform_dir=None,tenant_root=None,base_domain=None):
    platform=create_platform_app(platform_dir,tenant_root,testing)
    return TenantDispatcher(platform,tenant_root,base_domain,testing)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=('serve','create-platform-admin'),nargs='?',default='serve');parser.add_argument('--username')
    args=parser.parse_args();platform=create_platform_app()
    if args.command=='create-platform-admin':
        import getpass
        username=(args.username or input('Platformbeheerder: ')).strip();password=getpass.getpass('Wachtwoord (minimaal 14 tekens): ')
        if len(password)<14:raise SystemExit('Gebruik minimaal 14 tekens.')
        with platform.app_context():platform.db().execute('INSERT INTO platform_users(username,password) VALUES (?,?)',(username,generate_password_hash(password)));platform.db().commit()
        print('Platformbeheerder aangemaakt.')
    else:
        from werkzeug.serving import run_simple
        run_simple('127.0.0.1',8000,build_application())

