"""Player tracking: periodic reviews, training load, match output and progression."""
import time
from datetime import date
from flask import abort,g,jsonify,request

def register_tracking(app,db,protect,require,permitted,team_allowed,text):
    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS player_evaluations(id INTEGER PRIMARY KEY,season_id INTEGER NOT NULL,player_id INTEGER NOT NULL,
          period TEXT NOT NULL,evaluated_on TEXT NOT NULL,technical INTEGER NOT NULL,tactical INTEGER NOT NULL,physical INTEGER NOT NULL,
          mental INTEGER NOT NULL,social INTEGER NOT NULL,note TEXT NOT NULL,author_id INTEGER NOT NULL,updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS training_loads(id INTEGER PRIMARY KEY,season_id INTEGER NOT NULL,training_id INTEGER NOT NULL,
          player_id INTEGER NOT NULL,rpe INTEGER NOT NULL,minutes INTEGER NOT NULL,wellness INTEGER NOT NULL,note TEXT NOT NULL,
          author_id INTEGER NOT NULL,updated REAL NOT NULL,UNIQUE(training_id,player_id));
        CREATE TABLE IF NOT EXISTS match_player_stats(id INTEGER PRIMARY KEY,season_id INTEGER NOT NULL,selection_id INTEGER NOT NULL,
          player_id INTEGER NOT NULL,minutes INTEGER NOT NULL,goals INTEGER NOT NULL,assists INTEGER NOT NULL,yellow INTEGER NOT NULL,
          red INTEGER NOT NULL,xg REAL NOT NULL,xa REAL NOT NULL,rating REAL,note TEXT NOT NULL,author_id INTEGER NOT NULL,updated REAL NOT NULL,
          UNIQUE(selection_id,player_id));
        CREATE TABLE IF NOT EXISTS progression_reviews(id INTEGER PRIMARY KEY,season_id INTEGER NOT NULL,player_id INTEGER NOT NULL,
          target_team_id INTEGER NOT NULL,reviewed_on TEXT NOT NULL,readiness INTEGER NOT NULL,recommendation TEXT NOT NULL,
          rationale TEXT NOT NULL,decision TEXT NOT NULL,author_id INTEGER NOT NULL,updated REAL NOT NULL);
        ''');db().commit()

    def day(value):
        value=str(value or '')
        try:date.fromisoformat(value)
        except ValueError:abort(400,'Kies een geldige datum.')
        return value
    def integer(value,low,high,label):
        try:value=int(value)
        except (TypeError,ValueError):abort(400,f'Vul een geldige {label} in.')
        if not low<=value<=high:abort(400,f'{label.capitalize()} moet tussen {low} en {high} liggen.')
        return value
    def decimal(value,low,high,label,optional=False):
        if optional and (value is None or str(value).strip()==''):return None
        try:value=round(float(value),2)
        except (TypeError,ValueError):abort(400,f'Vul een geldige {label} in.')
        if not low<=value<=high:abort(400,f'{label.capitalize()} moet tussen {low} en {high} liggen.')
        return value
    def player(key):
        row=db().execute('SELECT p.id,p.name,m.team_id FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=? AND p.id=?',(g.season_id,key)).fetchone()
        if not row or not team_allowed(row['team_id']) or g.user['role']=='player' and key!=g.user['player_id']:abort(404,'Speler niet gevonden.')
        return row
    def staff():
        require('tracking',True)
        if g.user['role']=='player':abort(403,'Alleen bevoegde staf kan het spelersvolgsysteem bijwerken.')
    def owner(table,key):
        row=db().execute(f'SELECT * FROM {table} WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not row:abort(404,'Registratie niet gevonden.')
        player(row['player_id']);return row

    @app.post('/api/tracking/evaluations')
    @protect
    def evaluation_save():
        staff();p=request.get_json();pid=int(p.get('player_id') or 0);player(pid);scores=[integer(p.get(k),1,5,k) for k in ('technical','tactical','physical','mental','social')]
        values=(pid,text(p,'period',120),day(p.get('evaluated_on')),*scores,text(p,'note',5000,False),g.user['id'],time.time());key=int(p.get('id') or 0)
        if key:owner('player_evaluations',key);db().execute('UPDATE player_evaluations SET player_id=?,period=?,evaluated_on=?,technical=?,tactical=?,physical=?,mental=?,social=?,note=?,author_id=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO player_evaluations(season_id,player_id,period,evaluated_on,technical,tactical,physical,mental,social,note,author_id,updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',(g.season_id,*values)).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/tracking/loads')
    @protect
    def load_save():
        staff();p=request.get_json();pid=int(p.get('player_id') or 0);member=player(pid);training=int(p.get('training_id') or 0);event=db().execute('SELECT * FROM trainings WHERE id=? AND season_id=?',(training,g.season_id)).fetchone()
        if not event or event['team_id']!=member['team_id']:abort(400,'Kies een training van het team van deze speler.')
        values=(g.season_id,training,pid,integer(p.get('rpe'),1,10,'RPE'),integer(p.get('minutes'),0,300,'trainingsminuten'),integer(p.get('wellness'),1,5,'fitheid'),text(p,'note',3000,False),g.user['id'],time.time())
        db().execute('INSERT INTO training_loads(season_id,training_id,player_id,rpe,minutes,wellness,note,author_id,updated) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(training_id,player_id) DO UPDATE SET rpe=excluded.rpe,minutes=excluded.minutes,wellness=excluded.wellness,note=excluded.note,author_id=excluded.author_id,updated=excluded.updated',values);db().commit();return jsonify(ok=True)

    @app.post('/api/tracking/matches')
    @protect
    def match_save():
        staff();p=request.get_json();pid=int(p.get('player_id') or 0);member=player(pid);selection=int(p.get('selection_id') or 0);event=db().execute('SELECT * FROM selections WHERE id=? AND season_id=?',(selection,g.season_id)).fetchone()
        if not event or event['team_id']!=member['team_id']:abort(400,'Kies een wedstrijd van het team van deze speler.')
        values=(g.season_id,selection,pid,integer(p.get('minutes'),0,180,'speelminuten'),integer(p.get('goals'),0,30,'doelpunten'),integer(p.get('assists'),0,30,'assists'),integer(p.get('yellow'),0,2,'gele kaarten'),integer(p.get('red'),0,1,'rode kaarten'),decimal(p.get('xg'),0,20,'xG'),decimal(p.get('xa'),0,20,'xA'),decimal(p.get('rating'),1,10,'wedstrijdscore',True),text(p,'note',3000,False),g.user['id'],time.time())
        db().execute('INSERT INTO match_player_stats(season_id,selection_id,player_id,minutes,goals,assists,yellow,red,xg,xa,rating,note,author_id,updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(selection_id,player_id) DO UPDATE SET minutes=excluded.minutes,goals=excluded.goals,assists=excluded.assists,yellow=excluded.yellow,red=excluded.red,xg=excluded.xg,xa=excluded.xa,rating=excluded.rating,note=excluded.note,author_id=excluded.author_id,updated=excluded.updated',values);db().commit();return jsonify(ok=True)

    @app.post('/api/tracking/loads/bulk')
    @protect
    def loads_bulk():
        staff();p=request.get_json();training=int(p.get('training_id') or 0);event=db().execute('SELECT * FROM trainings WHERE id=? AND season_id=?',(training,g.season_id)).fetchone();rows=p.get('rows')
        if not event or not team_allowed(event['team_id']):abort(400,'Kies een geldige training.')
        if not isinstance(rows,list) or not 1<=len(rows)<=100:abort(400,'Kies 1 tot 100 spelers.')
        clean=[];seen=set();now=time.time()
        for row in rows:
            pid=int(row.get('player_id') or 0);member=player(pid)
            if member['team_id']!=event['team_id'] or pid in seen:abort(400,'Controleer de spelerslijst.')
            seen.add(pid);clean.append((g.season_id,training,pid,integer(row.get('rpe'),1,10,'RPE'),integer(row.get('minutes'),0,300,'trainingsminuten'),integer(row.get('wellness'),1,5,'fitheid'),str(row.get('note',''))[:3000],g.user['id'],now))
        db().execute('BEGIN IMMEDIATE');db().executemany('INSERT INTO training_loads(season_id,training_id,player_id,rpe,minutes,wellness,note,author_id,updated) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(training_id,player_id) DO UPDATE SET rpe=excluded.rpe,minutes=excluded.minutes,wellness=excluded.wellness,note=excluded.note,author_id=excluded.author_id,updated=excluded.updated',clean);db().commit();return jsonify(ok=True,count=len(clean))

    @app.post('/api/tracking/matches/bulk')
    @protect
    def matches_bulk():
        staff();p=request.get_json();selection=int(p.get('selection_id') or 0);event=db().execute('SELECT * FROM selections WHERE id=? AND season_id=?',(selection,g.season_id)).fetchone();rows=p.get('rows')
        if not event or not team_allowed(event['team_id']):abort(400,'Kies een geldige wedstrijd.')
        if not isinstance(rows,list) or not 1<=len(rows)<=100:abort(400,'Kies 1 tot 100 spelers.')
        clean=[];seen=set();now=time.time()
        for row in rows:
            pid=int(row.get('player_id') or 0);member=player(pid)
            if member['team_id']!=event['team_id'] or pid in seen:abort(400,'Controleer de spelerslijst.')
            seen.add(pid);clean.append((g.season_id,selection,pid,integer(row.get('minutes'),0,180,'speelminuten'),integer(row.get('goals',0),0,30,'doelpunten'),integer(row.get('assists',0),0,30,'assists'),integer(row.get('yellow',0),0,2,'gele kaarten'),integer(row.get('red',0),0,1,'rode kaarten'),decimal(row.get('xg',0),0,20,'xG'),decimal(row.get('xa',0),0,20,'xA'),decimal(row.get('rating'),1,10,'wedstrijdscore',True),str(row.get('note',''))[:3000],g.user['id'],now))
        db().execute('BEGIN IMMEDIATE');db().executemany('INSERT INTO match_player_stats(season_id,selection_id,player_id,minutes,goals,assists,yellow,red,xg,xa,rating,note,author_id,updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(selection_id,player_id) DO UPDATE SET minutes=excluded.minutes,goals=excluded.goals,assists=excluded.assists,yellow=excluded.yellow,red=excluded.red,xg=excluded.xg,xa=excluded.xa,rating=excluded.rating,note=excluded.note,author_id=excluded.author_id,updated=excluded.updated',clean);db().commit();return jsonify(ok=True,count=len(clean))

    @app.post('/api/tracking/progression')
    @protect
    def progression_save():
        staff();p=request.get_json();pid=int(p.get('player_id') or 0);player(pid);target=int(p.get('target_team_id') or 0)
        if not team_allowed(target) or not db().execute('SELECT 1 FROM teams WHERE id=?',(target,)).fetchone():abort(400,'Kies een geldig doelteam.')
        decision=str(p.get('decision','volgen'))
        if decision not in ('volgen','voordragen','doorstromen','behouden','afwijzen'):abort(400,'Kies een geldige doorstroombeslissing.')
        values=(pid,target,day(p.get('reviewed_on')),integer(p.get('readiness'),1,5,'gereedheid'),text(p,'recommendation',3000),text(p,'rationale',5000),decision,g.user['id'],time.time());key=int(p.get('id') or 0)
        if key:owner('progression_reviews',key);db().execute('UPDATE progression_reviews SET player_id=?,target_team_id=?,reviewed_on=?,readiness=?,recommendation=?,rationale=?,decision=?,author_id=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO progression_reviews(season_id,player_id,target_team_id,reviewed_on,readiness,recommendation,rationale,decision,author_id,updated) VALUES (?,?,?,?,?,?,?,?,?,?)',(g.season_id,*values)).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/tracking/<kind>/<int:key>/delete')
    @protect
    def tracking_delete(kind,key):
        staff();table={'evaluation':'player_evaluations','load':'training_loads','match':'match_player_stats','progression':'progression_reviews'}.get(kind)
        if not table:abort(404)
        owner(table,key);db().execute(f'DELETE FROM {table} WHERE id=?',(key,));db().commit();return jsonify(ok=True)

    def summary():
        if not permitted('tracking'):return {'tracking':{'evaluations':[],'loads':[],'matches':[],'progression':[]}}
        accessible={r['id'] for r in db().execute('SELECT p.id,m.team_id FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=?',(g.season_id,)) if team_allowed(r['team_id']) and (g.user['role']!='player' or r['id']==g.user['player_id'])}
        def rows(query):return [dict(r) for r in db().execute(query,(g.season_id,)) if r['player_id'] in accessible]
        evaluations=rows('SELECT * FROM player_evaluations WHERE season_id=? ORDER BY evaluated_on DESC,id DESC')
        loads=rows('SELECT l.*,t.title,t.starts FROM training_loads l JOIN trainings t ON t.id=l.training_id WHERE l.season_id=? ORDER BY t.starts DESC')
        matches=rows('SELECT m.*,s.opponent,s.kickoff FROM match_player_stats m JOIN selections s ON s.id=m.selection_id WHERE m.season_id=? ORDER BY s.kickoff DESC')
        progression=[] if g.user['role']=='player' else rows('SELECT * FROM progression_reviews WHERE season_id=? ORDER BY reviewed_on DESC,id DESC')
        return {'tracking':{'evaluations':evaluations,'loads':loads,'matches':matches,'progression':progression}}
    return summary
