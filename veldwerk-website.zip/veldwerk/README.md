# Veldwerk — besloten spelervolgsysteem

Deze zelfstandige teamwebsite staat naast de bestaande VoetbalZeeland-redactieapp. Python 3.12+, FFmpeg en FFprobe zijn vereist. Er is geen openbare registratie. Alleen een beheerder kan accounts uitgeven, wachtwoorden opnieuw instellen en accounts blokkeren.

De website heeft een homepagina met voetbalachtergrond en acht onderdelen achter de login: overzicht, teams, spelers, videobibliotheek, ontwikkeloverzicht, toegangsbeheer, clubinstellingen en hulp. De laatste twee beheerschermen voor accounts en instellingen zijn alleen voor de beheerder zichtbaar. Zie [HOSTING.md](HOSTING.md) voor WSGI-hosting, de verwerkingswachtrij en back-ups.

## Installatie en eerste account

```sh
cd /workspace/Home/team_app
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python server.py create-admin --username beheerder
.venv/bin/python server.py
```

Het eerste beheerderswachtwoord wordt interactief en verborgen ingevoerd (minimaal 12 tekens); er zijn geen standaardaccounts of standaardwachtwoorden. Voer de accountopdracht uit voordat de server wordt gestart. Deel nooit wachtwoorden in Git of chat. De lokale server gebruikt poort 8001. De redactieapp blijft op poort 8000 beschikbaar. `TEAM_DATA`, `TEAM_HOST` en `TEAM_PORT` zijn instelbaar. Bewaar een back-up van de volledige datamap, inclusief de SQLite-database én videobestanden.

## Rechten

| Rol | Toegang |
| --- | --- |
| Beheerder | Alle sportgegevens; teams en accounts aanmaken; accounts blokkeren en wachtwoorden instellen |
| Trainer | Alle teams en spelers; spelersprofielen, observaties en video's toevoegen |
| Speler | Eigen profiel, eigen observaties en clips; volledige wedstrijden van het eigen team; alleen lezen |

De server controleert rechten ook op individuele videoverzoeken (inclusief byte-rangeverzoeken). Een clip zonder speler is een trainersclip; alleen als **volledige wedstrijd** gemarkeerde video's zijn voor alle spelers van dat team zichtbaar. Rugnummers 1–99 moeten uniek zijn binnen een team. Beoordelingen zijn handmatige trainersscores.

Wachtwoorden worden met scrypt gehasht. Sessies verlopen na 8 uur, gebruiken HttpOnly/SameSite-cookies en worden na blokkering of wachtwoordreset ingetrokken. Schrijfverzoeken vereisen een CSRF-token. Inloggen is begrensd op 8 mislukte pogingen per 15 minuten per IP-adres. Er is nog geen accountherstel via e-mail; de beheerder stelt een nieuw wachtwoord in.

## Video's en automatisch bijwerken

- Upload geëxporteerde Veo-video's of losse MP4/WebM/MOV-bestanden (maximaal 512 MB per upload). H.264/MP4 heeft de breedste browserondersteuning.
- Koppel beelden aan team, optioneel een speler, teamtaak en teamfunctie.
- Na upload valideert FFprobe de video en start achtergrondanalyse (maximaal 2 gelijktijdig). De analyse meet duur, resolutie en gemiddelde pixelverandering op 1 beeld per seconde in de eerste 120 seconden. Camerabeweging beïnvloedt deze waarde; dit is geen voetbalprestatiemeting.
- Profielen en overzichten laden elke 5 seconden nieuwe gegevens. Ontwikkelscores zijn gemiddelden van de handmatige observaties per onderdeel.
- Trainers kunnen bij het afspelen van een video momenten vastleggen met tijdstip, speler, actie/teamgedrag, beoordeling en feedback. Klik op het tijdstip om terug te springen. Spelers zien uitsluitend hun eigen feedback; markeringen geven geen extra toegang tot een afgeschermde video.
- Het ontwikkeloverzicht bundelt trainersscores en aantallen gemarkeerde momenten. Dit zijn geen automatisch herkende voetbalacties. Teams kunnen worden hernoemd en videogegevens kunnen worden aangepast; toegangsrechten worden daarbij opnieuw gecontroleerd.
- Onderbroken analyses worden bij serverherstart als mislukt gemarkeerd en kunnen opnieuw gestart worden. Dit is een lokale werkqueue, nog geen productiequeue.

## Nog vereist voor de volledige gevraagde automatisering

Automatische herkenning van rugnummers, spelersacties en teamgedrag is **niet** geïmplementeerd. Hiervoor zijn representatieve Veo-beelden, teamopstellingen/wissels, een gevalideerd analysemodel en een geschikte uitvoeromgeving nodig. Een rugnummer in het spelersprofiel identificeert nog geen speler in videobeelden. Er worden geen voetbalgebeurtenissen of spelersscores uit technische beeldverandering afgeleid.

Een directe Veo-koppeling is nog niet aangesloten. Er is nog geen API/feed-toegang vastgesteld; een Veo-account alleen bewijst die toegang niet. Gebruik voorlopig video-export en upload. Geef geen Veo-wachtwoord aan de applicatie.

Automatisch deployen van software is nog niet aangesloten. WSGI-configuratie, een back-upcommando, GitHub CI en Dependabot-configuratie zijn voorbereid. CI en dependency-voorstellen starten pas na push naar GitHub en inschakeling van de betreffende functies. Voor deployment ontbreken het hostingaccount en een daar geteste terugvalprocedure. Er wordt geen onbekende code automatisch uitgevoerd. Nieuwe releases moeten accounts en video's behouden.

## Productie

De ingebouwde server is uitsluitend voor lokale ontwikkeling. Gebruik voor een publieke website een productie-WSGI-server achter HTTPS, zet `TEAM_HTTPS=1` voor Secure-cookies en configureer de proxy met uploadlimieten, opslagquota, back-ups en correcte client-IP-doorgifte voor inloglimieten. `wsgi.py` gebruikt standaard Secure-cookies en uitgestelde analyse (`deferred`). Verwerk die wachtrij met `server.py analyse-pending`; gebruik een ondersteunde planner voor automatische verwerking. Er zijn nog geen productie-auditlog, automatische back-ups of bewaartermijnen. Video's worden lokaal opgeslagen; voor meerdere serverprocessen of grote bibliotheken zijn objectopslag en een duurzame werkqueue nodig.

## Tests

```sh
cd /workspace/Home/team_app
.venv/bin/python -m unittest discover -s tests -v
node --check static/app.js
node --check static/pages.js
```

De tests gebruiken tijdelijke data en een daadwerkelijk met FFmpeg gegenereerde testvideo. Ze controleren onder meer accountrechten, afgeschermde video's, CSRF, sessie-intrekking, rugnummers, uploadvalidatie en de echte achtergrondanalyse. Er is nog geen gevalideerde voetbalinhoudelijke herkenningstest, omdat die functie nog ontbreekt.

## Websitepakket maken

```sh
.venv/bin/python maintenance.py --output /tmp/veldwerk-website.zip
```

Het ZIP-bestand bevat alle benodigde bronbestanden, statische afbeeldingen, tests en de installatiehandleiding. Accounts, databases, videobestanden, virtualenv en caches worden niet meegenomen. Bestaande ZIP-bestanden worden niet overschreven.
