import csv
import io
import unittest

import test_server as fixtures
from permissions import MODULES


class PlanningTests(unittest.TestCase):
    setUpClass=classmethod(fixtures.TeamTests.setUpClass.__func__)
    tearDownClass=classmethod(fixtures.TeamTests.tearDownClass.__func__)
    setUp=fixtures.TeamTests.setUp
    tearDown=fixtures.TeamTests.tearDown
    login=fixtures.TeamTests.login
    post=fixtures.TeamTests.post
    seed_video=fixtures.TeamTests.seed_video

    def training(self,team=1,**extra):
        payload={'team_id':team,'title':'Positiespeltraining','starts':'2999-11-12T19:00','ends':'2999-11-12T20:30','location':'Veld 1','notes':'Vrijlopen en vooruit kijken','exercise_ids':[],**extra}
        response=self.post('/api/trainings',payload)
        self.assertEqual(response.status_code,200,response.json)
        return response.json['id']

    def selection(self,**extra):
        return self.post('/api/selections',{'team_id':1,'opponent':'Tegenstander','kickoff':'2999-11-15T14:30','location':'Thuis','formation':'4-3-3','published':False,'players':[{'player_id':1,'status':'starter','slot':'ST'},{'player_id':2,'status':'bench','slot':''}],**extra})

    def plan(self,player=1,**extra):
        return self.post('/api/plans',{'player_id':player,'title':'Vrijlopen tussen de linies','category':'Tactiek','objective':'Voor de balontvangst kijken','actions':'Tweemaal per week gericht oefenen','success_measure':'Trainer beoordeelt vijf momenten','due_date':'2999-12-01','status':'bezig','evaluation':'','any_unused':'ignored',**extra})

    def test_training_schedule_validation_and_roster(self):
        self.login()
        key=self.training()
        data=self.client.get('/api/dashboard').json
        self.assertEqual(len([a for a in data['attendance'] if a['training_id']==key]),2)
        response=self.post('/api/trainings',{'team_id':1,'title':'Ongeldig','starts':'2999-11-12T19:00','ends':'2999-11-12T18:00'})
        self.assertEqual(response.status_code,400)
        self.assertEqual(len(self.client.get('/api/dashboard').json['trainings']),1)
        self.login('player')
        own=self.client.get('/api/dashboard').json
        self.assertEqual({a['player_id'] for a in own['attendance']},{1})
        self.assertEqual(self.post('/api/trainings',{'team_id':1}).status_code,403)

    def test_availability_is_not_actual_attendance_and_player_cannot_forge_it(self):
        self.login()
        key=self.training()
        self.login('player')
        own={'training_id':key,'player_id':1,'availability':'beschikbaar','note':'Ik kom'}
        self.assertEqual(self.post('/api/attendance',own).status_code,200)
        row=self.client.get('/api/dashboard').json['attendance'][0]
        self.assertEqual(row['attendance'],'onbekend')
        self.assertEqual(self.post('/api/attendance',{**own,'attendance':'aanwezig'}).status_code,403)
        self.assertEqual(self.post('/api/attendance',{**own,'player_id':2}).status_code,403)
        self.login('coach')
        self.assertEqual(self.post('/api/attendance',{**own,'attendance':'aanwezig'}).status_code,200)

    def test_cancelled_and_past_training_cannot_receive_player_responses(self):
        self.login()
        cancelled=self.training(cancelled=True)
        past=self.training(starts='2020-01-01T19:00',ends='2020-01-01T20:30')
        self.login('player')
        for key in (cancelled,past):
            self.assertEqual(self.post('/api/attendance',{'training_id':key,'player_id':1,'availability':'beschikbaar'}).status_code,400)

    def test_draft_selection_hidden_and_published_roster_has_no_private_profile_fields(self):
        self.login()
        response=self.selection()
        self.assertEqual(response.status_code,200,response.json)
        key=response.json['id']
        self.login('player')
        self.assertEqual(self.client.get('/api/dashboard').json['selections'],[])
        self.login('coach')
        self.assertEqual(self.selection(id=key,published=True).status_code,200)
        self.login('player')
        data=self.client.get('/api/dashboard').json
        self.assertEqual(len(data['selections']),1)
        self.assertEqual({r['player_id'] for r in data['selection_players']},{1,2})
        self.assertNotIn('goal',data['selection_players'][1])
        self.assertEqual({p['id'] for p in data['players']},{1})
        self.assertEqual(self.selection(id=key,published=True).status_code,403)

    def test_lineup_rejects_duplicates_foreign_players_and_invalid_positions_atomically(self):
        self.login()
        key=self.selection().json['id']
        invalid=[
            [{'player_id':1,'status':'starter','slot':'ST'},{'player_id':1,'status':'bench','slot':''}],
            [{'player_id':1,'status':'starter','slot':'ST'},{'player_id':2,'status':'starter','slot':'ST'}],
            [{'player_id':3,'status':'starter','slot':'ST'}],
            [{'player_id':1,'status':'starter','slot':'INVALID'}],
        ]
        for players in invalid:
            self.assertEqual(self.selection(id=key,players=players).status_code,400)
        self.assertEqual(len(self.client.get('/api/dashboard').json['selection_players']),2)

    def test_individual_plans_private_and_editable_by_staff(self):
        self.login()
        first=self.plan();second=self.plan(2)
        self.assertEqual(first.status_code,200,first.json)
        self.assertEqual(second.status_code,200,second.json)
        self.login('player')
        rows=self.client.get('/api/dashboard').json['plans']
        self.assertEqual({p['player_id'] for p in rows},{1})
        self.assertEqual(self.plan(id=first.json['id'],status='behaald').status_code,403)
        self.login('coach')
        self.assertEqual(self.plan(id=first.json['id'],status='behaald',evaluation='Doel bereikt').status_code,200)

    def test_reports_use_recorded_attendance_and_ignore_cancelled_unknown_and_excused(self):
        self.login()
        present=self.training()
        absent=self.training()
        excused=self.training()
        unknown=self.training()
        cancelled=self.training(cancelled=True)
        with self.app.app_context():
            db=self.app.db()
            for key,status in [(present,'aanwezig'),(absent,'afwezig'),(excused,'vrijgesteld'),(cancelled,'aanwezig')]:
                db.execute('UPDATE attendance SET attendance=? WHERE training_id=? AND player_id=1',(status,key))
            db.commit()
        rows=self.client.get('/api/reports').json['rows']
        row=next(r for r in rows if r['player_id']==1)
        self.assertEqual((row['present'],row['absent'],row['excused'],row['unknown'],row['percentage']),(1,1,1,1,50.0))
        self.assertEqual(self.client.get('/api/reports?from=2999-12-01&until=2999-01-01').status_code,400)
        self.login('player')
        self.assertEqual([r['player_id'] for r in self.client.get('/api/reports').json['rows']],[1])

    def test_report_csv_escapes_formula_names_and_filters_scope(self):
        self.login()
        with self.app.app_context():
            self.app.db().execute('UPDATE players SET name=? WHERE id=1',('=1+1',))
            self.app.db().commit()
        response=self.client.get('/api/reports.csv?team=1')
        self.assertEqual(response.status_code,200)
        rows=list(csv.reader(io.StringIO(response.data.decode('utf-8-sig')),delimiter=';'))
        self.assertEqual(rows[1][0],"'=1+1")
        self.assertEqual(len(rows),3)
        self.login('player')
        self.assertEqual(self.client.get('/api/reports?team=2').json['rows'],[])

    def test_old_custom_permissions_do_not_silently_gain_new_modules(self):
        self.login()
        coach=next(u for u in self.client.get('/api/users').json if u['username']=='coach')
        permissions={'modules':{'teams':'read','players':'read'},'all_teams':False,'team_ids':[1]}
        self.assertEqual(self.post(f"/api/users/{coach['id']}/manage",{'permissions':permissions}).status_code,200)
        self.login('coach')
        self.assertEqual(self.client.get('/api/dashboard').json['trainings'],[])
        self.assertEqual(self.client.get('/api/reports').status_code,403)
        self.assertEqual(self.plan().status_code,403)

    def test_player_with_read_only_availability_cannot_change_response(self):
        self.login()
        key=self.training()
        player=next(u for u in self.client.get('/api/users').json if u['username']=='player')
        policy={'modules':{m:'read' for m in MODULES},'all_teams':True,'team_ids':[]}
        self.assertEqual(self.post(f"/api/users/{player['id']}/manage",{'permissions':policy}).status_code,200)
        self.login('player')
        self.assertEqual(self.post('/api/attendance',{'training_id':key,'player_id':1,'availability':'beschikbaar'}).status_code,403)

    def test_report_blanks_denied_sections_instead_of_claiming_zero(self):
        self.login()
        coach=next(u for u in self.client.get('/api/users').json if u['username']=='coach')
        policy={'modules':{'players':'read','reports':'read'},'all_teams':False,'team_ids':[1]}
        self.assertEqual(self.post(f"/api/users/{coach['id']}/manage",{'permissions':policy}).status_code,200)
        self.login('coach')
        row=self.client.get('/api/reports').json['rows'][0]
        for column in ('present','absent','percentage','selections','plans','videos'):
            self.assertEqual(row[column],'')

    def test_training_editor_without_exercise_access_preserves_hidden_links(self):
        self.login()
        exercise={'title':'Passvorm','category':'Opbouwen','minutes':15,'description':'Speel in tweetallen'}
        self.assertEqual(self.post('/api/exercises',exercise).status_code,200)
        eid=self.client.get('/api/dashboard').json['exercises'][0]['id']
        key=self.training(exercise_ids=[eid])
        coach=next(u for u in self.client.get('/api/users').json if u['username']=='coach')
        policy={'modules':{'training':'write'},'all_teams':False,'team_ids':[1]}
        self.assertEqual(self.post(f"/api/users/{coach['id']}/manage",{'permissions':policy}).status_code,200)
        self.login('coach')
        self.training(id=key,title='Aangepaste titel',exercise_ids=[])
        self.login()
        self.assertEqual(self.client.get('/api/dashboard').json['training_exercises'],[{'training_id':key,'exercise_id':eid}])

    def test_video_labels_can_be_empty_and_new_exercise_categories_are_saved(self):
        self.login()
        response=self.client.post('/api/videos',data={'title':'Zonder labels','team_id':'1','kind':'clip','file':(io.BytesIO(self.video.read_bytes()),'sample.mp4')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,201,response.json)
        row=self.client.get('/api/dashboard').json['videos'][0]
        self.assertEqual((row['task'],row['function']),('',''))
        self.assertEqual(self.post('/api/videos/'+row['id']+'/details',{'title':'Nieuw','task':'','function':'','kind':'clip','category':'Techniek'}).status_code,200)
        exercise={'title':'Passvorm','category':'','theme':'Passvormen','age_group':'JO13','minutes':15,'description':'Speel in tweetallen'}
        self.assertEqual(self.post('/api/exercises',exercise).status_code,200)
        saved=self.client.get('/api/dashboard').json['exercises'][0]
        self.assertEqual((saved['category'],saved['theme'],saved['age_group']),('','Passvormen','JO13'))
