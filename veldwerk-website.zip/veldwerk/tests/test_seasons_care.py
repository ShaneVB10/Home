import unittest,json
from pathlib import Path
import test_server as f
import test_planning as pl
from server import create_app

class SeasonCareTests(unittest.TestCase):
    setUpClass=classmethod(f.TeamTests.setUpClass.__func__)
    tearDownClass=classmethod(f.TeamTests.tearDownClass.__func__)
    setUp=f.TeamTests.setUp
    tearDown=f.TeamTests.tearDown
    login=f.TeamTests.login
    post=f.TeamTests.post
    seed_video=f.TeamTests.seed_video
    training=pl.PlanningTests.training
    selection=pl.PlanningTests.selection

    def season(self,copy=True):
        r=self.post('/api/seasons',dict(name='2027/2028',starts='2027-07-01',ends='2028-06-30',copy_roster_from=1 if copy else 0))
        self.assertEqual(r.status_code,200,r.json);return r.json['id']

    def permissions(self,modules,teams=[1]):
        with self.app.app_context():
            self.app.db().execute("UPDATE users SET permissions=? WHERE username='coach'",(json.dumps(dict(modules=modules,all_teams=False,team_ids=teams)),));self.app.db().commit()

    def test_history_video_roster_restart(self):
        self.login();key=self.training();self.seed_video('old',1,1);self.selection();new=self.season()
        r=self.post(f'/api/players?season={new}',dict(id=1,team_id=2,name='Speler A',shirt_number=11));self.assertEqual(r.status_code,200,r.json)
        old=self.client.get('/api/dashboard?season=1').json;current=self.client.get(f'/api/dashboard?season={new}').json
        self.assertEqual(old['players'][0]['team_id'],1);self.assertEqual(current['players'][0]['team_id'],2)
        self.assertEqual(len(old['videos']),1);self.assertEqual(current['videos'],[]);self.assertEqual(current['selections'],[])
        self.assertEqual(self.client.get(f'/media/old?season={new}').status_code,404)
        r=self.client.get('/media/old?season=1');self.assertEqual(r.status_code,200);r.close()
        r=self.post(f'/api/trainings?season={new}',dict(id=key,team_id=1,title='x',starts='2027-08-01T19:00',ends='2027-08-01T20:00',cancelled=False));self.assertEqual(r.status_code,404,r.json)
        app=create_app(self.temp.name,testing=True);app.analysis_workers.shutdown(wait=True)
        self.assertTrue((Path(self.temp.name)/'videos/old.mp4').exists())

    def test_archive_and_jersey(self):
        self.login();new=self.season(False)
        self.assertEqual(self.post(f'/api/players?season={new}',dict(team_id=1,name='Nieuw',shirt_number=9)).status_code,200)
        self.assertEqual(self.post('/api/seasons/1',dict(archived=True)).status_code,400)
        self.post(f'/api/seasons/{new}',dict(active=True));self.post('/api/seasons/1',dict(archived=True))
        self.assertEqual(self.post('/api/players?season=1',dict(team_id=1,name='x')).status_code,403)
        self.assertEqual(self.post('/api/medical/measurements?season=1',{}).status_code,403)
        self.assertEqual(self.post('/api/seasons/1',dict(archived=False)).status_code,200)

    def series(self):
        return dict(title='Training',**{'from':'2027-08-02'},until='2027-08-15',exclude_dates=['2027-08-05'],schedules=[dict(team_id=t,weekdays=[1,3],start_time='19:30',end_time='21:00',location='Veld') for t in [1,2]])

    def test_recurrence_preview_idempotence_preserves_attendance(self):
        self.login();p=self.series();r=self.post('/api/trainings/series/preview',p);self.assertEqual(r.status_code,200,r.json);self.assertEqual(r.json['create_count'],6)
        self.assertEqual(self.client.get('/api/dashboard').json['trainings'],[])
        r=self.post('/api/trainings/series',p).json;key=r['created_ids'][0]
        self.assertEqual(self.post('/api/trainings/series',p).json['create_count'],0)
        self.post('/api/attendance',dict(training_id=key,player_id=1,attendance='aanwezig',note='Blijft'))
        edit=dict(team_ids=[1],start_time='20:00',end_time='21:30',title='Nieuw',cancelled=False,**{'from':'2027-08-02'})
        response=self.post('/api/trainings/series/'+r['series_id']+'/edit',edit);self.assertEqual(response.status_code,200,response.json)
        row=next(a for a in self.client.get('/api/dashboard').json['attendance'] if a['training_id']==key and a['player_id']==1)
        self.assertEqual(row['note'],'Blijft');self.assertEqual(row['attendance'],'aanwezig')

    def test_series_atomic_scope(self):
        self.permissions({'training':'write'});self.login('coach')
        self.assertEqual(self.post('/api/trainings/series',self.series()).status_code,403)
        self.assertEqual(self.client.get('/api/dashboard').json['trainings'],[])

    def test_bulk_undo_concurrency(self):
        self.login();key=self.training();self.post('/api/attendance',dict(training_id=key,player_id=2,availability='geblesseerd',note='Rust'))
        bulk=self.post('/api/attendance/bulk',dict(training_id=key,action='present_unmarked')).json;self.assertEqual(bulk['count'],1)
        self.assertEqual(self.post('/api/attendance/bulk',dict(training_id=key,action='undo',changes=bulk['changes'])).status_code,200)
        row=self.client.get('/api/dashboard').json['attendance'][0]
        self.post('/api/attendance',dict(training_id=key,player_id=1,attendance='afwezig'))
        self.assertEqual(self.post('/api/attendance',dict(training_id=key,player_id=1,note='stale',expected_updated=row['updated'])).status_code,409)
        self.login('player');self.assertEqual(self.post('/api/attendance/bulk',dict(training_id=key,action='present_unmarked')).status_code,403)

    def test_observation_restore_statuses_formations(self):
        self.login();self.post('/api/observations',dict(player_id=1,rating=4,category='Tactiek',note='Bewaren'))
        key=self.client.get('/api/dashboard').json['observations'][0]['id'];self.post(f'/api/observations/{key}/delete',{})
        self.assertEqual(self.client.get('/api/dashboard').json['observations'],[])
        new=self.season();self.assertEqual(self.post(f'/api/observations/{key}/restore?season={new}',{}).status_code,404)
        self.assertEqual(self.post(f'/api/observations/{key}/restore',{}).status_code,200)
        data=self.client.get('/api/dashboard').json;self.assertGreaterEqual(len(data['formations']),18)
        for name,slots in data['formations'].items():self.assertEqual(len(set(slots)),11,name)
        for status in ['reserve','bench','second_team','not_selected']:
            r=self.selection(players=[dict(player_id=1,status=status,slot='')],formation='5-2-3');self.assertEqual(r.status_code,200,r.json)
        self.login('player');self.assertEqual(self.post(f'/api/observations/{key}/delete',{}).status_code,403)

    def test_medical_explicit_scoped_read_write(self):
        self.login('coach');self.assertEqual(self.client.get('/api/medical').status_code,403)
        self.permissions({'medical':'write'});self.login('coach')
        r=self.post('/api/medical/measurements',dict(player_id=1,measured_on='2027-08-01',weight=76.5,height=180));self.assertEqual(r.status_code,200,r.json)
        self.assertEqual(self.post('/api/medical/measurements',dict(player_id=3,measured_on='2027-08-01',weight=70)).status_code,403)
        dashboard=self.client.get('/api/dashboard').json;self.assertEqual(dashboard['players'],[]);self.assertNotIn('measurements',dashboard)
        self.assertEqual({p['id'] for p in self.client.get('/api/medical').json['players']},{1,2})
        self.permissions({'medical':'read'});self.assertEqual(self.post('/api/medical/measurements',dict(player_id=1)).status_code,403)
        self.login('player');self.assertEqual(self.client.get('/api/medical').status_code,403)

    def test_medical_history_edits_and_cross_season(self):
        self.login();base=dict(player_id=1,title='Enkelklacht',body_part='Enkel',started='2027-08-01',phase='Revalidatie',restrictions='Geen duels',next_review='2027-08-08')
        r=self.post('/api/medical/injuries',base);self.assertEqual(r.status_code,200,r.json);key=r.json['id']
        self.assertEqual(self.post('/api/medical/reviews',dict(injury_id=key,reviewed_on='2027-08-03',note='Minder klachten',actions='Balans')).status_code,200)
        self.assertEqual(self.post('/api/medical/injuries',{**base,'id':key,'phase':'Volledig inzetbaar','closed_on':'2027-08-09'}).status_code,200)
        history=self.client.get('/api/medical').json;self.assertEqual(history['injuries'][0]['closed_on'],'2027-08-09');self.assertEqual(len(history['reviews']),1)
        new=self.season();self.assertEqual(self.client.get(f'/api/medical?season={new}').json['injuries'],[])
        self.assertEqual(self.post(f'/api/medical/reviews?season={new}',dict(injury_id=key,reviewed_on='2027-08-10',note='x')).status_code,404)

    def test_staff_presence_and_folders(self):
        self.login();key=self.training();r=self.post('/api/staff',dict(name='Fysio',role='Medisch',team_ids=[1]));self.assertEqual(r.status_code,200,r.json)
        payload=dict(kind='training',event_id=key,staff_id=r.json['id'],present=True)
        self.assertEqual(self.post('/api/staff/presence',payload).status_code,200)
        self.assertEqual(self.client.get('/api/dashboard').json['staff_presence'][0]['present'],1)
        new=self.season();self.assertEqual(len(self.client.get(f'/api/dashboard?season={new}').json['staff']),1)
        self.assertEqual(self.post(f'/api/staff/presence?season={new}',payload).status_code,404)
        for t in [None,1,2]:self.assertEqual(self.post('/api/exercises',dict(title=str(t),category='Opbouwen',description='Beschrijving',minutes=20,team_id=t)).status_code,200)
        self.permissions({'exercises':'write','staff':'write'});self.login('coach');data=self.client.get('/api/dashboard').json
        self.assertEqual({e['team_id'] for e in data['exercises']},{None,1})
        self.assertEqual(self.post('/api/exercises',dict(id=3,title='x',description='y',minutes=20,team_id=1)).status_code,403)
        self.assertEqual(self.post('/api/staff/presence',payload).status_code,403)

    def test_csv_standings_replace_only_selected_season(self):
        import io
        self.login()
        def upload(season,club):
            return self.client.post(f'/api/football/import?season={season}',data={'team_id':'1','kind':'standings','file':(io.BytesIO(f'ploeg;positie;gespeeld;punten\n{club};1;4;12\n'.encode()),'stand.csv')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(upload(1,'Oude club').status_code,200)
        new=self.season();self.assertEqual(upload(new,'Nieuwe club').status_code,200)
        self.assertEqual([r['club'] for r in self.client.get('/api/dashboard?season=1').json['standings']],['Oude club'])
        self.assertEqual([r['club'] for r in self.client.get(f'/api/dashboard?season={new}').json['standings']],['Nieuwe club'])
        self.assertEqual(self.client.get('/api/medical').headers['Cache-Control'],'no-store')
