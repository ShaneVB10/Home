import io
import json
import sqlite3
import subprocess
import tempfile
import time
import unittest
import os
import sys
import zipfile
from unittest.mock import patch
from pathlib import Path
from werkzeug.security import generate_password_hash

from server import create_app
from maintenance import backup, package


class TeamTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.video_dir = tempfile.TemporaryDirectory()
        cls.video = Path(cls.video_dir.name) / 'sample.mp4'
        subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=160x90:rate=10','-t','2','-c:v','libx264','-pix_fmt','yuv420p',str(cls.video)], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.video_dir.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.app = create_app(self.temp.name, testing=True)
        self.client = self.app.test_client()
        with self.app.app_context():
            db = self.app.db()
            db.executemany('INSERT INTO teams(id,name) VALUES (?,?)', [(1,'Team A'),(2,'Team B')])
            db.executemany('INSERT INTO players(id,team_id,name,shirt_number) VALUES (?,?,?,?)', [(1,1,'Speler A',9),(2,1,'Speler B',10),(3,2,'Speler C',9)])
            for username, role, player in [('owner','admin',None),('coach','trainer',None),('player','player',1)]:
                db.execute('INSERT INTO users(username,password,role,player_id) VALUES (?,?,?,?)', (username,generate_password_hash('test-password-only-2026'),role,player))
            db.commit()

    def tearDown(self):
        self.app.analysis_workers.shutdown(wait=True)
        self.temp.cleanup()

    def login(self, name='owner'):
        response = self.client.post('/api/login', json={'username':name,'password':'test-password-only-2026'})
        self.assertEqual(response.status_code, 200)
        self.csrf = self.client.get('/api/me').json['csrf']
        return response

    def post(self, path, payload):
        return self.client.post(path,json=payload,headers={'X-CSRF-Token':self.csrf})

    def seed_video(self, key, team, player, kind='clip'):
        with self.app.app_context():
            self.app.db().execute('INSERT INTO videos(id,team_id,player_id,title,task,function,kind,filename,created) VALUES (?,?,?,?,?,?,?,?,?)', (key,team,player,key,'Opbouw','Aanvallen',kind,key+'.mp4',time.time()))
            self.app.db().commit()
        (Path(self.temp.name)/'videos'/f'{key}.mp4').write_bytes(self.video.read_bytes())

    def test_auth_cookie_and_csrf(self):
        self.assertEqual(self.client.get('/api/dashboard').status_code,401)
        response = self.login()
        self.assertIn('HttpOnly',response.headers['Set-Cookie'])
        self.assertIn('SameSite=Strict',response.headers['Set-Cookie'])
        self.assertEqual(self.client.post('/api/teams',json={'name':'Invalid'}).status_code,403)
        self.assertEqual(self.post('/api/teams',{'name':'Team C'}).status_code,200)
        self.assertEqual(self.post('/api/logout',{}).status_code,200)
        self.assertEqual(self.client.get('/api/me').status_code,401)

    def test_players_only_own_clips_and_full_matches(self):
        for args in [('own',1,1,'clip'),('other',1,2,'clip'),('match',1,None,'match'),('foreign',2,3,'match'),('teamclip',1,None,'clip')]:
            self.seed_video(*args)
        self.login('player')
        data = self.client.get('/api/dashboard').json
        self.assertEqual([p['id'] for p in data['players']],[1])
        self.assertEqual({v['id'] for v in data['videos']},{'own','match'})
        self.assertEqual(self.client.get('/media/other').status_code,403)
        self.assertEqual(self.client.get('/media/foreign').status_code,403)
        self.assertEqual(self.client.get('/media/teamclip').status_code,403)
        response = self.client.get('/media/match',headers={'Range':'bytes=0-99'})
        self.assertEqual(response.status_code,206)
        response.close()
        self.assertEqual(self.post('/api/observations',{'player_id':1,'rating':5,'category':'Tactiek','note':'x'}).status_code,403)
        self.assertEqual(self.client.get('/api/users').status_code,403)

    def test_trainers_can_see_all_teams_but_not_manage_users(self):
        self.login('coach')
        data = self.client.get('/api/dashboard').json
        self.assertEqual(len(data['teams']),2)
        self.assertEqual(len(data['players']),3)
        self.assertEqual(self.post('/api/observations',{'player_id':3,'rating':4,'category':'Tactiek','note':'Goed vrijlopen'}).status_code,200)
        self.assertEqual(self.post('/api/users',{'username':'x'}).status_code,403)

    def test_account_block_revokes_session(self):
        self.login()
        payload = {'username':'newplayer','password':'another-test-password','role':'player','player_id':2}
        self.assertEqual(self.post('/api/users',payload).status_code,200)
        other = self.app.test_client()
        other.post('/api/login',json={'username':'newplayer','password':payload['password']})
        self.assertEqual(other.get('/api/me').status_code,200)
        users = self.client.get('/api/users').json
        account = next(u for u in users if u['username']=='newplayer')
        self.assertNotIn('password',account)
        self.assertEqual(self.post(f"/api/users/{account['id']}/manage",{'active':False}).status_code,200)
        self.assertEqual(other.get('/api/me').status_code,401)

    def test_numbers_unique_within_team(self):
        self.login()
        payload = {'name':'Nieuwe speler','team_id':1,'shirt_number':9}
        self.assertEqual(self.post('/api/players',payload).status_code,400)
        self.assertEqual(self.post('/api/players',{**payload,'shirt_number':11}).status_code,200)

    def test_real_video_upload_and_automatic_analysis(self):
        self.login()
        response = self.client.post('/api/videos',data={'title':'Testclip','team_id':'1','player_id':'1','function':'Aanvallen','task':'Opbouw','kind':'clip','file':(io.BytesIO(self.video.read_bytes()),'test.mp4')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,201,response.json)
        key = response.json['id']
        deadline = time.time()+15
        while time.time()<deadline:
            videos = self.client.get('/api/dashboard').json['videos']
            result = next(v for v in videos if v['id']==key)
            if result['state'] in ('done','failed'):
                break
            time.sleep(.1)
        self.assertEqual(result['state'],'done',result)
        self.assertEqual(result['analysis']['width'],160)
        self.assertGreater(result['analysis']['duration'],1)
        self.assertGreater(result['analysis']['frame_change_percent'],0)
        self.assertNotIn('filename',result)
        media = self.client.get('/media/'+key)
        self.assertEqual(media.status_code,200)
        media.close()

    def test_invalid_video_does_not_leave_files(self):
        self.login()
        response = self.client.post('/api/videos',data={'title':'Bad','team_id':'1','function':'Aanvallen','task':'Opbouw','file':(io.BytesIO(b'not video'),'fake.mp4')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,400)
        self.assertEqual(list((Path(self.temp.name)/'videos').iterdir()),[])

    def test_login_throttling_and_no_registration(self):
        for _ in range(8):
            self.assertEqual(self.client.post('/api/login',json={'username':'missing','password':'incorrect'}).status_code,401)
        self.assertEqual(self.client.post('/api/login',json={'username':'missing','password':'incorrect'}).status_code,429)
        self.assertEqual(self.client.post('/api/register',json={}).status_code,404)

    def test_cross_origin_login_and_json_shape_rejected(self):
        response = self.client.post('/api/login',json={'username':'owner','password':'test-password-only-2026'},headers={'Origin':'https://other.example'})
        self.assertEqual(response.status_code,403)
        self.assertEqual(self.client.post('/api/login',json=[]).status_code,400)

    def test_password_reset_revokes_other_sessions(self):
        self.login()
        other = self.app.test_client()
        other.post('/api/login',json={'username':'coach','password':'test-password-only-2026'})
        account = next(u for u in self.client.get('/api/users').json if u['username']=='coach')
        self.assertEqual(self.post(f"/api/users/{account['id']}/manage",{'password':'new-test-password-2026'}).status_code,200)
        self.assertEqual(other.get('/api/me').status_code,401)
        self.assertEqual(other.post('/api/login',json={'username':'coach','password':'new-test-password-2026'}).status_code,200)

    def test_moments_validate_time_and_protect_player_feedback(self):
        self.seed_video('match',1,None,'match')
        self.login()
        payload = dict(video_id='match', player_id=1, second=.5, label='Pass', outcome='geslaagd', note='Goed gezien')
        self.assertEqual(self.post('/api/moments',payload).status_code,200)
        self.assertEqual(self.post('/api/moments',{**payload,'player_id':2,'note':'Andere speler'}).status_code,200)
        for changes in ({'second':5},{'second':-1},{'second':float('nan')},{'player_id':3},{'outcome':'ongekend'}):
            self.assertEqual(self.post('/api/moments',{**payload,**changes}).status_code,400)
        self.login('player')
        moments = self.client.get('/api/dashboard').json['moments']
        self.assertEqual(len(moments),1)
        self.assertEqual(moments[0]['note'],'Goed gezien')
        self.assertEqual(self.post('/api/moments',payload).status_code,403)

    def test_team_settings_and_system_are_admin_only(self):
        self.login()
        self.assertEqual(self.post('/api/teams',{'id':1,'name':'Nieuwe teamnaam'}).status_code,200)
        self.assertEqual(self.post('/api/settings',{'club_name':'Testclub','season':'2026/2027'}).status_code,200)
        self.assertEqual(self.client.get('/api/system').json['accounts'],3)
        self.login('coach')
        self.assertEqual(self.post('/api/teams',{'id':1,'name':'Onbevoegd'}).status_code,403)
        self.assertEqual(self.post('/api/settings',{'club_name':'Onbevoegd'}).status_code,403)
        self.assertEqual(self.client.get('/api/system').status_code,403)
        data = self.client.get('/api/dashboard').json
        self.assertEqual(data['settings']['club_name'],'Testclub')
        self.assertEqual(data['teams'][0]['name'],'Nieuwe teamnaam')

    def test_video_edit_changes_access_immediately(self):
        self.seed_video('own',1,1,'clip')
        self.login()
        payload = dict(title='Gewijzigde clip',player_id=2,kind='clip',function='Verdedigen',task='Drukzetten')
        self.assertEqual(self.post('/api/videos/own/details',payload).status_code,200)
        self.assertEqual(self.post('/api/videos/own/details',{**payload,'player_id':3}).status_code,400)
        self.login('player')
        self.assertEqual(self.client.get('/media/own').status_code,403)
        self.assertEqual(self.post('/api/videos/own/details',payload).status_code,403)

    def test_deferred_queue_can_be_processed_without_web_threads(self):
        self.app.analysis_workers.shutdown(wait=True)
        with patch.dict(os.environ,{'TEAM_ANALYSIS_MODE':'deferred'}):
            self.app = create_app(self.temp.name, testing=True)
        self.client = self.app.test_client()
        self.login()
        response = self.client.post('/api/videos',data={'title':'Deferred','team_id':'1','function':'Aanvallen','task':'Opbouw','file':(io.BytesIO(self.video.read_bytes()),'test.mp4')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,201,response.json)
        key = response.json['id']
        self.assertEqual(self.client.get('/api/dashboard').json['videos'][0]['state'],'queued')
        self.app.analyse(key)
        self.assertEqual(self.client.get('/api/dashboard').json['videos'][0]['state'],'done')

    def test_backup_restores_database_and_referenced_video(self):
        self.seed_video('backup-video',1,1,'clip')
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder)/'backup.zip'
            backup(Path(self.temp.name),output)
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(set(archive.namelist()),{'data/teams.db','data/videos/backup-video.mp4'})
                archive.extractall(Path(folder)/'restored')
            with sqlite3.connect(Path(folder)/'restored/data/teams.db') as db:
                self.assertEqual(db.execute('SELECT COUNT(*) FROM users').fetchone()[0],3)
            self.assertEqual((Path(folder)/'restored/data/videos/backup-video.mp4').read_bytes(),self.video.read_bytes())
            with self.assertRaises(FileExistsError):
                backup(Path(self.temp.name),output)

    def test_source_package_contains_site_but_no_private_data(self):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder)/'site.zip'
            package(output)
            with zipfile.ZipFile(output) as archive:
                names = archive.namelist()
                self.assertIn('veldwerk/static/football-bg.webp',names)
                self.assertIn('veldwerk/wsgi.py',names)
                self.assertIn('veldwerk/HOSTING.md',names)
                self.assertFalse(any('/data/' in name or '/.venv/' in name or name.endswith('.db') for name in names))

    def test_wsgi_startup_keeps_data_and_creates_no_accounts(self):
        with tempfile.TemporaryDirectory() as folder:
            script = "from wsgi import application; assert application.config['ANALYSIS_MODE']=='deferred'; assert application.test_client().get('/').status_code==200; assert application.test_client().get('/api/dashboard').status_code==401; application.analysis_workers.shutdown(wait=True)"
            result = subprocess.run([sys.executable,'-c',script],cwd=Path(__file__).parent.parent,env={**os.environ,'TEAM_DATA':folder,'TEAM_ANALYSIS_MODE':'deferred'},capture_output=True,text=True,timeout=20)
            self.assertEqual(result.returncode,0,result.stderr)
            with sqlite3.connect(Path(folder)/'teams.db') as db:
                self.assertEqual(db.execute('SELECT COUNT(*) FROM users').fetchone()[0],0)


if __name__ == '__main__':
    unittest.main()
