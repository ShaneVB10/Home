(() => {
  let installPrompt = null, registration = null, refreshAfterUpdate = false;
  const buttons = [...document.querySelectorAll('[data-pwa-install]')];
  const dialog = document.querySelector('#pwa-dialog');
  const standalone = () => window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  function updateButtons() {
    buttons.forEach(button => button.hidden = standalone());
  }
  updateButtons();
  window.matchMedia('(display-mode: standalone)').addEventListener('change', updateButtons);
  window.addEventListener('appinstalled', () => { installPrompt = null; buttons.forEach(button => button.hidden = true); dialog.close(); });
  window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; });

  buttons.forEach(button => button.addEventListener('click', async () => {
    if (installPrompt) {
      const prompt = installPrompt;
      installPrompt = null;
      button.disabled = true;
      try { await prompt.prompt(); await prompt.userChoice; }
      catch { dialog.showModal(); }
      finally { button.disabled = false; }
    } else {
      dialog.showModal();
    }
  }));
  document.querySelector('[data-pwa-close]').addEventListener('click', () => dialog.close());

  document.querySelector('#pwa-update-button').addEventListener('click', () => {
    if (registration?.waiting) {
      refreshAfterUpdate = true;
      registration.waiting.postMessage({type: 'SKIP_WAITING'});
    } else {
      window.location.reload();
    }
  });

  if ('serviceWorker' in navigator && window.isSecureContext) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (refreshAfterUpdate) window.location.reload();
    });
    window.addEventListener('load', async () => {
      try {
        registration = await navigator.serviceWorker.register('/sw.js', {scope: '/', updateViaCache: 'none'});
        const notify = () => document.querySelector('#pwa-update').hidden = false;
        if (registration.waiting) notify();
        registration.addEventListener('updatefound', () => {
          const worker = registration.installing;
          worker?.addEventListener('statechange', () => {
            if (worker.state === 'installed' && navigator.serviceWorker.controller) notify();
          });
        });
      } catch {
        document.querySelector('#pwa-status').textContent = 'De appfunctie kon niet worden geladen. Vernieuw de pagina en probeer opnieuw. Je kunt de website gewoon blijven gebruiken.';
      }
    });
  } else {
    document.querySelector('#pwa-status').textContent = 'Gebruik een browser met appondersteuning en open Veldwerk via HTTPS.';
  }
})();
