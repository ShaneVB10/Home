/* Only the public offline notice is cached. Never cache app pages or team data. */
const OFFLINE_CACHE = 'veldwerk-offline-v1';
const OFFLINE_FILES = ['/static/offline.html', '/static/offline.css', '/static/icons/icon-192.png'];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(OFFLINE_CACHE).then(cache => cache.addAll(OFFLINE_FILES)));
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('veldwerk-offline-') && key !== OFFLINE_CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (OFFLINE_FILES.includes(url.pathname) && !url.search) {
    event.respondWith((async () => {
      const cache = await caches.open(OFFLINE_CACHE);
      return await cache.match(url.pathname) || fetch(request);
    })());
  } else if (request.mode === 'navigate' && url.pathname === '/') {
    event.respondWith(fetch(request).catch(async () => {
      const cache = await caches.open(OFFLINE_CACHE);
      return await cache.match('/static/offline.html') || new Response('Je bent offline. Maak verbinding om Veldwerk te gebruiken.', {status: 503, headers: {'Content-Type': 'text/plain; charset=utf-8'}});
    }));
  }
});
