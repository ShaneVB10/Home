# De volledige website installeren

Het websitepakket bevat de homepagina, login, teambeheer, spelersprofielen, videobibliotheek, videomomenten, ontwikkeloverzicht, accountbeheer, clubinstellingen en hulp. Het bevat geen bestaande accounts, wachtwoorden, database, video's of Python-omgeving.

## Lokaal starten

Pak het ZIP-bestand uit en open een terminal in de map `veldwerk`:

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python server.py create-admin --username beheerder
.venv/bin/python server.py
```

Op Windows gebruik je `.venv\Scripts\python` in plaats van `.venv/bin/python`. De beheerder kiest het eerste wachtwoord via verborgen terminalinvoer; er is geen standaardaccount. FFmpeg en FFprobe moeten beschikbaar zijn om video's te uploaden en analyseren. Zonder deze programma's blijven accounts, teams en observaties bruikbaar.

## PythonAnywhere of andere WSGI-hosting

De WSGI-ingang is voorbereid, maar de website is niet naar een hostingaccount geplaatst of daar getest. Controleer de actuele opslag-, upload-, CPU- en proceslimieten van het gekozen abonnement. Gratis hosting is bedoeld voor een kleine proefversie, niet voor een grote Veo-bibliotheek of voortdurende analyse.

1. Upload en pak de broncode uit in je eigen account.
2. Maak via een Bash-console een virtualenv met een ondersteunde Python-versie (3.12+) en installeer `requirements.txt`.
3. Maak via die console je beheerdersaccount aan met `server.py create-admin`. Gebruik de virtualenv-Python en geef het wachtwoord niet mee als commandoregelargument.
4. Maak een Python/Flask-webapp met handmatige WSGI-configuratie en wijs de virtualenv toe.
5. Plaats in het WSGI-configuratiebestand van je host:

```python
import os
import sys

project_dir = '/home/JOUW_GEBRUIKERSNAAM/veldwerk'
sys.path.insert(0, project_dir)
os.environ['TEAM_DATA'] = project_dir + '/data'
os.environ['TEAM_HTTPS'] = '1'
os.environ['TEAM_ANALYSIS_MODE'] = 'deferred'

from wsgi import application
```

6. Vervang het projectpad door je echte pad. Activeer HTTPS voor het subdomein van je host en herlaad de webapp. `Secure`-cookies vereisen HTTPS.
7. Test de homepagina, inloggen, accountuitgifte en het aanmaken van een team. Controleer dat een bezoeker zonder login het dashboard niet krijgt en een speler geen beelden van anderen kan openen.

Je hoeft statische bestanden niet apart te publiceren: Flask bedient `/static/`. Publiceer de map `data` nooit als statische map. De videoroute controleert per verzoek de accountrechten.

### Videoanalyse op gedeelde hosting

`wsgi.py` gebruikt standaard `TEAM_ANALYSIS_MODE=deferred`: uploads worden in de database klaargezet, niet in een onbetrouwbare achtergrondthread van de webserver. Als FFprobe beschikbaar is, kunnen video's na upload al worden afgespeeld. Verwerk de wachtrij via een console of ondersteunde taakplanner:

```sh
TEAM_DATA=/home/JOUW_GEBRUIKERSNAAM/veldwerk/data .venv/bin/python server.py analyse-pending
```

Automatisch uitvoeren vereist een taakplanner of worker die jouw abonnement ondersteunt. De gratis variant biedt die mogelijkheid mogelijk niet. Gebruik één wachtrijverwerker tegelijk. De lokale ontwikkelserver gebruikt standaard `background` en start analyses automatisch. Een productie-installatie met meer processen vraagt een echte werkqueue. Wissel niet naar `background` op een host die achtergrondthreads niet ondersteunt.

De analyse meet technische beeldgegevens, geen voetbalacties of rugnummers. Veo-import en voetbalinhoudelijke herkenning zijn nog niet gekoppeld.

## Back-ups en updates

Maak een lokale back-up voordat je een update plaatst:

```sh
.venv/bin/python server.py backup --output /een/prive/map/veldwerk-backup.zip
```

Deze opdracht maakt een consistente SQLite-kopie en neemt alle door de database gebruikte video's mee. Het bestand bevat gevoelige teamgegevens en wachtwoordhashes: bewaar het privé, buiten publiek bereik. Voor herstel: stop de website en worker, bewaar de huidige datamap, en pak de back-up uit in de installatiemap zodat `data/teams.db` en `data/videos/` worden hersteld. Herstart en controleer rechten, accounts en video's.

Installeer een nieuwe versie door code en statische bestanden bij te werken; behoud je volledige `data`-map. Installeer dependencies opnieuw en voer de tests uit met tijdelijke testdata. Herlaad daarna de webapp. Automatisch deployen is nog niet ingesteld: daarvoor ontbreken hostingtoegang, een releasekanaal en een terugvalprocedure die op die host is getest.

De repository bevat CI voor tests en Dependabot voor voorgestelde dependency-updates. Deze werken pas nadat de bestanden naar GitHub zijn gepusht en de functies zijn ingeschakeld. Ze publiceren de website niet automatisch.
