"""Scoped staff directory and separately authorized medical records."""
import time
from datetime import date
from flask import abort,g,jsonify,request

PHASES=('Nieuw','Behandeling','Revalidatie','Aangepaste training','Volledig inzetbaar')

def register_care(app,db,protect,require,permitted,team_allowed,text):
    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY,name TEXT NOT NULL,role TEXT NOT NULL,
          email TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL DEFAULT '');
        CREATE TABLE IF NOT EXISTS season_staff(season_id INTEGER NOT NULL REFERENCES seasons(id),
          staff_id INTEGER NOT NULL REFERENCES staff(id),team_id INTEGER NOT NULL REFERENCES teams(id),
          PRIMARY KEY(season_id,staff_id,team_id));
        CREATE TABLE IF NOT EXISTS staff_presence(season_id INTEGER NOT NULL REFERENCES seasons(id),
          kind TEXT NOT NULL,event_id INTEGER NOT NULL,staff_id INTEGER NOT NULL REFERENCES staff(id),present INTEGER NOT NULL,
          PRIMARY KEY(season_id,kind,event_id,staff_id));
        CREATE TABLE IF NOT EXISTS measurements(id INTEGER PRIMARY KEY,season_id INTEGER NOT NULL REFERENCES seasons(id),
          player_id INTEGER NOT NULL REFERENCES players(id),measured_on TEXT NOT NULL,height REAL,weight REAL,
          note TEXT NOT NULL,author_id INTEGER NOT NULL REFERENCES users(id),updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS injuries(id INTEGER PRIMARY KEY,season_id INTEGER NOT NULL REFERENCES seasons(id),
          player_id INTEGER NOT NULL REFERENCES players(id),title TEXT NOT NULL,body_part TEXT NOT NULL,side TEXT NOT NULL,
          started TEXT NOT NULL,cause TEXT NOT NULL,complaints TEXT NOT NULL,phase TEXT NOT NULL,restrictions TEXT NOT NULL,
          expected_return TEXT NOT NULL,next_review TEXT NOT NULL,closed_on TEXT NOT NULL,
          author_id INTEGER NOT NULL REFERENCES users(id),updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS medical_reviews(id INTEGER PRIMARY KEY,injury_id INTEGER NOT NULL REFERENCES injuries(id),
          reviewed_on TEXT NOT NULL,note TEXT NOT NULL,actions TEXT NOT NULL,author_id INTEGER NOT NULL REFERENCES users(id),updated REAL NOT NULL);
        ''')
        db().commit()

    def access(module,write=False):
        require(module,write)
        if g.user['role']=='player':abort(403,'Dit onderdeel is alleen voor bevoegde staf.')
        if write and g.season['archived']:abort(403,'Heropen dit seizoen om gegevens te wijzigen.')

    def day(p,key,required=False):
        value=text(p,key,10,required)
        if value:
            try:date.fromisoformat(value)
            except ValueError:abort(400,'Kies een geldige datum.')
        return value

    def member(pid):
        row=db().execute('SELECT p.id,p.name,m.team_id FROM players p JOIN season_players m ON m.player_id=p.id WHERE p.id=? AND m.season_id=?',(pid,g.season_id)).fetchone()
        if not row:abort(404,'Speler niet gevonden in dit seizoen.')
        if not team_allowed(row['team_id']):abort(403,'Geen toegang tot dit team.')
        return row

    def injury(key):
        row=db().execute('SELECT * FROM injuries WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not row:abort(404,'Blessure niet gevonden.')
        member(row['player_id'])
        return row

    def staff_rows():
        if not permitted('staff') or g.user['role']=='player':return []
        rows=[]
        for r in db().execute('SELECT DISTINCT s.* FROM staff s JOIN season_staff m ON m.staff_id=s.id WHERE m.season_id=? ORDER BY s.name',(g.season_id,)):
            teams=[m[0] for m in db().execute('SELECT team_id FROM season_staff WHERE season_id=? AND staff_id=?',(g.season_id,r['id'])) if team_allowed(m[0])]
            if teams:rows.append(dict(r,team_ids=teams))
        return rows

    def summary():
        staff=staff_rows();ids={s['id'] for s in staff}
        presence=[]
        if ids:
            for r in db().execute('SELECT * FROM staff_presence WHERE season_id=?',(g.season_id,)):
                if r['staff_id'] not in ids:continue
                table,module=('trainings','training') if r['kind']=='training' else ('selections','selections')
                event=db().execute(f'SELECT team_id FROM {table} WHERE id=? AND season_id=?',(r['event_id'],g.season_id)).fetchone()
                if event and team_allowed(event['team_id']) and (permitted(module) or r['kind']=='training' and permitted('availability')):presence.append(dict(r))
        return dict(staff=staff,staff_presence=presence)

    @app.post('/api/staff')
    @protect
    def save_staff():
        access('staff',True);p=request.get_json();key=int(p.get('id') or 0)
        teams=p.get('team_ids',[])
        if not isinstance(teams,list) or not teams or not all(type(i) is int for i in teams):abort(400,'Kies minimaal één team.')
        for team in teams:
            if not team_allowed(team) or not db().execute('SELECT 1 FROM teams WHERE id=?',(team,)).fetchone():abort(403,'Geen toegang tot dit team.')
        if key:
            old=list(db().execute('SELECT team_id FROM season_staff WHERE staff_id=? AND season_id=?',(key,g.season_id)))
            if not old:abort(404,'Staflid niet gevonden.')
            if not all(team_allowed(r[0]) for r in old):abort(403,'Alle betrokken teams zijn nodig om dit staflid te wijzigen.')
        values=(text(p,'name'),text(p,'role'),text(p,'email',200,False),text(p,'phone',80,False))
        if key:db().execute('UPDATE staff SET name=?,role=?,email=?,phone=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO staff(name,role,email,phone) VALUES (?,?,?,?)',values).lastrowid
        db().execute('DELETE FROM season_staff WHERE staff_id=? AND season_id=?',(key,g.season_id))
        db().executemany('INSERT INTO season_staff VALUES (?,?,?)',[(g.season_id,key,t) for t in set(teams)])
        db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/staff/presence')
    @protect
    def presence():
        access('staff',True);p=request.get_json();kind=p.get('kind')
        if kind not in ('training','selection'):abort(400,'Kies training of wedstrijd.')
        if kind=='training':
            if not (permitted('training') or permitted('availability')):abort(403)
        else:require('selections')
        table='trainings' if kind=='training' else 'selections'
        event=db().execute(f'SELECT * FROM {table} WHERE id=? AND season_id=?',(int(p.get('event_id',0)),g.season_id)).fetchone()
        if not event:abort(404,'Activiteit niet gevonden.')
        if not team_allowed(event['team_id']):abort(403)
        sid=int(p.get('staff_id',0));present=p.get('present')
        if type(present) is not bool:abort(400,'Kies aanwezig of afwezig.')
        if not db().execute('SELECT 1 FROM season_staff WHERE season_id=? AND staff_id=? AND team_id=?',(g.season_id,sid,event['team_id'])).fetchone():abort(400,'Kies een staflid van dit team.')
        db().execute('INSERT INTO staff_presence VALUES (?,?,?,?,?) ON CONFLICT(season_id,kind,event_id,staff_id) DO UPDATE SET present=excluded.present',(g.season_id,kind,event['id'],sid,int(present)))
        db().commit();return jsonify(ok=True)

    @app.get('/api/medical')
    @protect
    def medical():
        access('medical')
        players=[dict(r) for r in db().execute('SELECT p.id,p.name,m.team_id FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=? ORDER BY p.name',(g.season_id,)) if team_allowed(r['team_id'])]
        ids={p['id'] for p in players}
        measurements=[dict(r) for r in db().execute('SELECT * FROM measurements WHERE season_id=? ORDER BY measured_on DESC,id DESC',(g.season_id,)) if r['player_id'] in ids]
        injuries=[dict(r) for r in db().execute('SELECT * FROM injuries WHERE season_id=? ORDER BY started DESC,id DESC',(g.season_id,)) if r['player_id'] in ids]
        injury_ids={r['id'] for r in injuries}
        reviews=[dict(r) for r in db().execute('SELECT * FROM medical_reviews ORDER BY reviewed_on DESC,id DESC') if r['injury_id'] in injury_ids]
        return jsonify(players=players,measurements=measurements,injuries=injuries,reviews=reviews,phases=PHASES)

    @app.post('/api/medical/measurements')
    @protect
    def measurement_save():
        access('medical',True);p=request.get_json();pid=int(p.get('player_id',0));member(pid);key=int(p.get('id') or 0)
        values=[]
        for field,lo,hi in [('height',30,250),('weight',5,350)]:
            raw=p.get(field);value=None if raw in (None,'') else float(raw)
            if value is not None and not lo<=value<=hi:abort(400,'Controleer lengte (cm) en gewicht (kg).')
            values.append(value)
        if all(v is None for v in values):abort(400,'Vul lengte of gewicht in.')
        values=(day(p,'measured_on',True),*values,text(p,'note',3000,False),g.user['id'],time.time())
        if key:
            old=db().execute('SELECT * FROM measurements WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
            if not old or old['player_id']!=pid:abort(404,'Meting niet gevonden.')
            db().execute('UPDATE measurements SET measured_on=?,height=?,weight=?,note=?,author_id=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO measurements(season_id,player_id,measured_on,height,weight,note,author_id,updated) VALUES (?,?,?,?,?,?,?,?)',(g.season_id,pid,*values)).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/medical/injuries')
    @protect
    def injury_save():
        access('medical',True);p=request.get_json();pid=int(p.get('player_id',0));member(pid);key=int(p.get('id') or 0)
        phase=p.get('phase')
        if phase not in PHASES:abort(400,'Kies een herstelfase.')
        started=day(p,'started',True);closed=day(p,'closed_on')
        if closed and closed<started:abort(400,'Hersteldatum ligt vóór de blessuredatum.')
        values=(text(p,'title'),text(p,'body_part',120),text(p,'side',80,False),started,text(p,'cause',3000,False),text(p,'complaints',3000,False),phase,text(p,'restrictions',3000,False),day(p,'expected_return'),day(p,'next_review'),closed,g.user['id'],time.time())
        if key:
            old=injury(key)
            if old['player_id']!=pid:abort(400,'Een blessure kan niet naar een andere speler worden verplaatst.')
            db().execute('UPDATE injuries SET title=?,body_part=?,side=?,started=?,cause=?,complaints=?,phase=?,restrictions=?,expected_return=?,next_review=?,closed_on=?,author_id=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO injuries(season_id,player_id,title,body_part,side,started,cause,complaints,phase,restrictions,expected_return,next_review,closed_on,author_id,updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(g.season_id,pid,*values)).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/medical/reviews')
    @protect
    def review_save():
        access('medical',True);p=request.get_json();iid=int(p.get('injury_id',0));injury(iid);key=int(p.get('id') or 0)
        values=(day(p,'reviewed_on',True),text(p,'note',5000),text(p,'actions',3000,False),g.user['id'],time.time())
        if key:
            if not db().execute('SELECT 1 FROM medical_reviews WHERE id=? AND injury_id=?',(key,iid)).fetchone():abort(404,'Controle niet gevonden.')
            db().execute('UPDATE medical_reviews SET reviewed_on=?,note=?,actions=?,author_id=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO medical_reviews(injury_id,reviewed_on,note,actions,author_id,updated) VALUES (?,?,?,?,?,?)',(iid,*values)).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    return summary
