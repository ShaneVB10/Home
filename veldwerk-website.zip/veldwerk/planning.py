"""Training, attendance, match squads, development plans and scoped CSV reports."""
import csv
import io
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from flask import abort, g, jsonify, request, Response

FORMATIONS = {
    '4-3-3': ('GK','LB','LCB','RCB','RB','LCM','CM','RCM','LW','ST','RW'),
    '4-4-2': ('GK','LB','LCB','RCB','RB','LM','LCM','RCM','RM','LS','RS'),
    '3-5-2': ('GK','LCB','CB','RCB','LWB','LCM','CM','RCM','RWB','LS','RS'),
    '4-2-3-1': ('GK','LB','LCB','RCB','RB','LDM','RDM','LAM','CAM','RAM','ST'),
}
FORMATION_ROWS={
    '4-3-3':(('LW','ST','RW'),('LCM','CM','RCM'),('LB','LCB','RCB','RB'),('GK',)),
    '4-4-2':(('LS','RS'),('LM','LCM','RCM','RM'),('LB','LCB','RCB','RB'),('GK',)),
    '3-5-2':(('LS','RS'),('LWB','LCM','CM','RCM','RWB'),('LCB','CB','RCB'),('GK',)),
    '4-2-3-1':(('ST',),('LAM','CAM','RAM'),('LDM','RDM'),('LB','LCB','RCB','RB'),('GK',)),
    '4-3-3 (punt naar voren)':(('LW','ST','RW'),('CAM',),('LDM','RDM'),('LB','LCB','RCB','RB'),('GK',)),
    '4-3-3 (punt naar achteren)':(('LW','ST','RW'),('LCM','RCM'),('DM',),('LB','LCB','RCB','RB'),('GK',)),
    '4-4-2 (ruit)':(('LS','RS'),('CAM',),('LCM','RCM'),('DM',),('LB','LCB','RCB','RB'),('GK',)),
    '4-1-4-1':(('ST',),('LM','LCM','RCM','RM'),('DM',),('LB','LCB','RCB','RB'),('GK',)),
    '4-5-1':(('ST',),('LM','LCM','CM','RCM','RM'),('LB','LCB','RCB','RB'),('GK',)),
    '4-3-2-1':(('ST',),('LAM','RAM'),('LCM','CM','RCM'),('LB','LCB','RCB','RB'),('GK',)),
    '4-2-2-2':(('LS','RS'),('LAM','RAM'),('LDM','RDM'),('LB','LCB','RCB','RB'),('GK',)),
    '4-2-4':(('LW','LS','RS','RW'),('LCM','RCM'),('LB','LCB','RCB','RB'),('GK',)),
    '3-4-3':(('LW','ST','RW'),('LM','LCM','RCM','RM'),('LCB','CB','RCB'),('GK',)),
    '3-4-1-2':(('LS','RS'),('CAM',),('LM','LCM','RCM','RM'),('LCB','CB','RCB'),('GK',)),
    '3-4-2-1':(('ST',),('LAM','RAM'),('LM','LCM','RCM','RM'),('LCB','CB','RCB'),('GK',)),
    '5-3-2':(('LS','RS'),('LCM','CM','RCM'),('LWB','LCB','CB','RCB','RWB'),('GK',)),
    '5-4-1':(('ST',),('LM','LCM','RCM','RM'),('LWB','LCB','CB','RCB','RWB'),('GK',)),
    '5-2-3':(('LW','ST','RW'),('LCM','RCM'),('LWB','LCB','CB','RCB','RWB'),('GK',)),
}
for name,rows in FORMATION_ROWS.items():
    if name not in FORMATIONS:
        FORMATIONS[name]=tuple(slot for row in reversed(rows) for slot in row)
AVAILABILITY = ('onbekend','beschikbaar','afgemeld','geblesseerd')
ATTENDANCE = ('onbekend','aanwezig','afwezig','vrijgesteld')
PLAN_CATEGORIES = ('Techniek','Tactiek','Fysiek','Mentaliteit')


def register_planning(app, db, protect, require, permitted, team_allowed, text):
    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS trainings(id INTEGER PRIMARY KEY, team_id INTEGER NOT NULL REFERENCES teams(id),
          title TEXT NOT NULL, starts TEXT NOT NULL, ends TEXT NOT NULL, location TEXT NOT NULL,
          notes TEXT NOT NULL, cancelled INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS training_exercises(training_id INTEGER NOT NULL REFERENCES trainings(id),
          exercise_id INTEGER NOT NULL REFERENCES exercises(id), PRIMARY KEY(training_id,exercise_id));
        CREATE TABLE IF NOT EXISTS attendance(training_id INTEGER NOT NULL REFERENCES trainings(id),
          player_id INTEGER NOT NULL REFERENCES players(id), availability TEXT NOT NULL DEFAULT 'onbekend',
          attendance TEXT NOT NULL DEFAULT 'onbekend', note TEXT NOT NULL DEFAULT '', updated REAL NOT NULL,
          PRIMARY KEY(training_id,player_id));
        CREATE TABLE IF NOT EXISTS selections(id INTEGER PRIMARY KEY, team_id INTEGER NOT NULL REFERENCES teams(id),
          opponent TEXT NOT NULL, kickoff TEXT NOT NULL, location TEXT NOT NULL, formation TEXT NOT NULL,
          notes TEXT NOT NULL, published INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS selection_players(selection_id INTEGER NOT NULL REFERENCES selections(id),
          player_id INTEGER NOT NULL REFERENCES players(id), status TEXT NOT NULL, slot TEXT NOT NULL,
          PRIMARY KEY(selection_id,player_id));
        CREATE TABLE IF NOT EXISTS development_plans(id INTEGER PRIMARY KEY, player_id INTEGER NOT NULL REFERENCES players(id),
          title TEXT NOT NULL, category TEXT NOT NULL, objective TEXT NOT NULL, actions TEXT NOT NULL,
          success_measure TEXT NOT NULL, due_date TEXT NOT NULL, status TEXT NOT NULL, evaluation TEXT NOT NULL,
          created REAL NOT NULL, updated REAL NOT NULL);
        ''')
        db().commit()

    def local_time(value):
        try:
            return datetime.strptime(str(value),'%Y-%m-%dT%H:%M').strftime('%Y-%m-%dT%H:%M')
        except ValueError:
            abort(400,'Kies een geldige datum en tijd.')

    def scoped_team(team_id):
        if not team_allowed(team_id):
            abort(403,'Geen toegang tot dit team.')
        if not db().execute('SELECT 1 FROM teams WHERE id=?',(team_id,)).fetchone():
            abort(400,'Team niet gevonden.')

    def staff(module):
        require(module,True)
        if g.user['role']=='player':
            abort(403,'Alleen trainers en beheerder kunnen dit aanpassen.')

    def plan_player(player_id):
        row=db().execute('SELECT p.id,p.name,m.team_id FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=? AND p.id=?',(g.season_id,player_id)).fetchone()
        if not row:
            abort(404,'Speler niet gevonden.')
        scoped_team(row['team_id'])
        if g.user['role']=='player' and player_id!=g.user['player_id']:
            abort(403,'Geen toegang tot deze speler.')
        return row

    @app.post('/api/trainings')
    @protect
    def training_save():
        staff('training')
        payload=request.get_json()
        team_id=int(payload.get('team_id',0))
        scoped_team(team_id)
        starts,ends=local_time(payload.get('starts')),local_time(payload.get('ends'))
        if ends<=starts:
            abort(400,'De eindtijd moet na de begintijd liggen.')
        cancelled=payload.get('cancelled',False)
        if type(cancelled) is not bool:
            abort(400,'Kies of de training is geannuleerd.')
        exercises=payload.get('exercise_ids',[])
        if not isinstance(exercises,list) or not all(type(i) is int for i in exercises):
            abort(400,'Ongeldige oefeningenlijst.')
        if exercises:
            require('exercises')
            if not set(exercises).issubset({r[0] for r in db().execute('SELECT id FROM exercises')}):
                abort(400,'Een gekoppelde oefening bestaat niet.')
        values=(text(payload,'title'),starts,ends,text(payload,'location',200,False),text(payload,'notes',4000,False),int(cancelled))
        key=int(payload.get('id') or 0)
        if key:
            old=db().execute('SELECT * FROM trainings WHERE id=?',(key,)).fetchone()
            if not old or old['season_id']!=g.season_id:
                abort(404,'Training niet gevonden.')
            scoped_team(old['team_id'])
            if old['team_id']!=team_id:
                abort(400,'Een bestaande training kan niet naar een ander team worden verplaatst.')
            db().execute('UPDATE trainings SET title=?,starts=?,ends=?,location=?,notes=?,cancelled=? WHERE id=?',(*values,key))
        else:
            key=db().execute('INSERT INTO trainings(team_id,title,starts,ends,location,notes,cancelled,created,season_id) VALUES (?,?,?,?,?,?,?,?,?)',(team_id,*values,time.time(),g.season_id)).lastrowid
        if permitted('exercises') and 'exercise_ids' in payload:
            db().execute('DELETE FROM training_exercises WHERE training_id=?',(key,))
            db().executemany('INSERT INTO training_exercises VALUES (?,?)',[(key,i) for i in set(exercises)])
        db().execute('INSERT OR IGNORE INTO attendance(training_id,player_id,updated) SELECT ?,player_id,? FROM season_players WHERE team_id=? AND season_id=?',(key,time.time(),team_id,g.season_id))
        db().commit()
        return jsonify(ok=True,id=key)

    @app.post('/api/attendance')
    @protect
    def attendance_save():
        require('availability',True)
        payload=request.get_json()
        training_id,player_id=int(payload.get('training_id',0)),int(payload.get('player_id',0))
        training=db().execute('SELECT * FROM trainings WHERE id=?',(training_id,)).fetchone()
        if not training or training['season_id']!=g.season_id:
            abort(404,'Training niet gevonden.')
        scoped_team(training['team_id'])
        player=plan_player(player_id)
        if player['team_id']!=training['team_id']:
            abort(400,'Speler hoort niet bij het trainingsteam.')
        if training['cancelled']:
            abort(400,'Deze training is geannuleerd.')
        old=db().execute('SELECT * FROM attendance WHERE training_id=? AND player_id=?',(training_id,player_id)).fetchone()
        availability=payload.get('availability',old['availability'] if old else 'onbekend')
        attendance=payload.get('attendance',old['attendance'] if old else 'onbekend')
        if availability not in AVAILABILITY or attendance not in ATTENDANCE:
            abort(400,'Kies een geldige beschikbaarheid en aanwezigheid.')
        if g.user['role']=='player':
            if 'attendance' in payload:
                abort(403,'Alleen een trainer kan daadwerkelijke aanwezigheid registreren.')
            if training['starts']<=datetime.now(ZoneInfo('Europe/Amsterdam')).strftime('%Y-%m-%dT%H:%M'):
                abort(400,'Je kunt je beschikbaarheid alleen vóór de training wijzigen.')
        note=text(payload,'note',1000,False) if 'note' in payload else (old['note'] if old else '')
        fields={key:payload[key] for key in ('availability','attendance','note') if key in payload}
        if not fields:abort(400,'Geen wijziging opgegeven.')
        if 'note' in fields:fields['note']=note
        db().execute('INSERT OR IGNORE INTO attendance(training_id,player_id,updated) VALUES (?,?,0)',(training_id,player_id))
        fields['updated']=max(time.time(),(old['updated'] if old else 0)+0.000001)
        query='UPDATE attendance SET '+','.join(key+'=?' for key in fields)+' WHERE training_id=? AND player_id=?'
        values=[*fields.values(),training_id,player_id]
        if 'expected_updated' in payload:
            query+=' AND updated=?'
            values.append(payload['expected_updated'])
        if db().execute(query,values).rowcount!=1:
            db().rollback()
            abort(409,'Deze rij is intussen gewijzigd. Herlaad de rij voordat je opnieuw wijzigt.')
        db().commit()
        return jsonify(ok=True,row=dict(db().execute('SELECT * FROM attendance WHERE training_id=? AND player_id=?',(training_id,player_id)).fetchone()))

    @app.post('/api/selections')
    @protect
    def selection_save():
        staff('selections')
        payload=request.get_json()
        team_id=int(payload.get('team_id',0))
        scoped_team(team_id)
        formation=payload.get('formation')
        if formation not in FORMATIONS:
            abort(400,'Kies een ondersteunde opstelling.')
        published=payload.get('published',False)
        if type(published) is not bool:
            abort(400,'Kies concept of gepubliceerd.')
        entries=payload.get('players',[])
        if not isinstance(entries,list) or len(entries)>60:
            abort(400,'Ongeldige selectielijst.')
        roster={r[0] for r in db().execute('SELECT player_id FROM season_players WHERE team_id=? AND season_id=?',(team_id,g.season_id))}
        selected,occupied,validated=set(),set(),[]
        for entry in entries:
            if not isinstance(entry,dict):
                abort(400,'Ongeldige speler in selectie.')
            pid=int(entry.get('player_id',0))
            status,slot=entry.get('status'),str(entry.get('slot',''))
            if status=='reserve':status='bench'
            if pid not in roster or pid in selected or status not in ('starter','bench','reserve','second_team','not_selected'):
                abort(400,'Kies iedere speler maximaal eenmaal uit het geselecteerde team.')
            if status=='starter':
                if slot not in FORMATIONS[formation] or slot in occupied:
                    abort(400,'Kies unieke basisposities die bij de formatie passen.')
                occupied.add(slot)
            elif slot:
                abort(400,'Bankspelers en reserves hebben geen basispositie.')
            selected.add(pid)
            validated.append((pid,status,slot))
        values=(text(payload,'opponent'),local_time(payload.get('kickoff')),text(payload,'location',200,False),formation,text(payload,'notes',4000,False),int(published))
        key=int(payload.get('id') or 0)
        if key:
            old=db().execute('SELECT * FROM selections WHERE id=?',(key,)).fetchone()
            if not old or old['season_id']!=g.season_id:
                abort(404,'Selectie niet gevonden.')
            scoped_team(old['team_id'])
            if old['team_id']!=team_id:
                abort(400,'Een selectie kan niet naar een ander team worden verplaatst.')
            db().execute('UPDATE selections SET opponent=?,kickoff=?,location=?,formation=?,notes=?,published=? WHERE id=?',(*values,key))
        else:
            key=db().execute('INSERT INTO selections(team_id,opponent,kickoff,location,formation,notes,published,created,season_id) VALUES (?,?,?,?,?,?,?,?,?)',(team_id,*values,time.time(),g.season_id)).lastrowid
        db().execute('DELETE FROM selection_players WHERE selection_id=?',(key,))
        db().executemany('INSERT INTO selection_players VALUES (?,?,?,?)',[(key,*entry) for entry in validated])
        db().commit()
        return jsonify(ok=True,id=key)

    @app.post('/api/plans')
    @protect
    def plan_save():
        staff('plans')
        payload=request.get_json()
        player_id=int(payload.get('player_id',0))
        plan_player(player_id)
        category,status=payload.get('category'),payload.get('status')
        if category not in PLAN_CATEGORIES or status not in ('gepland','bezig','behaald','gestopt'):
            abort(400,'Kies een geldige categorie en voortgangsstatus.')
        due_date=text(payload,'due_date',10,False)
        if due_date:
            try:
                datetime.strptime(due_date,'%Y-%m-%d')
            except ValueError:
                abort(400,'Kies een geldige evaluatiedatum.')
        values=(text(payload,'title'),category,text(payload,'objective',3000),text(payload,'actions',3000),text(payload,'success_measure',2000,False),due_date,status,text(payload,'evaluation',3000,False),time.time())
        key=int(payload.get('id') or 0)
        if key:
            old=db().execute('SELECT * FROM development_plans WHERE id=?',(key,)).fetchone()
            if not old or old['season_id']!=g.season_id:
                abort(404,'Ontwikkelplan niet gevonden.')
            plan_player(old['player_id'])
            if player_id!=old['player_id']:
                abort(400,'Een ontwikkelplan kan niet naar een andere speler worden verplaatst.')
            db().execute('UPDATE development_plans SET title=?,category=?,objective=?,actions=?,success_measure=?,due_date=?,status=?,evaluation=?,updated=? WHERE id=?',(*values,key))
        else:
            key=db().execute('INSERT INTO development_plans(player_id,title,category,objective,actions,success_measure,due_date,status,evaluation,updated,created,season_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',(player_id,*values,time.time(),g.season_id)).lastrowid
        db().commit()
        return jsonify(ok=True,id=key)

    @app.get('/api/reports.csv')
    @protect
    def report_csv():
        require('reports')
        payload=app.view_functions['dashboard']().get_json()
        rows=build_report(payload,request.args)
        output=io.StringIO()
        writer=csv.writer(output,delimiter=';')
        writer.writerow(['Speler','Team','Aanwezig','Afwezig','Vrijgesteld','Registraties onbekend','Aanwezigheid %','Selecties','Basisplaatsen','Observaties','Gemiddelde trainersscore','Plannen behaald','Plannen totaal','Videoclips','Gemarkeerde momenten'])
        for r in rows:
            values=[r[k] for k in ('name','team','present','absent','excused','unknown','percentage','selections','starts','observations','rating','plans_done','plans','videos','moments')]
            writer.writerow([csv_safe(v) for v in values])
        return Response('\ufeff'+output.getvalue(),content_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="veldwerk-rapport.csv"'})

    @app.get('/api/reports')
    @protect
    def report_json():
        require('reports')
        return jsonify(rows=build_report(app.view_functions['dashboard']().get_json(),request.args))

    def dashboard():
        trainings=[]
        if permitted('training') or permitted('availability'):
            trainings=[dict(t) for t in db().execute('SELECT * FROM trainings WHERE season_id=? ORDER BY starts DESC',(g.season_id,)) if team_allowed(t['team_id'])]
        training_ids={t['id'] for t in trainings}
        attendance=[]
        if permitted('availability'):
            attendance=[dict(r) for r in db().execute('SELECT a.*,p.name,m.team_id FROM attendance a JOIN players p ON p.id=a.player_id JOIN season_players m ON m.player_id=p.id WHERE m.season_id=?',(g.season_id,))
                        if r['training_id'] in training_ids and (g.user['role']!='player' or r['player_id']==g.user['player_id'])]
        training_exercises=[]
        if permitted('exercises'):
            training_exercises=[dict(r) for r in db().execute('SELECT * FROM training_exercises') if r['training_id'] in training_ids]
        selections=[]
        if permitted('selections'):
            selections=[dict(s) for s in db().execute('SELECT * FROM selections WHERE season_id=? ORDER BY kickoff DESC',(g.season_id,))
                        if team_allowed(s['team_id']) and (g.user['role']!='player' or s['published'])]
        selection_ids={s['id'] for s in selections}
        selection_players=[dict(r) for r in db().execute('SELECT s.*,p.name,m.shirt_number,m.position FROM selection_players s JOIN players p ON p.id=s.player_id JOIN season_players m ON m.player_id=p.id WHERE m.season_id=?',(g.season_id,)) if r['selection_id'] in selection_ids]
        plans=[]
        if permitted('plans'):
            plans=[dict(r) for r in db().execute('SELECT d.*,p.name,m.team_id FROM development_plans d JOIN players p ON p.id=d.player_id JOIN season_players m ON m.player_id=p.id AND m.season_id=d.season_id WHERE d.season_id=? ORDER BY d.updated DESC',(g.season_id,))
                   if team_allowed(r['team_id']) and (g.user['role']!='player' or r['player_id']==g.user['player_id'])]
        candidates=[dict(r) for r in db().execute('SELECT p.id,m.team_id,p.name,m.shirt_number,m.position FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=? ORDER BY p.name',(g.season_id,)) if team_allowed(r['team_id'])] if g.user['role']!='player' else []
        return dict(trainings=trainings,attendance=attendance,training_exercises=training_exercises,selections=selections,selection_players=selection_players,plans=plans,
                    selection_candidates=candidates if permitted('selections',True) else [],plan_candidates=candidates if permitted('plans',True) else [],
                    formations=FORMATIONS,formation_rows=FORMATION_ROWS,availability_options=AVAILABILITY,attendance_options=ATTENDANCE,plan_categories=PLAN_CATEGORIES,
                    report_access={m:permitted(m) for m in ('availability','selections','plans','videos')})
    from fast_planning import register_fast_planning
    register_fast_planning(app,db,protect,staff,scoped_team,permitted,require,text)
    return dashboard


def build_report(data, filters):
    start,until=str(filters.get('from','')),str(filters.get('until',''))
    for value in (start,until):
        if value:
            try:
                datetime.strptime(value,'%Y-%m-%d')
            except ValueError:
                abort(400,'Gebruik een geldige rapportperiode.')
    if start and until and start>until:
        abort(400,'De einddatum moet op of na de begindatum liggen.')
    def in_period(stamp):
        day=stamp[:10] if isinstance(stamp,str) else datetime.fromtimestamp(stamp,ZoneInfo('Europe/Amsterdam')).strftime('%Y-%m-%d')
        return (not start or day>=start) and (not until or day<=until)
    teams={t['id']:t['name'] for t in data['teams']}
    trainings={t['id'] for t in data['trainings'] if not t['cancelled'] and in_period(t['starts']) and (not filters.get('team') or str(t['team_id'])==str(filters['team']))}
    selections={s['id'] for s in data['selections'] if s['published'] and in_period(s['kickoff']) and (not filters.get('team') or str(s['team_id'])==str(filters['team']))}
    rows=[]
    for p in data['players']:
        if filters.get('team') and str(p['team_id'])!=str(filters['team']):
            continue
        if filters.get('player') and str(p['id'])!=str(filters['player']):
            continue
        a=[r for r in data['attendance'] if r['player_id']==p['id'] and r['training_id'] in trainings]
        counts={k:sum(r['attendance']==k for r in a) for k in ATTENDANCE}
        denominator=counts['aanwezig']+counts['afwezig']
        entries=[s for s in data['selection_players'] if s['player_id']==p['id'] and s['selection_id'] in selections and s['status'] in ('starter','bench','reserve')]
        observations=[o for o in data['observations'] if o['player_id']==p['id'] and in_period(o['created'])]
        plans=[d for d in data['plans'] if d['player_id']==p['id'] and in_period(d['created'])]
        rows.append(dict(player_id=p['id'],name=p['name'],team=teams.get(p['team_id'],''),present=counts['aanwezig'],absent=counts['afwezig'],excused=counts['vrijgesteld'],unknown=counts['onbekend'],
                         percentage=round(counts['aanwezig']/denominator*100,1) if denominator else '',selections=len(entries),starts=sum(s['status']=='starter' for s in entries),
                         observations=len(observations),rating=round(sum(o['rating'] for o in observations)/len(observations),1) if observations else '',
                         plans=len(plans),plans_done=sum(d['status']=='behaald' for d in plans),
                         videos=sum(v['player_id']==p['id'] and in_period(v['created']) for v in data['videos']),
                         moments=sum(m['player_id']==p['id'] and in_period(m['created']) for m in data['moments'])))
    for row in rows:
        for module,keys in {'availability':('present','absent','excused','unknown','percentage'),'selections':('selections','starts'),'plans':('plans','plans_done'),'videos':('videos','moments')}.items():
            if not data['report_access'][module]:
                for key in keys:
                    row[key]=''
    return rows


def csv_safe(value):
    if isinstance(value,str) and value.lstrip(' \t\r\n').startswith(('=','+','-','@')):
        return "'"+value
    return value
