import io
import tempfile
import unittest
import zipfile
from pathlib import Path

import test_server as fixtures
from maintenance import backup


class WorkflowExtensionTests(unittest.TestCase):
    setUpClass=classmethod(fixtures.TeamTests.setUpClass.__func__)
    tearDownClass=classmethod(fixtures.TeamTests.tearDownClass.__func__)
    setUp=fixtures.TeamTests.setUp
    tearDown=fixtures.TeamTests.tearDown
    login=fixtures.TeamTests.login
    post=fixtures.TeamTests.post

    def upload_document(self, title='Beleidsplan'):
        return self.client.post('/api/club-documents',data={
            'title':title,'category':'Beleidsplan','team_id':'1','player_id':'1','note':'Versie één',
            'file':(io.BytesIO(b'%PDF-1.4 test'),'beleid.pdf')},
            headers={'X-CSRF-Token':self.csrf})

    def test_business_page_and_interest_are_public_but_leads_are_admin_only(self):
        page=self.client.get('/zakelijk');self.assertEqual(page.status_code,200);self.assertIn(b'29,99',page.data);self.assertIn(b'49,99',page.data);self.assertIn(b'pakket-team',page.data)
        response=self.client.post('/zakelijk/interesse',data={'name':'Shane','organisation':'SV Test','email':'info@example.nl','phone':'','package':'Club','message':'Bel mij'})
        self.assertEqual(response.status_code,302)
        self.login('coach');self.assertEqual(self.client.get('/api/business-leads').status_code,403)
        self.login();business=self.client.get('/api/business-leads').json;rows=business['rows']
        self.assertIn('planning',business['packages']['pilot'])
        self.assertEqual(self.post('/api/business-packages/pilot',{'features':['messages']}).status_code,200)
        pilot_page=self.client.get('/zakelijk').data
        self.assertIn('Berichten en helpdesk'.encode(),pilot_page);self.assertNotIn('Trainingsplanning en aanwezigheid'.encode(),pilot_page.split(b'id="pakket-pilot"')[1].split(b'</article>')[0])
        self.assertEqual(rows[0]['organisation'],'SV Test')
        self.assertNotIn('kvk',rows[0])
        messages=self.client.get('/api/mail').json['rows'];notice=next(r for r in messages if r['direction']=='notification')
        self.assertEqual(notice['status'],'nieuw');self.assertIn('SV Test',notice['subject'])
        self.assertEqual(self.post(f"/api/mail/{notice['id']}/read",{}).status_code,200)
        self.assertEqual(self.post(f"/api/mail/{notice['id']}/delete",{}).status_code,200)
        self.assertEqual(self.post(f"/api/business-leads/{rows[0]['id']}/delete",{}).status_code,200)
        self.assertFalse(self.client.get('/api/business-leads').json['rows'])

    def test_mail_drafts_are_editable_and_real_send_requires_configuration(self):
        self.login()
        payload={'action':'draft','subject':'Training','body':'Donderdag om 19.30 uur','team_id':1,'player_id':1,'to_address':'speler@example.nl'}
        response=self.post('/api/mail',payload);self.assertEqual(response.status_code,200,response.json)
        key=response.json['id'];mail=self.client.get('/api/mail').json
        self.assertFalse(mail['smtp_configured']);self.assertEqual(mail['rows'][0]['direction'],'draft')
        self.assertEqual(self.post('/api/mail',{**payload,'id':key,'subject':'Gewijzigd'}).status_code,200)
        self.assertEqual(self.post('/api/mail',{**payload,'id':key,'action':'send'}).status_code,503)
        self.assertEqual(self.post(f'/api/mail/{key}/delete',{}).status_code,200)

    def test_club_organisation_panels_open_and_support_crud(self):
        self.login()
        kinds={'task','agenda','academy','scouting','training_suggestion','player_report','parent','resource'}
        dashboard=self.client.get('/api/dashboard').json
        self.assertTrue(kinds.issubset({row['kind'] for row in dashboard['club_suite_items']}))
        for kind in kinds:
            created=self.post('/api/club-suite/items',{'kind':kind,'team_id':1,'player_id':'','title':'Controle '+kind,'body':'Volledig ingevuld','due':'2027-10-01','status':'open'})
            self.assertEqual(created.status_code,200,created.json);key=created.json['id']
            changed=self.post('/api/club-suite/items',{'id':key,'kind':kind,'team_id':1,'player_id':'','title':'Gewijzigd '+kind,'body':'Aangepast','due':'2027-10-02','status':'bezig'})
            self.assertEqual(changed.status_code,200,changed.json)
            row=next(row for row in self.client.get('/api/dashboard').json['club_suite_items'] if row['id']==key)
            self.assertEqual(row['status'],'bezig')
            self.assertEqual(self.post(f'/api/club-suite/items/{key}/delete',{}).status_code,200)

    def test_helpdesk_question_response_receive_and_delete(self):
        self.login('coach');created=self.post('/api/helpdesk',{'subject':'Waar vind ik scouting?','body':'Ik heb hulp nodig.'});self.assertEqual(created.status_code,200,created.json);key=created.json['id']
        own=self.client.get('/api/mail').json['tickets'];self.assertEqual(own[0]['status'],'open')
        self.login();self.assertGreaterEqual(self.client.get('/api/dashboard').json['mail_unread'],1)
        self.assertEqual(self.post(f'/api/helpdesk/{key}',{'response':'Open Scouting in het menu.','status':'beantwoord'}).status_code,200)
        self.login('coach');ticket=self.client.get('/api/mail').json['tickets'][0];self.assertEqual(ticket['response'],'Open Scouting in het menu.')
        self.assertEqual(self.post(f'/api/helpdesk/{key}/delete',{}).status_code,200)

    def test_documents_upload_edit_download_delete_and_backup(self):
        self.login();response=self.upload_document();self.assertEqual(response.status_code,200,response.json);key=response.json['id']
        row=next(d for d in self.client.get('/api/dashboard').json['club_documents'] if d['id']==key)
        self.assertNotIn('filename',row);self.assertEqual(row['player_id'],1)
        edit={'title':'Beleidsplan 2027','category':'Visieplan','team_id':1,'player_id':1,'note':'Definitief'}
        self.assertEqual(self.post(f'/api/club-documents/{key}',edit).status_code,200)
        download=self.client.get(f'/club-documents/{key}');self.assertEqual(download.status_code,200);self.assertEqual(download.data,b'%PDF-1.4 test');download.close()
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'backup.zip';backup(self.temp.name,target)
            with zipfile.ZipFile(target) as archive:self.assertTrue(any(n.startswith('data/club_documents/') for n in archive.namelist()))
        self.assertEqual(self.post(f'/api/club-documents/{key}/delete',{}).status_code,200)
        self.assertEqual(self.client.get(f'/club-documents/{key}').status_code,404)

    def test_document_rejects_player_from_another_team(self):
        self.login();response=self.client.post('/api/club-documents',data={'title':'Verkeerd','category':'Training','team_id':'1','player_id':'3','file':(io.BytesIO(b'x'),'x.pdf')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,400)

    def test_bulk_players_and_training_delete(self):
        self.login();response=self.post('/api/players/bulk',{'team_id':1,'rows':[{'shirt_number':11,'name':'Nieuwe speler','position':'Spits'},{'shirt_number':'','name':'Zonder nummer','position':''}]})
        self.assertEqual(response.status_code,200,response.json);self.assertEqual(response.json['count'],2)
        training=self.post('/api/trainings',{'team_id':1,'title':'Teamtraining','starts':'2027-08-01T19:00','ends':'2027-08-01T20:30','location':'Veld 1','notes':'Opbouwen','cancelled':False})
        self.assertEqual(training.status_code,200,training.json);key=training.json['id']
        self.assertEqual(self.post(f'/api/trainings/{key}/delete',{}).status_code,200)
        self.assertFalse(any(t['id']==key for t in self.client.get('/api/dashboard').json['trainings']))

    def test_player_tracking_bulk_entry_radar_data_and_progression_privacy(self):
        self.login()
        training=self.post('/api/trainings',{'team_id':1,'title':'RPE-training','starts':'2027-09-01T19:00','ends':'2027-09-01T20:30','location':'Veld','notes':'','cancelled':False}).json['id']
        selection=self.post('/api/selections',{'team_id':1,'selection_team':1,'opponent':'Tegenstander','kickoff':'2027-09-03T20:00','location':'Thuis','formation':'Nummers 1 t/m 11','notes':'','published':True,'players':[]}).json['id']
        evaluation={'player_id':1,'period':'September','evaluated_on':'2027-09-05','technical':4,'tactical':5,'physical':3,'mental':4,'social':5,'note':'Goede ontwikkeling'}
        self.assertEqual(self.post('/api/tracking/evaluations',evaluation).status_code,200)
        loads={'training_id':training,'rows':[{'player_id':1,'rpe':7,'minutes':90,'wellness':4},{'player_id':2,'rpe':6,'minutes':85,'wellness':3}]}
        self.assertEqual(self.post('/api/tracking/loads/bulk',loads).json['count'],2)
        matches={'selection_id':selection,'rows':[{'player_id':1,'minutes':90,'goals':1,'assists':1,'yellow':0,'red':0,'xg':0.8,'xa':0.4,'rating':8.1},{'player_id':2,'minutes':75,'goals':0,'assists':0,'yellow':1,'red':0,'xg':0.2,'xa':0.1,'rating':7}]}
        self.assertEqual(self.post('/api/tracking/matches/bulk',matches).json['count'],2)
        progression={'player_id':1,'target_team_id':2,'reviewed_on':'2027-09-06','readiness':4,'recommendation':'Meetraint met Team B','rationale':'Beoordeling, wedstrijdoutput en video','decision':'voordragen'}
        self.assertEqual(self.post('/api/tracking/progression',progression).status_code,200)
        tracking=self.client.get('/api/dashboard').json['tracking']
        self.assertEqual(tracking['evaluations'][0]['tactical'],5);self.assertEqual(tracking['loads'][0]['rpe'],7)
        self.assertEqual(tracking['matches'][0]['goals'],1);self.assertEqual(tracking['progression'][0]['decision'],'voordragen')
        self.login('player');own=self.client.get('/api/dashboard').json['tracking']
        self.assertEqual({r['player_id'] for r in own['loads']},{1});self.assertEqual(own['progression'],[])
        self.assertEqual(self.post('/api/tracking/evaluations',evaluation).status_code,403)

    def test_scout_can_be_added_as_staff_member(self):
        self.login();response=self.post('/api/staff',{'name':'Scout Eén','role':'Scout','email':'scout@example.nl','phone':'','bio':'Regioscout','specialties':'O13–O17','qualifications':'Scoutingsopleiding','team_ids':[1]})
        self.assertEqual(response.status_code,200,response.json)
        scout=next(s for s in self.client.get('/api/dashboard').json['staff'] if s['name']=='Scout Eén')
        self.assertEqual(scout['role'],'Scout');self.assertEqual(scout['specialties'],'O13–O17')


if __name__=='__main__':unittest.main()
