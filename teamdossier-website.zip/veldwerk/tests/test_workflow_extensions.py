import io
import tempfile
import unittest
import zipfile
from pathlib import Path

import test_server as fixtures
from maintenance import backup


class WorkflowExtensionTests(unittest.TestCase):
    setUpClass=classmethod(fixtures.TeamTests.setUpClass.__func__)
    tearDownClass=classmethod(fixtures.TeamTests.tearDownClass.__func__)
    setUp=fixtures.TeamTests.setUp
    tearDown=fixtures.TeamTests.tearDown
    login=fixtures.TeamTests.login
    post=fixtures.TeamTests.post

    def upload_document(self, title='Beleidsplan'):
        return self.client.post('/api/club-documents',data={
            'title':title,'category':'Beleidsplan','team_id':'1','player_id':'1','note':'Versie één',
            'file':(io.BytesIO(b'%PDF-1.4 test'),'beleid.pdf')},
            headers={'X-CSRF-Token':self.csrf})

    def test_business_page_and_interest_are_public_but_leads_are_admin_only(self):
        self.assertEqual(self.client.get('/zakelijk').status_code,200)
        response=self.client.post('/zakelijk/interesse',data={'name':'Shane','organisation':'SV Test','email':'info@example.nl','phone':'','package':'Club','message':'Bel mij'})
        self.assertEqual(response.status_code,302)
        self.login('coach');self.assertEqual(self.client.get('/api/business-leads').status_code,403)
        self.login();rows=self.client.get('/api/business-leads').json['rows']
        self.assertEqual(rows[0]['organisation'],'SV Test')
        self.assertNotIn('kvk',rows[0])

    def test_mail_drafts_are_editable_and_real_send_requires_configuration(self):
        self.login()
        payload={'action':'draft','subject':'Training','body':'Donderdag om 19.30 uur','team_id':1,'player_id':1,'to_address':'speler@example.nl'}
        response=self.post('/api/mail',payload);self.assertEqual(response.status_code,200,response.json)
        key=response.json['id'];mail=self.client.get('/api/mail').json
        self.assertFalse(mail['smtp_configured']);self.assertEqual(mail['rows'][0]['direction'],'draft')
        self.assertEqual(self.post('/api/mail',{**payload,'id':key,'subject':'Gewijzigd'}).status_code,200)
        self.assertEqual(self.post('/api/mail',{**payload,'id':key,'action':'send'}).status_code,503)
        self.assertEqual(self.post(f'/api/mail/{key}/delete',{}).status_code,200)

    def test_documents_upload_edit_download_delete_and_backup(self):
        self.login();response=self.upload_document();self.assertEqual(response.status_code,200,response.json);key=response.json['id']
        row=next(d for d in self.client.get('/api/dashboard').json['club_documents'] if d['id']==key)
        self.assertNotIn('filename',row);self.assertEqual(row['player_id'],1)
        edit={'title':'Beleidsplan 2027','category':'Visieplan','team_id':1,'player_id':1,'note':'Definitief'}
        self.assertEqual(self.post(f'/api/club-documents/{key}',edit).status_code,200)
        download=self.client.get(f'/club-documents/{key}');self.assertEqual(download.status_code,200);self.assertEqual(download.data,b'%PDF-1.4 test');download.close()
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'backup.zip';backup(self.temp.name,target)
            with zipfile.ZipFile(target) as archive:self.assertTrue(any(n.startswith('data/club_documents/') for n in archive.namelist()))
        self.assertEqual(self.post(f'/api/club-documents/{key}/delete',{}).status_code,200)
        self.assertEqual(self.client.get(f'/club-documents/{key}').status_code,404)

    def test_document_rejects_player_from_another_team(self):
        self.login();response=self.client.post('/api/club-documents',data={'title':'Verkeerd','category':'Training','team_id':'1','player_id':'3','file':(io.BytesIO(b'x'),'x.pdf')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,400)

    def test_bulk_players_and_training_delete(self):
        self.login();response=self.post('/api/players/bulk',{'team_id':1,'rows':[{'shirt_number':11,'name':'Nieuwe speler','position':'Spits'},{'shirt_number':'','name':'Zonder nummer','position':''}]})
        self.assertEqual(response.status_code,200,response.json);self.assertEqual(response.json['count'],2)
        training=self.post('/api/trainings',{'team_id':1,'title':'Teamtraining','starts':'2027-08-01T19:00','ends':'2027-08-01T20:30','location':'Veld 1','notes':'Opbouwen','cancelled':False})
        self.assertEqual(training.status_code,200,training.json);key=training.json['id']
        self.assertEqual(self.post(f'/api/trainings/{key}/delete',{}).status_code,200)
        self.assertFalse(any(t['id']==key for t in self.client.get('/api/dashboard').json['trainings']))


if __name__=='__main__':unittest.main()
