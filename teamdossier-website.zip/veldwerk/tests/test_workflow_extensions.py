import io
import tempfile
import unittest
import zipfile
from pathlib import Path

import test_server as fixtures
from maintenance import backup


class WorkflowExtensionTests(unittest.TestCase):
    setUpClass=classmethod(fixtures.TeamTests.setUpClass.__func__)
    tearDownClass=classmethod(fixtures.TeamTests.tearDownClass.__func__)
    setUp=fixtures.TeamTests.setUp
    tearDown=fixtures.TeamTests.tearDown
    login=fixtures.TeamTests.login
    post=fixtures.TeamTests.post

    def upload_document(self, title='Beleidsplan'):
        return self.client.post('/api/club-documents',data={
            'title':title,'category':'Beleidsplan','team_id':'1','player_id':'1','note':'Versie één',
            'file':(io.BytesIO(b'%PDF-1.4 test'),'beleid.pdf')},
            headers={'X-CSRF-Token':self.csrf})

    def test_business_page_and_interest_are_public_but_leads_are_admin_only(self):
        self.assertEqual(self.client.get('/zakelijk').status_code,200)
        response=self.client.post('/zakelijk/interesse',data={'name':'Shane','organisation':'SV Test','email':'info@example.nl','phone':'','package':'Club','message':'Bel mij'})
        self.assertEqual(response.status_code,302)
        self.login('coach');self.assertEqual(self.client.get('/api/business-leads').status_code,403)
        self.login();rows=self.client.get('/api/business-leads').json['rows']
        self.assertEqual(rows[0]['organisation'],'SV Test')
        self.assertNotIn('kvk',rows[0])

    def test_mail_drafts_are_editable_and_real_send_requires_configuration(self):
        self.login()
        payload={'action':'draft','subject':'Training','body':'Donderdag om 19.30 uur','team_id':1,'player_id':1,'to_address':'speler@example.nl'}
        response=self.post('/api/mail',payload);self.assertEqual(response.status_code,200,response.json)
        key=response.json['id'];mail=self.client.get('/api/mail').json
        self.assertFalse(mail['smtp_configured']);self.assertEqual(mail['rows'][0]['direction'],'draft')
        self.assertEqual(self.post('/api/mail',{**payload,'id':key,'subject':'Gewijzigd'}).status_code,200)
        self.assertEqual(self.post('/api/mail',{**payload,'id':key,'action':'send'}).status_code,503)
        self.assertEqual(self.post(f'/api/mail/{key}/delete',{}).status_code,200)

    def test_documents_upload_edit_download_delete_and_backup(self):
        self.login();response=self.upload_document();self.assertEqual(response.status_code,200,response.json);key=response.json['id']
        row=next(d for d in self.client.get('/api/dashboard').json['club_documents'] if d['id']==key)
        self.assertNotIn('filename',row);self.assertEqual(row['player_id'],1)
        edit={'title':'Beleidsplan 2027','category':'Visieplan','team_id':1,'player_id':1,'note':'Definitief'}
        self.assertEqual(self.post(f'/api/club-documents/{key}',edit).status_code,200)
        download=self.client.get(f'/club-documents/{key}');self.assertEqual(download.status_code,200);self.assertEqual(download.data,b'%PDF-1.4 test');download.close()
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'backup.zip';backup(self.temp.name,target)
            with zipfile.ZipFile(target) as archive:self.assertTrue(any(n.startswith('data/club_documents/') for n in archive.namelist()))
        self.assertEqual(self.post(f'/api/club-documents/{key}/delete',{}).status_code,200)
        self.assertEqual(self.client.get(f'/club-documents/{key}').status_code,404)

    def test_document_rejects_player_from_another_team(self):
        self.login();response=self.client.post('/api/club-documents',data={'title':'Verkeerd','category':'Training','team_id':'1','player_id':'3','file':(io.BytesIO(b'x'),'x.pdf')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,400)

    def test_bulk_players_and_training_delete(self):
        self.login();response=self.post('/api/players/bulk',{'team_id':1,'rows':[{'shirt_number':11,'name':'Nieuwe speler','position':'Spits'},{'shirt_number':'','name':'Zonder nummer','position':''}]})
        self.assertEqual(response.status_code,200,response.json);self.assertEqual(response.json['count'],2)
        training=self.post('/api/trainings',{'team_id':1,'title':'Teamtraining','starts':'2027-08-01T19:00','ends':'2027-08-01T20:30','location':'Veld 1','notes':'Opbouwen','cancelled':False})
        self.assertEqual(training.status_code,200,training.json);key=training.json['id']
        self.assertEqual(self.post(f'/api/trainings/{key}/delete',{}).status_code,200)
        self.assertFalse(any(t['id']==key for t in self.client.get('/api/dashboard').json['trainings']))

    def superstar_import(self,kind,content,team='1'):
        return self.client.post('/api/superstar/import',data={'kind':kind,'team_id':team,'file':(io.BytesIO(content.encode()),'superstar.csv')},headers={'X-CSRF-Token':self.csrf})

    def test_superstar_exercises_and_development_are_reviewable_and_idempotent(self):
        self.login()
        settings=self.post('/api/superstar/settings',{'mode':'csv','organisation':'SV Test Academy','portal':'https://superstar.app/'})
        self.assertEqual(settings.status_code,200,settings.json)
        exercises='id;titel;leeftijd;teamtaak;thema;omschrijving;organisatie;coaching;minuten;spelers;bron\nss-1;Positiespel;O13;Opbouwen;Passing;Houd balbezit;Vier vakken;Open draaien;20;12;https://superstar.app/'
        response=self.superstar_import('exercises',exercises);self.assertEqual(response.status_code,200,response.json);self.assertEqual(response.json['created'],1)
        updated=exercises.replace('Positiespel','Positiespel vernieuwd')
        response=self.superstar_import('exercises',updated);self.assertEqual(response.status_code,200,response.json);self.assertEqual(response.json['updated'],1)
        development='id;speler;rugnummer;titel;doel;acties;categorie;succescriterium;evaluatiedatum;status;evaluatie\ndev-1;Speler A;9;Vrijlopen;Beter aanspeelbaar;Scannen en bewegen;Tactiek;Drie goede keuzes;2027-12-01;bezig;'
        response=self.superstar_import('development',development);self.assertEqual(response.status_code,200,response.json)
        dashboard=self.client.get('/api/dashboard').json
        self.assertEqual(dashboard['superstar']['organisation'],'SV Test Academy')
        self.assertEqual(dashboard['superstar']['counts'],{'development':1,'exercises':1})
        self.assertEqual([e['title'] for e in dashboard['exercises'] if e['title'].startswith('Positiespel')],['Positiespel vernieuwd'])
        self.assertTrue(any(p['title']=='Vrijlopen' and p['player_id']==1 for p in dashboard['plans']))

    def test_superstar_invalid_csv_is_atomic_and_players_cannot_import(self):
        self.login();bad='id;titel;leeftijd\na;Goed;O13\nb;Fout;O99'
        self.assertEqual(self.superstar_import('exercises',bad).status_code,400)
        self.assertFalse(any(e['title'] in ('Goed','Fout') for e in self.client.get('/api/dashboard').json['exercises']))
        self.login('player');valid='id;titel\nx;Oefening'
        self.assertEqual(self.superstar_import('exercises',valid).status_code,403)

    def test_player_tracking_bulk_entry_radar_data_and_progression_privacy(self):
        self.login()
        training=self.post('/api/trainings',{'team_id':1,'title':'RPE-training','starts':'2027-09-01T19:00','ends':'2027-09-01T20:30','location':'Veld','notes':'','cancelled':False}).json['id']
        selection=self.post('/api/selections',{'team_id':1,'selection_team':1,'opponent':'Tegenstander','kickoff':'2027-09-03T20:00','location':'Thuis','formation':'Nummers 1 t/m 11','notes':'','published':True,'players':[]}).json['id']
        evaluation={'player_id':1,'period':'September','evaluated_on':'2027-09-05','technical':4,'tactical':5,'physical':3,'mental':4,'social':5,'note':'Goede ontwikkeling'}
        self.assertEqual(self.post('/api/tracking/evaluations',evaluation).status_code,200)
        loads={'training_id':training,'rows':[{'player_id':1,'rpe':7,'minutes':90,'wellness':4},{'player_id':2,'rpe':6,'minutes':85,'wellness':3}]}
        self.assertEqual(self.post('/api/tracking/loads/bulk',loads).json['count'],2)
        matches={'selection_id':selection,'rows':[{'player_id':1,'minutes':90,'goals':1,'assists':1,'yellow':0,'red':0,'xg':0.8,'xa':0.4,'rating':8.1},{'player_id':2,'minutes':75,'goals':0,'assists':0,'yellow':1,'red':0,'xg':0.2,'xa':0.1,'rating':7}]}
        self.assertEqual(self.post('/api/tracking/matches/bulk',matches).json['count'],2)
        progression={'player_id':1,'target_team_id':2,'reviewed_on':'2027-09-06','readiness':4,'recommendation':'Meetraint met Team B','rationale':'Beoordeling, wedstrijdoutput en video','decision':'voordragen'}
        self.assertEqual(self.post('/api/tracking/progression',progression).status_code,200)
        tracking=self.client.get('/api/dashboard').json['tracking']
        self.assertEqual(tracking['evaluations'][0]['tactical'],5);self.assertEqual(tracking['loads'][0]['rpe'],7)
        self.assertEqual(tracking['matches'][0]['goals'],1);self.assertEqual(tracking['progression'][0]['decision'],'voordragen')
        self.login('player');own=self.client.get('/api/dashboard').json['tracking']
        self.assertEqual({r['player_id'] for r in own['loads']},{1});self.assertEqual(own['progression'],[])
        self.assertEqual(self.post('/api/tracking/evaluations',evaluation).status_code,403)

    def test_scout_can_be_added_as_staff_member(self):
        self.login();response=self.post('/api/staff',{'name':'Scout Eén','role':'Scout','email':'scout@example.nl','phone':'','bio':'Regioscout','specialties':'O13–O17','qualifications':'Scoutingsopleiding','team_ids':[1]})
        self.assertEqual(response.status_code,200,response.json)
        scout=next(s for s in self.client.get('/api/dashboard').json['staff'] if s['name']=='Scout Eén')
        self.assertEqual(scout['role'],'Scout');self.assertEqual(scout['specialties'],'O13–O17')


if __name__=='__main__':unittest.main()
