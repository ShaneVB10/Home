# Teamdossier.nl — besloten voetbalteamomgeving

Deze zelfstandige teamwebsite staat naast de bestaande VoetbalZeeland-redactieapp. Python 3.12+, FFmpeg en FFprobe zijn vereist. Er is geen openbare registratie. Alleen een beheerder kan accounts uitgeven, wachtwoorden opnieuw instellen en accounts blokkeren.

## Installeren als app

Teamdossier.nl is voorbereid als installeerbare webapp (PWA). Dezelfde website en accounts worden gebruikt; er is geen aparte App Store- of Google Play-publicatie. Installeer eerst de nieuwste versie op de HTTPS-hosting en klik op Reload. Open daarna de website op je telefoon:

- **iPhone/iPad:** open in Safari, kies de deelknop → **Zet op beginscherm** → eventueel **Open als webapp** → **Voeg toe**.
- **Android:** open in Chrome, gebruik **App installeren** op de website of kies via het browsermenu **App installeren / Toevoegen aan startscherm**.
- **Computer:** Chrome/Edge kunnen een installatieknop in de adresbalk aanbieden.

De site bevat ook installatiehulp voor browsers die geen directe installatieprompt aanbieden. Geïnstalleerd opent Teamdossier.nl in een eigen venster met app-icoon. Internet blijft nodig voor inloggen, teamgegevens, foto's, video's en bewerken.

De serviceworker slaat uitsluitend een openbare offline-melding, het bijbehorende CSS-bestand en het openbare app-icoon op. HTML van het dashboard, API-antwoorden en privébestanden worden niet in de PWA-cache bewaard. Zonder verbinding verschijnt bij openen van de app een algemene melding. Er is geen offline invoer of synchronisatie. Gewijzigde sitebestanden worden bij opnieuw openen online opnieuw gecontroleerd. Bij een nieuwe serviceworkerversie wordt vernieuwen aangeboden; dit gebeurt niet automatisch terwijl een formulier openstaat.

De website heeft een homepagina met voetbalachtergrond en onderdelen voor teams, spelers, trainingen, aanwezigheid, selecties/opstellingen, ontwikkelplannen, rapporten, video’s, oefenstof, presentaties en wedstrijdgegevens. Accountbeheer en clubinstellingen zijn alleen voor de beheerder zichtbaar. Zie [HOSTING.md](HOSTING.md) voor WSGI-hosting, de verwerkingswachtrij en back-ups.

## Samengevoegde werkruimte

- **Overzicht:** toont de laatst geregistreerde aantallen aanwezige/afwezige spelers en aanwezige staf, het aanwezigheidspercentage per speler en openstaande agenda-/taakmeldingen.
- **Trainingsplanning:** training, stafaanwezigheid, spelersaanwezigheid, oefenstof, het veld “Wat gaan we doen?” en trainingsdocumenten staan bij elkaar. Losse trainingen kunnen worden verwijderd.
- **Wedstrijdselectie:** start standaard met posities 1 t/m 11. De overige statussen zijn Bank, 2e elftal en Niet bij de selectie. Wedstrijddocumenten kunnen per seizoen worden toegevoegd.
- **Clubdocumenten:** beveiligde PDF-, Word-, Excel-, PowerPoint-, TXT- en CSV-bestanden voor beleid, visie, training, wedstrijdselectie, ontwikkelplannen en rapporten. Metadata kan worden gewijzigd; downloaden en verwijderen volgen de bestaande rechten en seizoensgrenzen.
- **Teams en staf:** ieder spelersprofiel opent vanuit het teamscherm. Een lijst van maximaal 100 spelers kan in één keer worden geplakt. Stafprofielen bevatten foto, functie, contactgegevens, specialismen, opleidingen en verantwoordelijkheden.
- **Oefenstof en video:** leeftijdsmappen O8 t/m O23 en Mijn oefenstof staan op de oefenstofpagina. Teamtaken staan bij de videobibliotheek. Het tekenbord ondersteunt spelers, bal, dopjes, doelen en pass-, loop- en dribbellijnen.
- **Cluborganisatie:** agenda, taken, HJO, scouting, trainingsvoorstellen, spelersrapporten, ouderportaal en materiaal/velden hebben een eigen klikbare map met toevoegen, wijzigen en verwijderen. Tegenstanders staat als aparte pagina.
- **Mail & berichten:** staat los van Cluborganisatie. Concepten en interne berichten werken direct; echte verzending en ontvangen e-mail vereisen SMTP-/IMAP-instellingen uit `deploy/teamdossier.env.example`.
- **Zakelijk:** `/zakelijk` is de openbare pakketten- en contactpagina. De beheerder ziet aanvragen in Zakelijk beheer. Meerdere fysiek gescheiden clubomgevingen en `/eigenaar` werken met `saas_wsgi.py` op een VPS.

## Spelersvolgsysteem, Super Star en trainer-coach

- **Periodieke evaluaties:** technisch, tactisch, fysiek, mentaal en sociaal op schaal 1–5, met gesprek/periode, toelichting en radarplot. Een nieuwe evaluatie neemt de vorige scores als uitgangspunt.
- **Trainingsbelasting:** RPE 1–10, trainingsminuten, sessiebelasting (RPE × minuten), fitheid/herstel en notitie. Vul één speler in of het hele team in één tabel met vooraf ingevulde standaardwaarden.
- **Wedstrijdstatistieken:** speelminuten, goals, assists, gele/rode kaarten, xG, xA, wedstrijdscore en notitie. Ook dit kan per speler of voor het hele team tegelijk.
- **Doorstroming:** een onderbouwd advies met doelteam, gereedheid, status en argumenten uit evaluaties, belasting, wedstrijden, scouting en video. Spelers zien interne doorstroomadviezen niet.
- **Scouts:** voeg een Scout of Hoofd scouting als staflid toe, met foto, teams, regio/specialismen, opleiding en contactgegevens. De aparte scoutingpagina bevat bewerkbare scoutingsrapporten en vervolgacties.
- **Super Star Academy:** een veilige portal-link en herhaalbare CSV-import voor oefenstof en spelersontwikkeling. Bestaande gekoppelde records worden op Super Star-id bijgewerkt. Wachtwoorden worden niet opgeslagen. Een officiële API werkt pas wanneer de leverancier toegang en documentatie verstrekt en `TEAM_SUPERSTAR_API_TOKEN` beveiligd op de server staat.
- **KNVB-kompas:** Trainingsplanning en Oefenstof tonen de vier gouden trainingsprincipes: voetbalecht trainen, veel prikkels en plezier, coaching en organisatie, en afstemming op de spelers. Ook de vier trainer-coachkwaliteiten zijn opgenomen: structuur bieden, stimuleren, individuele aandacht geven en verantwoordelijkheid geven.

## Uitbreidingen november 2026

- **Spelersfoto:** beheerder/trainers met bewerkrechten kunnen een JPG, PNG of WebP van maximaal 5 MB en 20 megapixels toevoegen of vervangen. De foto verschijnt op kaart en profiel, wordt na controle maximaal 640×640 opgeslagen als JPEG en krijgt geen EXIF-metadata mee. De fotobestanden staan privé in `data/photos/` en worden met dezelfde speler-/teamrechten als het profiel aangeboden. Spelers kunnen alleen hun eigen foto bekijken; uploaden is voor bevoegde staf. Voor verwerking is Pillow nodig; installeer de bijgewerkte requirements.
- **Beoordelingen aanpassen:** in een spelersprofiel of het observatieoverzicht kan bevoegde staf een bestaande beoordeling aanpassen. Categorie, cijfer en toelichting zijn wijzigbaar. De oorspronkelijke aanmaakdatum en auteur blijven staan; laatste bewerker en wijzigingsdatum worden bijgehouden. De beoordeling wordt niet gedupliceerd en rapportgemiddelden worden herberekend. Spelers kunnen hun beoordelingen niet zelf wijzigen.
- **PowerPoint en uploadfouten:** reguliere `.pptx`-bestanden kunnen als bijlage worden opgeslagen en gedownload, maximaal 25 MB. Een presentatie van 317 MB valt daarbuiten: gebruik een HTTPS-kijklink uit OneDrive/Google Drive of verklein de presentatie. De webapp controleert de grootte vóór upload. HTML-fouten van de hosting worden nu omgezet in een leesbare melding met HTTP-status, in plaats van `Unexpected token '<'`. Externe kijklinks volgen ook de rechten van de externe dienst; deel alleen met de bedoelde personen.

- **Trainingsplanning en aanwezigheid:** plan trainingen per team met begin/eindtijd, locatie, notities en gekoppelde oefenstof. Een training kan worden gewijzigd of geannuleerd. Spelers geven hun eigen beschikbaarheid vóór de training door; alleen trainers/beheerder registreren daadwerkelijke aanwezigheid. Een aanmelding telt dus niet als aanwezig. De training neemt bij opslaan de huidige spelersgroep op; sla opnieuw op om nieuwe teamleden toe te voegen.
- **Wedstrijdselecties en opstellingen:** maak een selectie met basis, Bank, 2e elftal en Niet bij de selectie in achttien elftalformaties. Concepten zijn uitsluitend voor bevoegde staf; na publicatie ziet het eigen team de selectie en teamnotities. Teamgenoten krijgen alleen namen, rugnummers en positie/status uit de selectie, geen toegang tot elkaars privéprofielen. Een speler en een basispositie kunnen slechts eenmaal in een selectie voorkomen.
- **Individuele ontwikkelplannen:** per speler doelen, categorie, acties, succescriteria, evaluatiedatum, voortgang en evaluatie. Trainers met de juiste rechten kunnen wijzigen; spelers zien alleen hun eigen plannen en kunnen deze niet aanpassen.
- **Filters en categorieën:** filter video’s op speler, soort, vrije categorie, uploadperiode, analysestatus en teamfunctie. Video’s kunnen zonder teamfunctie én zonder teamtaak worden opgeslagen en teruggevonden. Oefenstof heeft optionele teamtaak, vrije extra categorie en doelgroep. De centrale zoekfunctie doorzoekt ook toegankelijke trainingen, selecties en ontwikkelplannen.
- **Statistieken en rapporten:** per speler geregistreerde aanwezigheid, gepubliceerde selecties/basisplaatsen, trainersbeoordelingen, ontwikkelplannen, clips en gemarkeerde momenten. Filters op team, speler en periode; CSV-download en afdrukweergave voor opslaan als PDF in de browser. Aanwezigheidspercentage gebruikt alleen aanwezig/(aanwezig+afwezig); onbekend, vrijgesteld en geannuleerd tellen niet mee. Beschikbaarheid telt niet als aanwezigheid. De periode gebruikt trainings-/wedstrijddatum en voor overige gegevens aanmaakdatum. Onderdelen zonder toegangsrecht blijven leeg in het rapport, niet een schijnbare nul. CSV-tekstvelden worden tegen formule-injectie beschermd.
- **Nieuwe rechten:** afzonderlijk voor trainingsplanning, aanwezigheid/beschikbaarheid, selecties, ontwikkelplannen en rapporten. De basisrol speler mag bij beschikbaarheid schrijven, maar alleen de eigen aanmelding; de server weigert wijzigingen aan echte aanwezigheid of een andere speler. Bestaande accounts met aangepaste rechten krijgen nieuwe onderdelen standaard niet: de beheerder kan ze expliciet inschakelen. Basisrollen zonder aangepaste rechten krijgen hun standaardrechten voor de nieuwe onderdelen.

- **Teamtaken:** zes vaste mappen: Opbouwen, Kansen creëren, Opbouw verstoren, Kansen voorkomen, Omschakelen V-A en Omschakelen A-V. Teamtaak is optioneel; gebruik ‘Zonder teamtaak’ voor ongecategoriseerde beelden. Bekende oude namen Opbouw, Drukzetten en Kansen creeren worden bij de databasemigratie omgezet. Andere bestaande taaknamen blijven behouden en zichtbaar in de ongefilterde bibliotheek.
- **Zoeken:** een centrale zoekpagina voor toegankelijke teams, spelers, video’s, oefenstof en presentaties, plus filters binnen de bibliotheken. Verborgen gegevens worden door de server uit de dataset gehouden.
- **Gedeeltelijke toegang:** de beheerder stelt per account per onderdeel geen toegang, lezen of lezen/bewerken in, en kiest alle toegestane teams of een specifieke selectie. De rechten kunnen de basisrol alleen beperken: spelers blijven bij hun eigen profiel, clips, plannen en team, met uitsluitend de eigen beschikbaarheid als schrijfbare uitzondering. Het ontwikkeloverzicht gebruikt de toegankelijke spelersdata. Een wijziging trekt bestaande sessies in. De oefenstofbibliotheek is gedeeld op clubniveau; toegang daartoe wordt per onderdeel geregeld.
- **Oefenstof:** eigen oefeningen per teamtaak met beschrijving, duur, doelgroep, organisatie, coachaccenten en een optionele HTTPS-bronlink. Er zijn geen ongecontroleerde externe oefeningen of verzonnen bibliotheekrecords vooraf ingevuld.
- **Wedstrijdpresentaties:** PDF/PPTX-upload (maximaal 25 MB) of een externe HTTPS-link, met team, datum, tegenstander en toelichting. Bestanden staan buiten de statische map en worden alleen met module- én teamrechten aangeboden. Externe links hebben daarnaast de rechten van de externe aanbieder. Alleen presentaties van toegankelijke teams verschijnen in zoeken en overzichten.
- **Voetbal.nl-pagina:** de beheerder koppelt lokale teams aan het 1e en 2e elftal en bewaart officiële Voetbal.nl-links. Programma, uitslagen en stand kunnen met CSV worden geïmporteerd. Dit is **nog geen automatische Voetbal.nl/Sportlink-koppeling**. Er is geen officiële gegevensverbinding geleverd; het raadplegen van beide websites gaf hier proxy-403. Er worden geen accountwachtwoorden opgeslagen of niet-geverifieerde API-eindpunten gebruikt.

### Wedstrijdgegevens importeren

UTF-8 CSV met komma, puntkomma of tab; maximaal 1 MB. Voor programma/uitslagen:

```csv
datum;thuis;uit;thuisdoelpunten;uitdoelpunten
2026-11-14T14:30;Eigen team;Tegenstander;;
```

Vul beide eindscores in voor een uitslag. Import werkt bestaande wedstrijden bij op team/datum/clubs. Voor de stand:

```csv
ploeg;positie;gespeeld;punten
Eigen team;1;4;12
```

Een stand-import vervangt de bestaande stand van het geselecteerde team. Bij ongeldige gegevens wordt niets geïmporteerd. Gegevens blijven gemarkeerd als CSV-import; ze worden niet als live Voetbal.nl-data gepresenteerd.

## Installatie en eerste account

```sh
cd /workspace/Home/team_app
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python server.py create-admin --username beheerder
.venv/bin/python server.py
```

Het eerste beheerderswachtwoord wordt interactief en verborgen ingevoerd (minimaal 12 tekens); er zijn geen standaardaccounts of standaardwachtwoorden. Voer de accountopdracht uit voordat de server wordt gestart. Deel nooit wachtwoorden in Git of chat. De lokale server gebruikt poort 8001. De redactieapp blijft op poort 8000 beschikbaar. `TEAM_DATA`, `TEAM_HOST` en `TEAM_PORT` zijn instelbaar. Bewaar een back-up van de volledige datamap, inclusief de SQLite-database én videobestanden.

## Rechten

| Rol | Toegang |
| --- | --- |
| Beheerder | Alle sportgegevens; teams en accounts aanmaken; accounts blokkeren en wachtwoorden instellen |
| Trainer | Alle teams en spelers; spelersprofielen, observaties en video's toevoegen |
| Speler | Eigen profiel, observaties, clips, plannen en rapport; trainingen en gepubliceerde teamselecties; standaard alleen lezen, behalve de eigen beschikbaarheid |

De server controleert rechten ook op individuele videoverzoeken (inclusief byte-rangeverzoeken). Een clip zonder speler is een trainersclip; alleen als **volledige wedstrijd** gemarkeerde video's zijn voor alle spelers van dat team zichtbaar. Rugnummers 1–99 moeten uniek zijn binnen een team. Beoordelingen zijn handmatige trainersscores.

Wachtwoorden worden met scrypt gehasht. Sessies verlopen na 8 uur, gebruiken HttpOnly/SameSite-cookies en worden na blokkering of wachtwoordreset ingetrokken. Schrijfverzoeken vereisen een CSRF-token. Inloggen is begrensd op 8 mislukte pogingen per 15 minuten per IP-adres. Er is nog geen accountherstel via e-mail; de beheerder stelt een nieuw wachtwoord in.

## Video's en automatisch bijwerken

- Upload geëxporteerde Veo-video's of losse MP4/WebM/MOV-bestanden (maximaal 512 MB per upload). H.264/MP4 heeft de breedste browserondersteuning.
- Koppel beelden aan team, optioneel een speler, teamtaak en teamfunctie.
- Na upload valideert FFprobe de video en start achtergrondanalyse (maximaal 2 gelijktijdig). De analyse meet duur, resolutie en gemiddelde pixelverandering op 1 beeld per seconde in de eerste 120 seconden. Camerabeweging beïnvloedt deze waarde; dit is geen voetbalprestatiemeting.
- Profielen en overzichten laden elke 5 seconden nieuwe gegevens. Ontwikkelscores zijn gemiddelden van de handmatige observaties per onderdeel.
- Trainers kunnen bij het afspelen van een video momenten vastleggen met tijdstip, speler, actie/teamgedrag, beoordeling en feedback. Klik op het tijdstip om terug te springen. Spelers zien uitsluitend hun eigen feedback; markeringen geven geen extra toegang tot een afgeschermde video.
- Het ontwikkeloverzicht bundelt trainersscores en aantallen gemarkeerde momenten. Dit zijn geen automatisch herkende voetbalacties. Teams kunnen worden hernoemd en videogegevens kunnen worden aangepast; toegangsrechten worden daarbij opnieuw gecontroleerd.
- Onderbroken analyses worden bij serverherstart als mislukt gemarkeerd en kunnen opnieuw gestart worden. Dit is een lokale werkqueue, nog geen productiequeue.

## Nog vereist voor de volledige gevraagde automatisering

Automatische herkenning van rugnummers, spelersacties en teamgedrag is **niet** geïmplementeerd. Hiervoor zijn representatieve Veo-beelden, teamopstellingen/wissels, een gevalideerd analysemodel en een geschikte uitvoeromgeving nodig. Een rugnummer in het spelersprofiel identificeert nog geen speler in videobeelden. Er worden geen voetbalgebeurtenissen of spelersscores uit technische beeldverandering afgeleid.

Een directe Veo-koppeling is nog niet aangesloten. Er is nog geen API/feed-toegang vastgesteld; een Veo-account alleen bewijst die toegang niet. Gebruik voorlopig video-export en upload. Geef geen Veo-wachtwoord aan de applicatie.

Automatisch deployen van software is nog niet aangesloten. WSGI-configuratie, een back-upcommando, GitHub CI en Dependabot-configuratie zijn voorbereid. CI en dependency-voorstellen starten pas na push naar GitHub en inschakeling van de betreffende functies. Voor deployment ontbreken het hostingaccount en een daar geteste terugvalprocedure. Er wordt geen onbekende code automatisch uitgevoerd. Nieuwe releases moeten accounts en video's behouden.

## Productie

De ingebouwde server is uitsluitend voor lokale ontwikkeling. Gebruik voor een publieke website een productie-WSGI-server achter HTTPS, zet `TEAM_HTTPS=1` voor Secure-cookies en configureer de proxy met uploadlimieten, opslagquota, back-ups en correcte client-IP-doorgifte voor inloglimieten. `wsgi.py` gebruikt standaard Secure-cookies en uitgestelde analyse (`deferred`). Verwerk die wachtrij met `server.py analyse-pending`; gebruik een ondersteunde planner voor automatische verwerking. Er zijn nog geen productie-auditlog, automatische back-ups of bewaartermijnen. Video's worden lokaal opgeslagen; voor meerdere serverprocessen of grote bibliotheken zijn objectopslag en een duurzame werkqueue nodig.

## Tests

```sh
cd /workspace/Home/team_app
.venv/bin/python -m unittest discover -s tests -v
node --check static/app.js
node --check static/pages.js
node --check static/library.js
node --check static/planning.js
node --check static/pwa.js
node --check static/sw.js
```

De tests gebruiken tijdelijke data en een daadwerkelijk met FFmpeg gegenereerde testvideo. Ze controleren onder meer accountrechten, afgeschermde video's, CSRF, sessie-intrekking, rugnummers, uploadvalidatie en de echte achtergrondanalyse. Er is nog geen gevalideerde voetbalinhoudelijke herkenningstest, omdat die functie nog ontbreekt.

## Websitepakket maken

```sh
.venv/bin/python maintenance.py --output /tmp/veldwerk-website.zip
```

Het ZIP-bestand bevat alle benodigde bronbestanden, statische afbeeldingen, tests en de installatiehandleiding. Accounts, databases, videobestanden, spelersfoto’s, virtualenv en caches worden niet meegenomen. Bestaande ZIP-bestanden worden niet overschreven.


## Seizoenen, snelle planning, staf en medische dossiers

- Kies bovenaan het seizoen. De eerste keer worden bestaande spelers, beelden, beoordelingen, trainingen, presentaties en wedstrijdgegevens aan het eerste seizoen gekoppeld. Deze migratie bewaart de gegevens en bestanden en is herhaalbaar. Maak vooraf een privéback-up.
- Beheerder: **Seizoenen beheren** maakt een seizoen met een eigen spelersgroep. Je kunt spelers en staf uit het gekozen seizoen overnemen. Opstellingen, beelden, trainingen en medische registraties blijven bij het oorspronkelijke seizoen. Stel één standaardseizoen in; iedereen kan zelf een ander seizoen bekijken. Archiveren voorkomt wijzigingen, heropenen maakt correcties mogelijk. Er is geen knop om seizoenen te verwijderen.
- Spelersnamen en profielfoto's worden als actuele profielgegevens gedeeld tussen seizoenen; teamindeling, rugnummer, positie en ontwikkeldoel zijn per seizoen opgeslagen. Oefenstof is een blijvende bibliotheek met mappen per team en een clubbrede map.
- **Trainingen voor een periode**: kies begin/einde, teams, vaste dagen, tijden en eventueel uitzonderingsdatums. Bekijk het aantal en maak de reeks aan. Reeds bestaande trainingen met dezelfde team/starttijd worden overgeslagen. Pas deze en volgende trainingen als reeks aan; aanwezigheid en gekoppelde oefeningen blijven staan. Je kunt een losse training kopiëren naar de volgende week.
- **Aanwezigheid**: klik een status aan of opnieuw om die leeg te maken. Typ een reden en verlaat het veld om automatisch op te slaan. De groepsactie zet uitsluitend onbekende aanwezigheid op aanwezig en slaat afgemelde/geblesseerde spelers over. Ongedaan maken verandert uitsluitend ongewijzigde rijen. Gelijktijdige wijzigingen geven een conflictmelding; je kunt opnieuw proberen of je wijziging laten vervallen om de serverversie te laden. Onopgeslagen wijzigingen blijven gemarkeerd.
- **Selectie**: Bank vervangt Reserve (oude registraties blijven leesbaar als Bank). De labels 2e elftal en Niet bij de selectie veranderen alleen deze wedstrijdselectie, niet het vaste team van een speler. Een andere formatie behoudt de ingevulde spelers waar mogelijk.
- **Spelers** toont lijsten onder elkaar voor de gehele selectie, het 1e, 2e en andere teams. De koppeling van 1e/2e elftal gebruikt de bestaande Voetbal.nl-teaminstelling; zonder koppeling worden de eerste twee zichtbare teams gebruikt.
- **Stafleden** bevat naam, functie, contactgegevens en teams. Vink bij een training of wedstrijdselectie aanwezige staf aan. Een stafprofiel geeft geen account: alleen de beheerder maakt accounts aan.
- **Medische staf** en **Blessuremonitor** zijn afzonderlijk afgeschermd. De beheerder heeft toegang. Trainers krijgen medische toegang uitsluitend wanneer de beheerder dit expliciet instelt via Toegangsbeheer. Maak voor een medisch staflid een stafaccount. De knop **Medisch account instellen** kiest medische bewerkrechten, inzage in staf en alleen het eerste zichtbare team; controleer en pas de teams aan voordat je opslaat. Geef alleen de benodigde onderdelen toegang. Spelersaccounts hebben geen medische toegang. Medische dossiers worden niet opgenomen in algemeen zoeken, spelersprofielen, algemene rapporten of de dashboard-API.
- **Meten & wegen** bewaart meetdatum, lengte, gewicht en toelichting. Bekijk en wijzig metingen en het verschil met de vorige gewichtsmeting. **Blessures** bewaren lichaamsdeel/zijde, ontstaan, klachten, herstelfase, trainingsbeperkingen, verwachte terugkeer, volgende controle en afsluitdatum. Controles/behandelingen hebben een apart bewerkbaar logboek met bevindingen en acties. Filter op speler, herstelfase en open/afgesloten dossiers; eerdere blessures blijven raadpleegbaar. De medische staf bepaalt zelf inzetbaarheid en terugkeer; er wordt geen automatische diagnose gemaakt.
- Observaties verwijderen verbergt ze uit profielen en rapporten. **Ongedaan maken** herstelt de laatst verwijderde observatie zolang je in dezelfde sessie en hetzelfde seizoen blijft. De server bewaart de verwijderde registratie.

Gebruik voor echte persoonsgegevens HTTPS, persoonlijke accounts met passende teamrechten en een beveiligde privéback-up. Medische registraties staan in dezelfde privé-SQLite-database en worden dus in een volledige databack-up meegenomen. De broncode-ZIP bevat geen accounts, dossiers, uploads of database. De app bewaart privégegevens niet in de offlinecache.

## Verkoopbare klantomgevingen

`saas_wsgi.py` is het productie-entrypoint voor meerdere klanten. Het hoofddomein toont het platform; een subdomein zoals `svterheijden.teamdossier.nl` wordt uitsluitend gekoppeld aan `tenant_data/svterheijden`. Iedere klant heeft een eigen SQLite-database, video-, foto- en documentenmap. Er staat geen `tenant_id` in één gedeelde medische database: de scheiding vindt fysiek op map- en databaseniveau plaats.

Maak de platformbeheerder eenmalig aan met:

```bash
.venv/bin/python saas.py create-platform-admin --username Shane
```

Stel in productie minimaal deze omgevingsvariabelen in:

```text
TEAM_BASE_DOMAIN=teamdossier.nl
TEAM_PLATFORM_DATA=/beveiligd/pad/platform
TEAM_TENANT_ROOT=/beveiligd/pad/tenants
TEAM_PLATFORM_SECRET=<lange willekeurige waarde>
TEAM_AUDIT_KEY=<andere lange willekeurige waarde>
TEAM_HTTPS=1
TEAM_ENFORCE_HTTPS=1
TEAM_TRUST_PROXY=1
TEAM_LEGAL_NAME=Teamdossier.nl
TEAM_LEGAL_ADDRESS=<correspondentieadres>
TEAM_PRIVACY_EMAIL=<privacy-contactadres>
TEAM_SUBPROCESSORS=<hosting, back-up, e-mail en betaling>
```

Vertrouw `X-Forwarded-*` uitsluitend wanneer Nginx de enige directe proxy is. Configureer wildcard-DNS en een wildcard-TLS-certificaat voor `*.teamdossier.nl`. Het platform kan een voetbalvereniging activeren of blokkeren, maar bevat geen functie om klantdata direct te openen of te verwijderen.

Iedere klantdatabase bevat een auditlog van muterende verzoeken met gebruiker, pad, status en verzoeknummer. De inhoud van medische dossiers en formulierwaarden wordt niet gelogd. Stel de bewaartermijn in met `TEAM_AUDIT_RETENTION_DAYS`; standaard is 365 dagen.

## Versleutelde klantback-ups

Genereer één keer een willekeurige sleutel en bewaar deze buiten de server en buiten de back-upopslag:

```bash
.venv/bin/python saas_backup.py generate-key
```

Zet het resultaat als `TEAM_BACKUP_KEY` in een beveiligde secret store. Maak daarna vanuit cron of een systemd timer een back-up:

```bash
.venv/bin/python saas_backup.py backup-all \
  --platform-db /beveiligd/pad/platform/platform.db \
  --tenant-root /beveiligd/pad/tenants \
  --output-dir /andere-versleutelde-back-uplocatie
```

Elke back-up gebruikt AES-256-GCM, wordt na het schrijven direct geverifieerd en bevat precies één klant. Herstel gebeurt bewust uitsluitend naar een nieuwe map:

```bash
.venv/bin/python saas_backup.py restore --file klant-datum.tdbk --output /tijdelijk/hersteltest
```

Test herstel periodiek en stel retentie in bij de externe back-upleverancier. Zonder `TEAM_BACKUP_KEY` zijn de back-ups niet leesbaar; verlies van de sleutel betekent verlies van de back-ups.

De routes `/privacy` en `/verwerkersovereenkomst` bevatten Nederlandse conceptteksten zonder KvK-veld. De voetbalvereniging is verwerkingsverantwoordelijke; Teamdossier is verwerker. Vul adres, privacycontact, hostinglocaties, subverwerkers, termijnen en contractgegevens in en laat de teksten juridisch controleren voordat klanten ondertekenen.
# Slimme wedstrijdhub, VEO en koppelingen

Het ontwikkeloverzicht bevat een controleerbare video-workflow. Een beheerder kiest of de club werkt met een normaal VEO-account, exports of een officiële API. VEO-wachtwoorden worden nooit in Teamdossier opgeslagen. Wedstrijdlinks kunnen aan een geüploade volledige wedstrijd worden gekoppeld. Een CSV-export met `start;eind;rugnummer;actie;teamtaak;teamfunctie;betrouwbaarheid` wordt automatisch aan de selectie en rugnummers van het gekozen seizoen gekoppeld. Een trainer keurt ieder voorstel goed of wijst het af voordat het als videomoment in een spelersdossier verschijnt.

Een officiële VEO API-sleutel wordt uitsluitend als `TEAM_VEO_API_TOKEN` op de server ingesteld. Teamdossier claimt geen directe VEO-download of inhoudelijke AI-herkenning wanneer die officiële toegang en een getest analysemodel ontbreken.

Programma, live scores en uitslagen kunnen handmatig worden ingevoerd en gecorrigeerd. De productieomgeving verwacht voor automatische synchronisatie een contract met een officiële dataleverancier, ingesteld via `TEAM_SCORES_PROVIDER` en een leveranciersadapter. Het administratorgedeelte heeft centraal koppelingenbeheer voor uitslagen, video, e-mail, agenda, opslag en overige HTTPS-API’s. Daar kan de beheerder koppelingen toevoegen, wijzigen, pauzeren, controleren en verwijderen. API-sleutels en wachtwoorden worden niet via dit formulier opgeslagen.

# Tekenbord voor oefenstof

Trainers met schrijfrechten kunnen bij eigen oefeningen een veldtekening opslaan. Het tekenbord ondersteunt rode en blauwe spelers, ballen, dopjes, doelen, passlijnen en looplijnen. Veldtekeningen zijn gewone oefengegevens en vallen daardoor onder dezelfde teamrechten, back-up en klantisolatie. De ingebouwde clubbibliotheek blijft alleen-lezen; maak een eigen oefening om een tekening toe te voegen.

