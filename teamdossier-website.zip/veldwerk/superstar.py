"""Reviewable bridge for Super Star Academy development plans and exercises."""
import csv
import io
import os
import time
from datetime import datetime
from urllib.parse import urlsplit

from flask import abort, g, jsonify, request
from permissions import TASKS

AGES=('O8','O9','O10','O11','O12','O13','O14','O15','O16','O17','O18','O19','O23')
PLAN_CATEGORIES=('Techniek','Tactiek','Fysiek','Mentaliteit')
PLAN_STATUSES=('gepland','bezig','behaald','gestopt')

def register_superstar(app,db,protect,require,permitted,team_allowed,admin,text):
    with app.app_context():
        db().execute('''CREATE TABLE IF NOT EXISTS superstar_records(kind TEXT NOT NULL,external_id TEXT NOT NULL,
          season_id INTEGER NOT NULL,local_id INTEGER NOT NULL,updated REAL NOT NULL,
          PRIMARY KEY(kind,external_id,season_id))''')
        for key,value in (('superstar_mode','csv'),('superstar_organisation',''),('superstar_portal','https://superstar.app/')):
            db().execute('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)',(key,value))
        db().commit()

    def https_url(value):
        value=str(value or '').strip()
        try:
            parsed=urlsplit(value)
            if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or len(value)>2000:raise ValueError()
        except ValueError:abort(400,'Gebruik een geldige HTTPS-link zonder gebruikersnaam of wachtwoord.')
        return value

    def rows_from_upload():
        upload=request.files.get('file');raw=upload.stream.read(2_000_001) if upload else b''
        if not upload or not raw or len(raw)>2_000_000:abort(400,'Kies een CSV-bestand van maximaal 2 MB.')
        try:
            content=raw.decode('utf-8-sig');dialect=csv.Sniffer().sniff(content[:4096],delimiters=',;\t')
            rows=list(csv.DictReader(io.StringIO(content),dialect=dialect))
        except (UnicodeError,csv.Error):abort(400,'De CSV kon niet worden gelezen. Gebruik UTF-8 met komma, puntkomma of tab.')
        if not rows or len(rows)>3000:abort(400,'Gebruik een CSV met 1 tot 3000 regels.')
        return [{str(k or '').strip().lower():str(v or '').strip() for k,v in row.items()} for row in rows]

    def chosen_team():
        team=int(request.form.get('team_id') or 0)
        if not team_allowed(team) or not db().execute('SELECT 1 FROM teams WHERE id=?',(team,)).fetchone():abort(403,'Kies een toegankelijk team.')
        return team

    @app.post('/api/superstar/settings')
    @protect
    def settings():
        admin();p=request.get_json();mode=str(p.get('mode','csv'))
        if mode not in ('link','csv','api'):abort(400,'Kies link, CSV-import of officiële API.')
        values={'superstar_mode':mode,'superstar_organisation':text(p,'organisation',200,False),'superstar_portal':https_url(p.get('portal') or 'https://superstar.app/')}
        db().executemany('INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)',values.items());db().commit()
        return jsonify(ok=True)

    @app.post('/api/superstar/import')
    @protect
    def import_csv():
        if g.user['role']=='player':abort(403,'Alleen bevoegde staf kan importeren.')
        kind=str(request.form.get('kind',''));team=chosen_team();rows=rows_from_upload();now=time.time()
        if kind=='exercises':
            require('exercises',True);required={'id','titel'}
            if not required.issubset(rows[0]):abort(400,'Vereiste kolommen voor oefenstof: id en titel.')
            clean=[];seen=set()
            for row in rows:
                external=row.get('id','');title=row.get('titel','');task=row.get('teamtaak','');age=row.get('leeftijd','');source=row.get('bron','')
                if not external or len(external)>200 or external in seen or not title or len(title)>200:abort(400,'Controleer unieke id en titel; er is niets geïmporteerd.')
                if task and task not in TASKS:abort(400,'Onbekende teamtaak bij '+title+'.')
                if age and age not in AGES:abort(400,'Onbekende leeftijd bij '+title+'.')
                try:minutes=int(row.get('minuten') or 15)
                except ValueError:abort(400,'Ongeldige duur bij '+title+'.')
                if not 1<=minutes<=240:abort(400,'Duur moet 1 tot 240 minuten zijn bij '+title+'.')
                if source:source=https_url(source)
                seen.add(external);clean.append((external,title,task,row.get('omschrijving','')[:5000],row.get('organisatie','')[:3000],row.get('coaching','')[:3000],minutes,row.get('spelers','')[:100],source,row.get('thema','')[:120],age))
            db().execute('BEGIN IMMEDIATE');created=updated=0
            for external,title,task,description,setup,coaching,minutes,players,source,theme,age in clean:
                mapped=db().execute("SELECT local_id FROM superstar_records WHERE kind='exercise' AND external_id=? AND season_id=0",(external,)).fetchone()
                values=(title,task,description,setup,coaching,minutes,players,source,theme,age,team)
                if mapped and db().execute('SELECT 1 FROM exercises WHERE id=?',(mapped['local_id'],)).fetchone():
                    db().execute('UPDATE exercises SET title=?,category=?,description=?,setup=?,coaching=?,minutes=?,players=?,url=?,theme=?,age_group=?,team_id=? WHERE id=?',(*values,mapped['local_id']));local=mapped['local_id'];updated+=1
                else:
                    local=db().execute('INSERT INTO exercises(title,category,description,setup,coaching,minutes,players,url,theme,age_group,team_id,created) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',(*values,now)).lastrowid;created+=1
                db().execute("INSERT INTO superstar_records VALUES ('exercise',?,?,?,?) ON CONFLICT(kind,external_id,season_id) DO UPDATE SET local_id=excluded.local_id,updated=excluded.updated",(external,0,local,now))
        elif kind=='development':
            require('plans',True);required={'id','speler','titel','doel','acties'}
            if not required.issubset(rows[0]):abort(400,'Vereiste kolommen: id, speler, titel, doel en acties.')
            clean=[];seen=set()
            for row in rows:
                external=row.get('id','');name=row.get('speler','');title=row.get('titel','');category=row.get('categorie') or 'Tactiek';status=row.get('status') or 'gepland';due=row.get('evaluatiedatum','')
                if not external or len(external)>200 or external in seen or not name or not title:abort(400,'Controleer unieke id, speler en titel; er is niets geïmporteerd.')
                if category not in PLAN_CATEGORIES or status not in PLAN_STATUSES:abort(400,'Ongeldige categorie of status bij '+title+'.')
                if due:
                    try:datetime.strptime(due,'%Y-%m-%d')
                    except ValueError:abort(400,'Gebruik JJJJ-MM-DD als evaluatiedatum bij '+title+'.')
                number=row.get('rugnummer','');player=None
                if number:
                    try:number=int(number)
                    except ValueError:abort(400,'Ongeldig rugnummer bij '+name+'.')
                    player=db().execute('SELECT player_id FROM season_players WHERE season_id=? AND team_id=? AND shirt_number=?',(g.season_id,team,number)).fetchone()
                if not player:player=db().execute('SELECT p.id AS player_id FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=? AND m.team_id=? AND lower(p.name)=lower(?)',(g.season_id,team,name)).fetchone()
                if not player:abort(400,'Speler niet gevonden in het gekozen team: '+name+'.')
                seen.add(external);clean.append((external,player['player_id'],title[:200],category,row['doel'][:3000],row['acties'][:3000],row.get('succescriterium','')[:2000],due,status,row.get('evaluatie','')[:3000]))
            db().execute('BEGIN IMMEDIATE');created=updated=0
            for external,player,title,category,goal,actions,success,due,status,evaluation in clean:
                mapped=db().execute("SELECT local_id FROM superstar_records WHERE kind='development' AND external_id=? AND season_id=?",(external,g.season_id)).fetchone()
                values=(player,title,category,goal,actions,success,due,status,evaluation,now)
                if mapped and db().execute('SELECT 1 FROM development_plans WHERE id=? AND season_id=?',(mapped['local_id'],g.season_id)).fetchone():
                    db().execute('UPDATE development_plans SET player_id=?,title=?,category=?,objective=?,actions=?,success_measure=?,due_date=?,status=?,evaluation=?,updated=? WHERE id=?',(*values,mapped['local_id']));local=mapped['local_id'];updated+=1
                else:
                    local=db().execute('INSERT INTO development_plans(player_id,title,category,objective,actions,success_measure,due_date,status,evaluation,updated,created,season_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',(*values,now,g.season_id)).lastrowid;created+=1
                db().execute("INSERT INTO superstar_records VALUES ('development',?,?,?,?) ON CONFLICT(kind,external_id,season_id) DO UPDATE SET local_id=excluded.local_id,updated=excluded.updated",(external,g.season_id,local,now))
        else:abort(400,'Kies oefenstof of spelersontwikkeling.')
        db().commit();return jsonify(ok=True,created=created,updated=updated,total=len(rows))

    def summary():
        values=dict(db().execute("SELECT key,value FROM settings WHERE key LIKE 'superstar_%'"))
        counts=dict(exercises=db().execute("SELECT count(*) FROM superstar_records WHERE kind='exercise'").fetchone()[0],development=db().execute("SELECT count(*) FROM superstar_records WHERE kind='development' AND season_id=?",(g.season_id,)).fetchone()[0])
        return {'superstar':{'mode':values.get('superstar_mode','csv'),'organisation':values.get('superstar_organisation',''),'portal':values.get('superstar_portal','https://superstar.app/'),'api_ready':bool(os.environ.get('TEAM_SUPERSTAR_API_TOKEN')),'counts':counts}}
    return summary
