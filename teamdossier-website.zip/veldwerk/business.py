"""Public product page and interest form shared by single-club and SaaS apps."""
import os,time
from flask import abort,redirect,render_template,request,url_for

def register_business(app,db):
    with app.app_context():
        db().execute('''CREATE TABLE IF NOT EXISTS business_leads(id INTEGER PRIMARY KEY,created REAL NOT NULL,name TEXT NOT NULL,
          organisation TEXT NOT NULL,email TEXT NOT NULL,phone TEXT NOT NULL,package TEXT NOT NULL,message TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'nieuw')''');db().commit()
    @app.get('/zakelijk')
    def business_page():
        prices={'trainer':os.environ.get('TEAM_PRICE_TRAINER','€ 12,50 p/m'),'team':os.environ.get('TEAM_PRICE_TEAM','€ 24,95 p/m'),'club':os.environ.get('TEAM_PRICE_CLUB','Op aanvraag')}
        return render_template('business.html',prices=prices,sent=request.args.get('verstuurd')=='1')
    @app.post('/zakelijk/interesse')
    def business_interest():
        if request.form.get('website'):return redirect(url_for('business_page',verstuurd=1))
        values=[request.form.get(k,'').strip() for k in ('name','organisation','email','phone','package','message')]
        if not values[0] or not values[1] or '@' not in values[2] or values[4] not in ('Trainer','Team','Club') or any(len(v)>2000 for v in values):abort(400,'Controleer het contactformulier.')
        db().execute('INSERT INTO business_leads(created,name,organisation,email,phone,package,message) VALUES (?,?,?,?,?,?,?)',(time.time(),*values));db().commit()
        if db().execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='mail_messages'").fetchone():
            now=time.time();db().execute('INSERT INTO mail_messages(direction,status,from_address,to_address,subject,body,created,updated) VALUES (?,?,?,?,?,?,?,?)',('notification','nieuw',values[2],'','Nieuwe pakketaanvraag · '+values[1],f'Naam: {values[0]}\nPakket: {values[4]}\nTelefoon: {values[3]}\n\n{values[5]}',now,now));db().commit()
        return redirect(url_for('business_page',verstuurd=1))
