const $=s=>document.querySelector(s), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let refreshVersion=0;
let me=null, data=null, view='overview', team='', player=null, search='', functionFilter='', modalAction=null, users=[], businessLeads=[], businessPackages={}, businessFeatureCatalog=[], toastTimer;
const roleName={admin:'Beheerder',trainer:'Trainer / staf',player:'Speler'}, stateName={queued:'In wachtrij',processing:'Analyse loopt',done:'Analyse gereed',failed:'Analyse mislukt'};
const date=v=>new Date(v*1000).toLocaleDateString('nl-NL',{day:'numeric',month:'short',year:'numeric'});
const writable=(module=null)=>can(module||pageModule[view]||'players',true);
function toast(text,error=false){$('#toast').textContent=text;$('#toast').classList.toggle('error',error);$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').hidden=true,6000);}
function responseFailure(status){
 if(status===413)return 'Het bestand is te groot voor de server of hosting (HTTP 413). Gebruik een kleiner bestand of een HTTPS-link naar je presentatie.';
 if(status===502||status===503||status===504)return 'De hosting kon het verzoek niet verwerken (HTTP '+status+'). Probeer opnieuw; controleer bij herhaling het Error log op PythonAnywhere.';
 if(status===404)return 'Dit onderdeel is niet gevonden op de server (HTTP 404). Werk de websitebestanden bij en klik op Reload in PythonAnywhere.';
 if(status===500)return 'Er is een serverfout opgetreden (HTTP 500). Kijk bij PythonAnywhere → Web → Error log voor de oorzaak.';
 return 'De server gaf geen geldig gegevensantwoord (HTTP '+status+'). Controleer de website en het Error log in PythonAnywhere.';
}
async function api(path,options={}){
 options.headers={...options.headers};if(me&&options.method&&options.method!=='GET')options.headers['X-CSRF-Token']=me.csrf;
 const requestPath=seasonUrl(path);let response;try{response=await fetch(requestPath,options);}catch{throw Error('Geen verbinding met de website. Controleer je verbinding en probeer opnieuw.');}
 if(response.status===401&&path!=='/api/login'){showLogin();throw Error('Je sessie is verlopen. Log opnieuw in.');}
 const raw=await response.text();let result;
 try{result=JSON.parse(raw);if(result===null||typeof result!=='object')throw Error();}catch{throw Error(responseFailure(response.status));}
 if(!response.ok)throw Error(result.error||responseFailure(response.status));return result;
}
const post=(path,body)=>api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
function showLogin(){
 mailData={rows:[],tickets:[],smtp_configured:false,imap_configured:false,address:''};
 me=null;data=null;selectedSeason='';medicalData=null;medicalTeam='';medicalPlayer='';attendanceDrafts.clear();attendanceQueues.clear();observationUndo=null;attendanceUndo=null;view='overview';activeTraining=null;activeSelection=null;reportRows=[];planPlayer='';planCategory='';planStatus='';exerciseTheme='';exerciseAge='';exerciseCatalog=null;advanced={player:'',kind:'',category:'',from:'',until:'',state:''};taskFolder='';exerciseCategory='';team='';player=null;users=[];businessLeads=[];selectedTeam=null;search='';functionFilter='';watchingVideo=null;systemInfo=null;auditRows=[];
 $('#workspace').hidden=true;$('#login-screen').hidden=false;
 document.querySelectorAll('dialog[open]').forEach(d=>d.close());
 $('#video-player').pause();$('#video-player').removeAttribute('src');
}
async function enter(){
 me=await api('/api/me');
 const route=location.hash.slice(1);
 const allowed=['overview','search','help',...Object.keys(pageModule).filter(p=>can(pageModule[p])),...(me.role==='admin'?['accounts','settings']:[])];
 view=allowed.includes(route)?route:'overview';
 $('#login-screen').hidden=true;$('#workspace').hidden=false;
 $('#user-name').textContent=me.username;$('#user-avatar').textContent=me.username.slice(0,2).toUpperCase();$('#user-role').textContent=roleName[me.role];
 $('#accounts-nav').hidden=me.role!=='admin';$('#settings-nav').hidden=me.role!=='admin';$('#business-nav').hidden=me.role!=='admin';document.querySelectorAll('aside nav button').forEach(button=>button.title=button.querySelector('span')?.textContent||'');document.querySelectorAll('[data-view]').forEach(b=>{const mod=pageModule[b.dataset.view];if(mod)b.hidden=!can(mod);});
 await refresh();
}
async function refresh(){
 if(!me)return;if(attendanceQueues.size)await Promise.all([...attendanceQueues.values()]);if(!me)return;
 const session=me.id,requestedSeason=selectedSeason,revision=++refreshVersion;
 const next=await api('/api/dashboard');
 if(me?.id!==session||selectedSeason!==requestedSeason||revision!==refreshVersion)return;
 const catalog=['exercises','search'].includes(view)&&can('exercises')?(exerciseCatalog||(await api('/api/exercise-catalog')).rows):null;
 if(catalog){exerciseCatalog=catalog;const known=new Set(next.exercises.map(e=>e.id));next.exercises.push(...catalog.filter(e=>!known.has(e.id)));}
 const medical=['medical','injuries'].includes(view)&&can('medical')?await api('/api/medical'):null;
 const nextUsers=view==='accounts'?await api('/api/users'):null;
 const nextReports=view==='reports'?(await api('/api/reports?'+reportQuery())).rows:null;
 const nextSystem=view==='settings'&&me.role==='admin'?await api('/api/system'):null;
 const nextAudit=view==='settings'&&me.role==='admin'?await api('/api/audit?limit=100'):null;
 const nextMail=view==='mail'?await api('/api/mail'):null;
 const nextBusiness=view==='business'&&me.role==='admin'?await api('/api/business-leads'):null;
 if(me?.id!==session||selectedSeason!==requestedSeason||revision!==refreshVersion)return;
 data=next;selectedSeason=String(next.selected_season.id);if(medical)medicalData=medical;
 if(nextUsers)users=nextUsers;if(nextMail)mailData=nextMail;if(nextBusiness){businessLeads=nextBusiness.rows;businessPackages=nextBusiness.packages;businessFeatureCatalog=nextBusiness.feature_catalog;}if(nextReports)reportRows=nextReports;if(nextSystem)systemInfo={...nextSystem,audit_retention_days:nextAudit?.retention_days};if(nextAudit)auditRows=nextAudit.rows;
 $('#club-name').textContent=data.settings.club_name||'Clubomgeving';document.documentElement.style.setProperty('--green',data.settings.primary_color||'#183c2d');document.documentElement.style.setProperty('--lime',data.settings.accent_color||'#d9f391');render();
 const mailCount=Number(data.mail_unread||0);mailNav.innerHTML=`✉ <span>Berichten</span>${mailCount?`<b class="nav-badge">${mailCount}</b>`:''}`;
 if(watchingVideo&&$('#video-dialog').open)updateVideoPanel();
}
$('#login-form').onsubmit=async event=>{event.preventDefault();const button=event.submitter;button.disabled=true;$('#login-error').textContent='';try{await post('/api/login',Object.fromEntries(new FormData(event.target)));event.target.reset();await enter();}catch(e){$('#login-error').textContent=e.message;}finally{button.disabled=false;}};
$('#logout').onclick=async()=>{try{await post('/api/logout',{});showLogin();}catch(e){toast(e.message,true);}};
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=async()=>{view=b.dataset.view;player=null;selectedTeam=null;activeTraining=null;activeSelection=null;planPlayer='';planCategory='';planStatus='';exerciseTheme='';exerciseAge='';advanced={player:'',kind:'',category:'',from:'',until:'',state:''};search='';taskFolder='';exerciseCategory='';try{await refresh();}catch(e){toast(e.message,true);}});
document.querySelectorAll('.close').forEach(b=>b.onclick=()=>b.closest('dialog').close());
$('#video-dialog').addEventListener('close',()=>{watchingVideo=null;$('#video-player').pause();$('#video-player').removeAttribute('src');});
function button(action,label,primary=false,extra=''){const required=actionAccess[action];if(required&&!can(required[0],required[1]))return '';return `<button class="${primary?'primary':'secondary'}" data-action="${action}" ${extra}>${label}</button>`;}
function empty(title,text,action=''){return `<div class="empty"><strong>${esc(title)}</strong><p>${esc(text)}</p>${action}</div>`;}
function teamName(id){return data.teams.find(t=>t.id===id)?.name||'Team';}
function playerName(id){return data.players.find(p=>p.id===id)?.name||'Teambeelden';}
function teamOptions(){return data.teams.map(t=>`<option value="${t.id}" ${String(t.id)===String(team)?'selected':''}>${esc(t.name)}</option>`).join('');}
function toolbar(video=false){return `<div class="toolbar"><select id="team-filter" aria-label="Filter op team"><option value="">Alle teams</option>${teamOptions()}</select><input id="search" type="search" placeholder="${video?'Zoek video, teamtaak of categorie…':['training','availability'].includes(view)?'Zoek training of locatie…':view==='selections'?'Zoek tegenstander of wedstrijd…':'Zoek een speler…'}" aria-label="Zoeken" value="${esc(search)}">${video?`<select id="function-filter" aria-label="Filter teamfunctie"><option value="">Alle teamfuncties</option><option value="__none" ${functionFilter==='__none'?'selected':''}>Geen teamfunctie</option>${data.functions.map(f=>`<option ${f===functionFilter?'selected':''}>${esc(f)}</option>`).join('')}</select>`:''}</div>`;}
function filteredPlayers(){return data.players.filter(p=>(!team||String(p.team_id)===team)&&p.name.toLowerCase().includes(search.toLowerCase()));}
function filteredVideos(){return data.videos.filter(v=>(!team||String(v.team_id)===team)&&(!player||v.player_id===player)&&(!functionFilter||(functionFilter==='__none'?!v.function:v.function===functionFilter))&&(!taskFolder||(taskFolder==='__none'?!v.task:v.task===taskFolder))&&(!advanced.player||String(v.player_id)===advanced.player)&&(!advanced.kind||v.kind===advanced.kind)&&(!advanced.category||v.category===advanced.category)&&(!advanced.state||v.state===advanced.state)&&periodMatch(v.created)&&`${v.title} ${v.task} ${v.function} ${v.category||''} ${teamName(v.team_id)} ${playerName(v.player_id)}`.toLowerCase().includes(search.toLowerCase()));}
function stats(){const done=data.videos.filter(v=>v.state==='done').length;return `<section class="stats">${[['Teams',data.teams.length,'in jouw omgeving'],['Spelers',data.players.length,'in beeld'],['Videobeelden',data.videos.length,'opgeslagen en gekoppeld'],['Analyses gereed',done,'technische beeldanalyses']].map(([label,n,sub])=>`<div class="stat"><span>${label}</span><strong>${n}</strong><small>${sub}</small></div>`).join('')}</section>`;}
function teamRows(){return data.teams.map(t=>`<div class="team-row"><div class="team-icon">⚑</div><div><strong>${esc(t.name)}</strong><small>${data.players.filter(p=>p.team_id===t.id).length} spelers · ${data.videos.filter(v=>v.team_id===t.id).length} video's</small></div><button class="text-button" data-action="team-view" data-id="${t.id}">Bekijk team →</button></div>`).join('');}
function observationRows(rows){return rows.map(o=>`<div class="observation"><strong>${esc(o.category)} · ${o.rating}/5</strong><small> · ${date(o.created)} · ${esc(playerName(o.player_id))}</small><p>${esc(o.note)}</p>${o.updated>o.created?`<small>Bijgewerkt op ${date(o.updated)}</small>`:''}<div class="actions">${can('players',true)?button('observation-edit','Beoordeling aanpassen',false,`data-id="${o.id}"`)+button('observation-delete','Verwijderen',false,`data-id="${o.id}"`):''}</div></div>`).join('');}
function overview(){return `<article class="club-welcome"><img src="/static/terheijden.png" alt="Logo SV Terheijden"><div><span class="eyebrow">${esc((data.settings.club_name||'CLUBOMGEVING').toLocaleUpperCase('nl'))}</span><h2>${esc(data.settings.welcome_title||'Samen op het veld. Samen vooruit.')}</h2><p>${esc(data.settings.welcome_text||data.selected_season.name+' · Jouw teams en spelers in beeld.')}</p></div></article>`+stats()+`<section class="split"><div><article class="panel"><div class="panel-head"><div><h2>Jouw teams</h2><p>Een eigen plek voor ieder elftal.</p></div>${me.role==='admin'?button('team','＋ Team'):''}</div>${data.teams.length?teamRows():empty('De aftrap begint bij een team.','Voeg je eerste elftal toe en bouw daarna je spelersgroep op.',me.role==='admin'?button('team','＋ Eerste team toevoegen',true):'')}</article><article class="panel"><div class="panel-head"><div><h2>Laatste observaties</h2><p>Van de training naar een concrete volgende stap.</p></div></div>${data.observations.length?observationRows(data.observations.slice(0,4)):empty('Ontwikkeling begint met kijken.','Observaties en beoordelingen van trainers verschijnen hier.')}</article></div><div><article class="insight"><div class="eyebrow">JE EIGEN ONTWIKKELLIJN</div><h3>Meer dan een momentopname.</h3><p>Koppel beelden aan een speler, teamtaak en teamfunctie. Leg vast wat je ziet en werk gericht aan de volgende stap.</p><div class="steps">Beelden <span>→</span> Inzicht <span>→</span> Ontwikkeling</div></article><article class="panel"><div class="panel-head"><h3>Analyse & actualisatie</h3></div><div class="notice">Upload geëxporteerde Veo-beelden of eigen MP4-bestanden. Nieuwe video's worden automatisch technisch geanalyseerd. Spelersprofielen en overzichten verversen elke 5 seconden. Herkenning van spelersacties en teamgedrag en automatische software-updates zijn nog niet aangesloten.</div></article><article class="panel"><div class="panel-head"><h3>Wie ziet wat?</h3></div><div class="notice">Beheerder: accounts en alle teamgegevens.<br>Trainers: toegewezen teams en onderdelen.<br>Spelers: eigen profiel, eigen clips en volledige wedstrijden van hun team.</div></article></div></section>`;}
function playerCard(p){const obs=data.observations.filter(o=>o.player_id===p.id),avg=obs.length?(obs.reduce((n,o)=>n+o.rating,0)/obs.length).toFixed(1):'—';return `<article class="player-card"><div class="player-top">${p.has_photo?`<img class="player-photo" src="${seasonUrl(`/photos/${p.id}?v=${p.photo_updated}`)}" alt="Foto van ${esc(p.name)}" loading="lazy">`:`<div class="avatar">${esc(p.name.split(' ').map(n=>n[0]).slice(0,2).join(''))}</div>`}<div><h3>${p.shirt_number?'#'+p.shirt_number+' · ':''}${esc(p.name)}</h3><p>${esc(p.position||'Positie nog niet ingevuld')} · ${esc(teamName(p.team_id))}</p></div></div><div class="goal">${esc(p.goal||'Nog geen ontwikkeldoel vastgelegd.')}</div><div class="player-numbers"><div><strong>${data.videos.filter(v=>v.player_id===p.id).length}</strong><small>videoclips</small></div><div><strong>${avg}</strong><small>trainersscore / 5</small></div></div><div class="actions">${button('profile','Spelersprofiel →',false,`data-id="${p.id}"`)}</div></article>`;}
function playersView(){if(player)return profileView();return playerLists();}
function profileView(){const p=data.players.find(p=>p.id===player);if(!p){player=null;return playersView();}const obs=data.observations.filter(o=>o.player_id===p.id);const categories=[...new Set(obs.map(o=>o.category))];return `<div class="actions">${button('players-back','← Alle spelers')}${can('players',true)?button('player-photo',p.has_photo?'Foto vervangen':'Foto toevoegen',false,`data-id="${p.id}"`):''}${writable()?button('player-edit','Profiel wijzigen',false,`data-id="${p.id}"`):''}${writable()?button('observation','＋ Observatie toevoegen',true,`data-id="${p.id}"`):''}</div><section class="profile">${p.has_photo?`<img class="profile-photo" src="${seasonUrl(`/photos/${p.id}?v=${p.photo_updated}`)}" alt="Foto van ${esc(p.name)}">`: ''}<span class="tag">${esc(teamName(p.team_id))}</span><h2>${p.shirt_number?'#'+p.shirt_number+' · ':''}${esc(p.name)}</h2><p>${esc(p.position||'Positie nog niet ingevuld')}</p><strong>Ontwikkeldoel</strong><p>${esc(p.goal||'Nog geen ontwikkeldoel vastgelegd.')}</p><div class="ratings">${categories.map(c=>{const rows=obs.filter(o=>o.category===c),avg=rows.reduce((s,o)=>s+o.rating,0)/rows.length;return `<div class="rating"><strong>${avg.toFixed(1)}<small>${esc(c)} · ${rows.length} observaties</small></strong><div class="bar"><meter min="0" max="5" value="${avg}" aria-label="${esc(c)}"></meter></div></div>`;}).join('')}</div><p class="hint">Scores zijn beoordelingen van de trainer, geen automatisch gemeten spelersprestaties.</p></section><article class="panel"><div class="panel-head"><h2>Ontwikkellogboek</h2></div>${obs.length?observationRows(obs):empty('Nog geen observaties.','Leg het eerste ontwikkelmoment vast.')}</article><h2>Beelden van ${p.shirt_number?'#'+p.shirt_number+' · ':''}${esc(p.name)}</h2><div class="cards">${data.videos.filter(v=>v.player_id===p.id).map(videoCard).join('')}</div>`;}
function videoCard(v){const a=v.analysis;return `<article class="video-card"><div class="video-cover">▷<small>${v.kind==='match'?'VOLLEDIGE WEDSTRIJD':'SPELERS- / TEAMCLIP'} · ${a.duration?Math.round(a.duration)+' SEC':'VIDEO'}</small></div><div class="video-body"><span class="pill ${v.state}">${stateName[v.state]}</span><h3>${esc(v.title)}</h3><p>${esc(teamName(v.team_id))} · ${esc(playerName(v.player_id))}</p><p><strong>${esc(v.function||'Geen teamfunctie')}</strong><br>${esc(v.task||'Geen teamtaak')}${v.category?'<br>'+esc(v.category):''}</p><div class="actions">${button('watch','▷ Bekijken',false,`data-id="${v.id}"`)}${can('videos',true)?button('video-edit','Wijzigen',false,`data-id="${v.id}"`):''}${can('videos',true)&&v.state==='failed'?button('retry','Analyse opnieuw',false,`data-id="${v.id}"`):''}</div></div></article>`;}
function videosView(){const list=filteredVideos();return toolbar(true)+advancedFilters('videos')+`<div id="results" class="cards">${list.map(videoCard).join('')}</div>${list.length?'':empty('Geef je beelden een plek.','Upload een wedstrijd of clip en koppel deze aan je team en spelers.',writable()&&data.teams.length?button('upload','＋ Video uploaden',true):'')}`;}
function accountsView(){return `<article class="panel"><div class="panel-head"><div><h2>Accounts & toegang</h2><p>Alleen jij maakt gebruikersnamen en wachtwoorden aan.</p></div>${button('account','＋ Account',true)}</div>${users.map(u=>`<div class="account-row"><div><strong>${esc(u.username)}</strong><small>${roleName[u.role]} · ${u.active?'Actief':'Geblokkeerd'} · ${u.permissions.all_teams?'Alle toegestane teams':u.permissions.team_ids.length+' geselecteerde teams'}${u.player_id?' · '+esc(playerName(u.player_id)):''}</small></div>${u.role==='admin'?'<span class="tag">BEHEERDER</span>':`<div class="actions">${button('permissions','Toegang instellen',false,`data-id="${u.id}"`)}${button('password','Wachtwoord instellen',false,`data-id="${u.id}"`)}${button('toggle-user',u.active?'Blokkeren':'Activeren',false,`data-id="${u.id}"`)}</div>`}</div>`).join('')}</article><div class="notice">Stel per account de onderdelen en teams in. Koppel een spelersaccount aan de juiste speler; dat account ziet alleen diens profiel, eigen clips en volledige teamwedstrijden. Blokkeren of een nieuw wachtwoord instellen beëindigt bestaande sessies.</div>`;}
function render(){
 if(!me||!data)return;
 seasonControls();
 const pages={
 staff:['Stafleden','De mensen achter het team.','Stafleden per team en hun contactgegevens.',staffView],
 medical:['Medische staf','Gezondheid en herstel in beeld.','Meten, wegen en medische dossiers voor bevoegde staf.',medicalView],
 injuries:['Blessuremonitor','Volg iedere stap in het herstel.','Blessures, beperkingen en geplande controles.',medicalView],
  overview:['Overzicht','Het overzicht. De volgende stap.','Houd je teams in beeld en de ontwikkeling in beweging.',overview],
  teams:['Teams','Ieder elftal een eigen verhaal.','Spelers en beelden bij elkaar, van jeugdteam tot eerste elftal.',teamsView],
  players:['Spelers','Iedere speler een eigen ontwikkellijn.','Volg doelen, trainersobservaties en bijbehorende videobeelden.',playersView],
  scouting:['Scouting','Van waarneming naar onderbouwde keuze.','Beheer scouts, rapporten en vervolgacties voor talentontwikkeling.',scoutingView],
  videos:['Video’s','Het moment. Het inzicht.','Geordend per speler, teamtaak en teamfunctie.',videosView],
  analysis:['Ontwikkeloverzicht','Van observatie naar volgende stap.','Je vastgelegde beoordelingen en videomomenten in één overzicht.',analysisView],
  training:['Trainingsplanning','Een helder plan voor het trainingsveld.','Plan trainingen, locaties en oefenstof voor ieder elftal.',trainingsView],
  availability:['Aanwezigheid','Weten wie er is. En wie er komt.','Beschikbaarheid en daadwerkelijke aanwezigheid apart bijgehouden.',trainingsView],
  selections:['Selecties & opstellingen','De selectie. Het plan. De aftrap.','Maak een conceptopstelling en publiceer deze voor je team.',selectionsView],
  plans:['Ontwikkelplannen','Een gerichte volgende stap voor iedere speler.','Doelen, acties, succescriteria en evaluatie per speler.',plansView],
  reports:['Statistieken & rapporten','Van vastleggen naar overzicht.','Aanwezigheid, selecties, ontwikkeling en trainersscores.',reportsView],
  suite:['Cluborganisatie','Alles wat de club vooruithelpt.','Taken, communicatie, opleiding, scouting en planning bij elkaar.',suiteView],
  suite_detail:['Cluborganisatie','Werk gericht aan dit clubonderdeel.','Alle informatie, acties en afspraken op één eigen pagina.',suiteDetailView],
  opponents:['Tegenstanders','Ken de volgende tegenstander.','Dossiers, speelwijze, formaties, spelers en wedstrijdplan.',opponentsView],
  mail:['Berichten','Communicatie op één plek.','Inbox, verzonden e-mail, concepten en interne berichten.',mailView],
  business:['Zakelijk beheer','Beheer Teamdossier als dienst.','Pakketten, interesseformulieren en afzonderlijke clubomgevingen.',businessView],
  tasks:['Teamtaken','Zes teamtaken. Eén duidelijke structuur.','Je beelden geordend naar de momenten die het spel bepalen.',taskView],
  exercises:['Oefenstof','Van inzicht naar het trainingsveld.','Oefeningen per teamtaak, met organisatie en coachaccenten.',exercisesView],
  myexercises:['Mijn oefenstof','Zelf gemaakt. Snel teruggevonden.','Eigen oefeningen, veldtekeningen en coachaccenten bij elkaar.',myExercisesView],
  presentations:['Wedstrijdpresentaties','Een helder plan voor elke wedstrijd.','Je wedstrijdbesprekingen bij elkaar, per team en tegenstander.',presentationsView],
  documents:['Documenten','Alles wat de club vastlegt.','Beleid, visie, training, wedstrijd, ontwikkeling en rapportage.',documentsView],
  matches:['Programma & stand','Jouw eerste en tweede elftal in beeld.','Programma, uitslagen en stand, met een verwijzing naar Voetbal.nl.',matchesView],
  search:['Zoeken','Vind het juiste beeld. Of de volgende oefening.','Zoek in de onderdelen waarvoor jouw account toegang heeft.',searchView],
  accounts:['Toegangsbeheer','Jij bepaalt wie meedoet.','Een besloten omgeving, met accounts die jij uitgeeft.',accountsView],
  settings:['Administrator','Beheer de volledige clubomgeving.','Gebruikers, koppelingen, beveiliging, opslag en clubinstellingen op één plek.',settingsView],
  help:['Hulp & uitleg','Zo haal je meer uit Teamdossier.nl.','Van het eerste team tot een gericht ontwikkelgesprek.',helpView]
 };
 let config=pages[view]||pages.overview;if(view==='suite_detail'&&suiteKinds[suiteKind])config=[suiteKinds[suiteKind][0],suiteKinds[suiteKind][0],suiteKinds[suiteKind][1],suiteDetailView];
 history.replaceState(null,'','#'+view);
 $('#breadcrumb').textContent=config[0];$('#page-title').textContent=config[1];$('#page-description').textContent=config[2];
 document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 if(view==='suite_detail')suiteNav.classList.add('active');
 const sportPage=['overview','teams','players','videos','tasks'].includes(view);
 $('#top-actions').innerHTML=`${me.role==='admin'&&['overview','teams'].includes(view)?button('team','＋ Team toevoegen'):''}${view==='players'&&can('players',true)&&data.teams.length?button('player','＋ Speler toevoegen',true):''}${sportPage&&can('videos',true)&&data.teams.length?button('upload','↑ Video uploaden',true):''}${['training','availability'].includes(view)&&can('training',true)&&data.teams.length?button('training-new','＋ Training plannen',true):''}${view==='selections'&&can('selections',true)&&data.teams.length?button('selection-new','＋ Wedstrijdselectie',true):''}${['plans','analysis'].includes(view)&&can('plans',true)&&data.plan_candidates.length?button('plan-new','＋ Ontwikkelplan',true):''}${view==='exercises'&&can('exercises',true)?button('exercise','＋ Oefening toevoegen',true):''}${view==='presentations'&&can('presentations',true)&&data.teams.length?button('presentation','＋ Presentatie toevoegen',true):''}`;
 const active=document.activeElement?.id,selection=active==='search'?document.activeElement.selectionStart:null;
 $('#content').innerHTML=(typeof dashboardLinks==='function'?dashboardLinks():'')+(data.selected_season.archived?'<div class="notice">Je bekijkt een gearchiveerd seizoen. Gegevens blijven bewaard.</div>':'')+(observationUndo?'<div class="notice">Observatie verwijderd. '+button('observation-undo','Ongedaan maken')+'</div>':'')+config[3]();
 if(['training','availability'].includes(view)&&can('training',true))$('#top-actions').insertAdjacentHTML('afterbegin',button('training-series','＋ Trainingen voor een periode'));
 $('#season-manage').hidden=me.role!=='admin';
 if(active==='search'){$('#search')?.focus();$('#search')?.setSelectionRange(selection,selection);}
}
function field(name,label,type='text',value='',extra=''){return `<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;}
function select(name,label,options,extra=''){return `<label>${label}<select name="${name}" ${extra}>${options}</select></label>`;}
function openForm(title,html,action,submit='Opslaan'){$('#dialog-title').textContent=title;$('#form-fields').innerHTML=html;$('#form-error').textContent='';$('#form-submit').textContent=submit;modalAction=action;$('#form-dialog').showModal();}
function openPlayer(id){const p=data.players.find(p=>p.id===Number(id));openForm(p?'Spelersprofiel wijzigen':'Speler toevoegen',`${p?`<input type="hidden" name="id" value="${p.id}">`:''}${field('name','Naam','text',p?.name||'','required maxlength="200"')}${select('team_id','Team',data.teams.map(t=>`<option value="${t.id}" ${t.id===(p?.team_id||Number(team))?'selected':''}>${esc(t.name)}</option>`).join(''),'required')}${field('shirt_number','Rugnummer','number',p?.shirt_number??'','min="1" max="99"')}${field('position','Positie','text',p?.position||'','maxlength="200"')}<label>Ontwikkeldoel<textarea name="goal" maxlength="2000">${esc(p?.goal||'')}</textarea></label>`,async f=>post('/api/players',Object.fromEntries(f)));}
document.addEventListener('change',event=>{if(event.target.id==='team-filter'){team=event.target.value;render();}if(event.target.id==='function-filter'){functionFilter=event.target.value;render();}if(event.target.name==='team_id'&&$('#dynamic-form [name="file"]')&&$('#dynamic-form [name="player_id"]')){const sel=$('#dynamic-form [name="player_id"]');sel.innerHTML='<option value="">Teambeelden (geen individuele speler)</option>'+data.players.filter(p=>String(p.team_id)===event.target.value).map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');}if(event.target.name==='role'){const el=$('#player-account-field');if(el)el.hidden=event.target.value!=='player';}});
document.addEventListener('input',event=>{if(event.target.id==='search'){search=event.target.value;render();}});
document.addEventListener('click',async event=>{const b=event.target.closest('[data-action]');if(!b)return;const action=b.dataset.action,id=b.dataset.id;try{
  if(await quickAction(action,id,b))return;
  if(await planningAction(action,id,b))return;
  if(await smartAction(action,id,b))return;
  if(await suiteAction(action,id,b))return;
  if(await mailAction(action,id,b))return;
  if(await documentsAction(action,id,b))return;
  if(await trackingAction(action,id,b))return;
  if(await enhancementAction(action,id,b))return;
  if(await tacticsAction(action,id,b))return;
  if(await libraryAction(action,id,b))return;
  if(action==='global-search'){view='search';search='';render();return;}
  if(await extraAction(action,id,b))return;
  if(action==='team')openForm('Team toevoegen',field('name','Teamnaam','text','','required maxlength="200"'),async f=>post('/api/teams',Object.fromEntries(f)));
  if(action==='team-view'){team=id;selectedTeam=Number(id);view='teams';player=null;search='';render();}
  if(action==='player'||action==='player-edit')openPlayer(id);
  if(action==='player-photo')playerPhotoForm(id);
  if(action==='profile'){player=Number(id);render();}
  if(action==='players-back'){player=null;render();}
  if(action==='observation')observationForm(Number(id));
  if(action==='observation-edit'){const o=data.observations.find(o=>o.id===Number(id));observationForm(o.player_id,o.id);}
  if(action==='account')openForm('Account aanmaken',`${field('username','Gebruikersnaam','text','','required autocomplete="off" maxlength="80"')}${field('password','Wachtwoord (minimaal 12 tekens)','password','','required minlength="12" maxlength="256" autocomplete="new-password"')}${select('role','Toegang','<option value="trainer">Staf · trainer of medisch</option><option value="player">Speler · eigen beelden en teamwedstrijden</option>')}<div id="player-account-field" hidden>${select('player_id','Gekoppelde speler','<option value="">Kies speler</option>'+data.players.map(p=>`<option value="${p.id}">${esc(p.name)} · ${esc(teamName(p.team_id))}</option>`).join(''))}</div><button type="button" class="secondary" data-action="medical-account-template">Medisch account instellen</button><div id="account-permissions">${permissionFields('trainer')}</div><p class="hint">Geef de gebruikersnaam en het wachtwoord zelf via een geschikt privé-kanaal aan de gebruiker.</p>`,async f=>post('/api/users',{...Object.fromEntries(f),permissions:readPermissions(f)}),'Account aanmaken');
  if(action==='password')openForm('Nieuw wachtwoord instellen',field('password','Nieuw wachtwoord','password','','required minlength="12" maxlength="256" autocomplete="new-password"'),async f=>post(`/api/users/${id}/manage`,Object.fromEntries(f)));
  if(action==='toggle-user'){const u=users.find(u=>u.id===Number(id));if(confirm(`${u.active?'Blokkeer':'Activeer'} account ${u.username}?`)){await post(`/api/users/${id}/manage`,{active:!u.active});await refresh();toast('Account bijgewerkt.');}}
  if(action==='upload'){const teamId=team||String(data.teams[0]?.id||'');openForm('Videobeelden toevoegen',`${field('title','Titel','text','','required maxlength="200"')}${select('team_id','Team',data.teams.map(t=>`<option value="${t.id}" ${String(t.id)===teamId?'selected':''}>${esc(t.name)}</option>`).join(''))}${select('kind','Soort beelden','<option value="clip">Spelers- of teamclip</option><option value="match">Volledige wedstrijd · zichtbaar voor spelers van dit team</option>')}${select('player_id','Speler (optioneel)','<option value="">Teambeelden (geen individuele speler)</option>'+data.players.filter(p=>String(p.team_id)===teamId).map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join(''))}${select('function','Teamfunctie','<option value="">Geen teamfunctie</option>'+data.functions.map(f=>`<option>${esc(f)}</option>`).join(''))}${select('task','Teamtaakmap (optioneel)',taskOptions(taskFolder==='__none'?'':taskFolder))}${field('category','Extra categorie (optioneel)','text','','maxlength="120" placeholder="Bijvoorbeeld wedstrijd, techniek of coaching"')}${field('file','Videobestand (maximaal 512 MB)','file','','required accept=".mp4,.webm,.mov"')}<p class="notice">Technische beeldanalyse start automatisch. Herkenning van spelersacties en teamgedrag is nog niet beschikbaar. MP4 met H.264 speelt in de meeste browsers af; MOV is niet in elke browser afspeelbaar.</p>`,async f=>{const file=f.get('file');if(file.size>512*1024*1024)throw Error('Maximaal 512 MB per video.');return api('/api/videos',{method:'POST',body:f});},'Uploaden & analyseren');}
  if(action==='watch')openVideo(id);
  if(action==='retry'){await post(`/api/videos/${id}/retry`,{});await refresh();toast('Analyse klaargezet voor verwerking.');}
}catch(e){toast(e.message,true);}});
$('#dynamic-form').onsubmit=async event=>{event.preventDefault();const button=event.submitter;button.disabled=true;$('#form-error').textContent='';try{const result=await modalAction(new FormData(event.target));if(result?.keepOpen)return;$('#form-dialog').close();await refresh();toast('Opgeslagen. Overzichten worden automatisch bijgewerkt.');}catch(e){$('#form-error').textContent=e.message;}finally{button.disabled=false;}};
enter().catch(()=>showLogin());
setInterval(()=>{if(me&&!document.hidden&&!isEditingAttendance()&&!$('#form-dialog').open)refresh().catch(e=>toast(e.message,true));},5000);
