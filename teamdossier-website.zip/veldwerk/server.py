"""Private football player development workspace."""
import argparse
import functools
import getpass
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import subprocess
import threading
import time
import uuid
import io
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from flask import Flask, abort, g, jsonify, redirect, render_template, request, send_file
from werkzeug.security import check_password_hash, generate_password_hash

from permissions import MODULES, TASKS, resolve as resolve_permissions, validate as validate_permissions
from legal import legal_context

ROOT = Path(__file__).parent
FUNCTIONS = ('Aanvallen', 'Verdedigen', 'Omschakelen naar aanval', 'Omschakelen naar verdediging')


def create_app(data_dir=None, testing=False, recover_jobs=False, tenant_slug=None):
    app = Flask(__name__)
    data = Path(data_dir or os.environ.get('TEAM_DATA', ROOT / 'data'))
    data.mkdir(parents=True, exist_ok=True, mode=0o700)
    (data / 'videos').mkdir(exist_ok=True, mode=0o700)
    (data / 'photos').mkdir(exist_ok=True, mode=0o700)
    analysis_mode = os.environ.get('TEAM_ANALYSIS_MODE', 'background')
    if analysis_mode not in ('background', 'deferred'):
        raise ValueError('TEAM_ANALYSIS_MODE moet background of deferred zijn.')
    app.config.update(DATA=data, MAX_CONTENT_LENGTH=512 * 1024 * 1024, TESTING=testing,
                      ANALYSIS_MODE=analysis_mode, TENANT_SLUG=tenant_slug or os.environ.get('TEAM_TENANT','single'))
    if os.environ.get('TEAM_BASE_DOMAIN'):
        app.config['TRUSTED_HOSTS']=[os.environ['TEAM_BASE_DOMAIN'],'.'+os.environ['TEAM_BASE_DOMAIN'],'localhost','127.0.0.1']

    def db():
        if 'db' not in g:
            g.db = sqlite3.connect(data / 'teams.db', timeout=20)
            g.db.row_factory = sqlite3.Row
            g.db.execute('PRAGMA foreign_keys=ON')
        return g.db

    app.db = db

    @app.teardown_appcontext
    def close_db(error=None):
        conn = g.pop('db', None)
        if conn:
            conn.close()

    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS teams(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
        CREATE TABLE IF NOT EXISTS players(id INTEGER PRIMARY KEY, team_id INTEGER NOT NULL REFERENCES teams(id),
          name TEXT NOT NULL, position TEXT NOT NULL DEFAULT '', goal TEXT NOT NULL DEFAULT '', shirt_number INTEGER,
          UNIQUE(team_id,shirt_number));
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('admin','trainer','player')), player_id INTEGER REFERENCES players(id), active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS access(user_id INTEGER REFERENCES users(id), team_id INTEGER REFERENCES teams(id), PRIMARY KEY(user_id,team_id));
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER REFERENCES users(id), csrf TEXT NOT NULL, expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS videos(id TEXT PRIMARY KEY, team_id INTEGER NOT NULL REFERENCES teams(id), player_id INTEGER REFERENCES players(id),
          title TEXT NOT NULL, task TEXT NOT NULL, function TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'clip', filename TEXT NOT NULL, created REAL NOT NULL,
          state TEXT NOT NULL DEFAULT 'queued', analysis TEXT NOT NULL DEFAULT '{}');
        CREATE TABLE IF NOT EXISTS observations(id INTEGER PRIMARY KEY, player_id INTEGER NOT NULL REFERENCES players(id),
          user_id INTEGER NOT NULL REFERENCES users(id), category TEXT NOT NULL, rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
          note TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS moments(id INTEGER PRIMARY KEY, video_id TEXT NOT NULL REFERENCES videos(id),
          player_id INTEGER REFERENCES players(id), user_id INTEGER NOT NULL REFERENCES users(id),
          second REAL NOT NULL, label TEXT NOT NULL, outcome TEXT NOT NULL, note TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS login_attempts(address TEXT PRIMARY KEY, failures INTEGER NOT NULL, until REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY, created REAL NOT NULL,
          request_id TEXT NOT NULL, user_id INTEGER, username TEXT NOT NULL, method TEXT NOT NULL,
          path TEXT NOT NULL, status INTEGER NOT NULL, address_hash TEXT NOT NULL);
        ''')
        if 'permissions' not in {r[1] for r in db().execute('PRAGMA table_info(users)')}:
            db().execute("ALTER TABLE users ADD COLUMN permissions TEXT NOT NULL DEFAULT ''")
        if 'category' not in {r[1] for r in db().execute('PRAGMA table_info(videos)')}:
            db().execute("ALTER TABLE videos ADD COLUMN category TEXT NOT NULL DEFAULT ''")
        observation_columns={r[1] for r in db().execute('PRAGMA table_info(observations)')}
        if 'updated' not in observation_columns:
            db().execute('ALTER TABLE observations ADD COLUMN updated REAL NOT NULL DEFAULT 0')
        if 'updated_by' not in observation_columns:
            db().execute('ALTER TABLE observations ADD COLUMN updated_by INTEGER REFERENCES users(id)')
        if 'deleted' not in observation_columns:
            db().execute('ALTER TABLE observations ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0')
        player_columns={r[1] for r in db().execute('PRAGMA table_info(players)')}
        if 'photo' not in player_columns:
            db().execute("ALTER TABLE players ADD COLUMN photo TEXT NOT NULL DEFAULT ''")
        if 'photo_updated' not in player_columns:
            db().execute('ALTER TABLE players ADD COLUMN photo_updated REAL NOT NULL DEFAULT 0')
        for old_task, new_task in (('Opbouw','Opbouwen'),('Drukzetten','Opbouw verstoren'),('Kansen creeren','Kansen creëren')):
            db().execute('UPDATE videos SET task=? WHERE task=? COLLATE NOCASE',(new_task,old_task))
        # A process restart can interrupt a worker. Mark those jobs for explicit retry.
        if recover_jobs:
            db().execute("UPDATE videos SET state='failed', analysis=? WHERE state IN ('queued','processing')", (json.dumps({'error': 'Analyse onderbroken door herstart. Start de analyse opnieuw.'}),))
        try:
            retention_days=max(30,min(int(os.environ.get('TEAM_AUDIT_RETENTION_DAYS','365')),3650))
        except ValueError:
            retention_days=365
        db().execute('DELETE FROM audit_log WHERE created<?',(time.time()-retention_days*86400,))
        db().commit()

    def password_ok(password):
        if not isinstance(password, str) or len(password) < 12 or len(password) > 256:
            abort(400, 'Gebruik een wachtwoord van 12 tot 256 tekens.')

    app.password_ok = password_ok

    @app.before_request
    def validate_json_shape():
        g.request_id=uuid.uuid4().hex
        if os.environ.get('TEAM_ENFORCE_HTTPS')=='1' and not request.is_secure:
            if request.method in ('GET','HEAD'):
                return redirect('https://'+request.host+request.full_path.rstrip('?'),code=308)
            abort(400,'Gebruik een beveiligde HTTPS-verbinding.')
        multipart=request.path in ('/api/videos','/api/presentations','/api/football/import','/api/smart-analysis/import','/api/club-documents','/api/superstar/import') or (request.path.startswith('/api/players/') and request.path.endswith('/photo')) or (request.path.startswith('/api/staff/') and request.path.endswith('/photo'))
        if request.path.startswith('/api/') and request.method == 'POST' and not multipart:
            if not request.is_json or not isinstance(request.get_json(), dict):
                abort(400, 'Een JSON-object is vereist.')

    def user():
        token = request.cookies.get('team_session', '')
        key = hashlib.sha256(token.encode()).hexdigest()
        row = db().execute('SELECT u.*, s.csrf FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>? AND u.active=1', (key, time.time())).fetchone()
        return row

    def protect(fn):
        @functools.wraps(fn)
        def wrapped(*args, **kwargs):
            g.user = user()
            if not g.user:
                abort(401, 'Log in om verder te gaan.')
            if request.method != 'GET' and not secrets.compare_digest(request.headers.get('X-CSRF-Token', ''), g.user['csrf']):
                abort(403, 'Ongeldige sessiecontrole. Log opnieuw in.')
            season_context()
            return fn(*args, **kwargs)
        return wrapped

    def admin():
        if g.user['role'] != 'admin':
            abort(403, 'Alleen de beheerder kan accounts en teams beheren.')

    def permitted(module, write=False):
        level = resolve_permissions(g.user)['modules'].get(module, 'none')
        return level == 'write' if write else level in ('read', 'write')

    def require(module, write=False):
        if not permitted(module, write):
            abort(403, 'Geen toegang tot dit onderdeel.')

    def team_allowed(team_id):
        if g.user['role'] == 'admin':
            return True
        scope = resolve_permissions(g.user)
        if not scope['all_teams'] and team_id not in scope['team_ids']:
            return False
        if g.user['role'] == 'player':
            return bool(db().execute('SELECT 1 FROM season_players WHERE season_id=? AND player_id=? AND team_id=?',(g.season_id,g.user['player_id'],team_id)).fetchone())
        return True

    def player_allowed(player_id, write=False):
        require('players', write)
        row = db().execute('SELECT p.id,p.name,p.photo,p.photo_updated,m.team_id,m.shirt_number,m.position,m.goal FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=? AND p.id=?',(g.season_id,player_id)).fetchone()
        if not row:
            abort(404, 'Speler niet gevonden.')
        if not team_allowed(row['team_id']) or (g.user['role'] == 'player' and (write or row['id'] != g.user['player_id'])):
            abort(403, 'Geen toegang tot deze speler.')
        return row

    def text(payload, key, limit=200, required=True):
        value = str(payload.get(key, '')).strip()
        if (required and not value) or len(value) > limit:
            abort(400, f'Vul {key} in (maximaal {limit} tekens).')
        return value

    def task_name(value, existing=''):
        value = str(value).strip()
        if not value:
            return ''
        aliases = {'opbouw':'Opbouwen', 'drukzetten':'Opbouw verstoren', 'kansen creeren':'Kansen creëren'}
        canonical = next((t for t in TASKS if t.casefold()==value.casefold()), aliases.get(value.casefold()))
        if canonical:
            return canonical
        if value and value == existing:
            return existing
        abort(400, 'Kies een van de zes teamtaakmappen.')

    @app.errorhandler(Exception)
    def error(exc):
        from werkzeug.exceptions import HTTPException
        connection=g.get('db')
        if connection:
            connection.rollback()
        if isinstance(exc, HTTPException):
            return jsonify(error=exc.description), exc.code
        if isinstance(exc, (ValueError, TypeError)):
            return jsonify(error='Ongeldige invoer.'), 400
        if isinstance(exc, sqlite3.IntegrityError):
            return jsonify(error='Deze naam bestaat al of de koppeling is ongeldig.'), 400
        app.logger.exception('Verzoek mislukt')
        return jsonify(error='Verzoek mislukt. Probeer opnieuw.'), 500

    @app.after_request
    def headers(response):
        response.headers['X-Request-ID']=getattr(g,'request_id',uuid.uuid4().hex)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; worker-src 'self'; manifest-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        if os.environ.get('TEAM_HTTPS')=='1':
            response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
        if request.path.startswith(('/api/', '/media/', '/documents/', '/photos/', '/staff-photos/', '/club-documents/')):
            response.headers['Cache-Control'] = 'no-store'
        elif request.path in ('/','/sw.js','/manifest.webmanifest') or request.path.startswith('/static/'):
            response.headers['Cache-Control'] = 'no-cache'
        if request.method in ('POST','PUT','PATCH','DELETE'):
            try:
                current=getattr(g,'user',None)
                audit_key=os.environ.get('TEAM_AUDIT_KEY','').encode()
                address=request.remote_addr or ''
                address_hash=hmac.new(audit_key,address.encode(),hashlib.sha256).hexdigest()[:20] if audit_key else 'niet-opgeslagen'
                db().execute('INSERT INTO audit_log(created,request_id,user_id,username,method,path,status,address_hash) VALUES (?,?,?,?,?,?,?,?)',
                    (time.time(),response.headers['X-Request-ID'],current['id'] if current else None,current['username'] if current else '',request.method,request.path,response.status_code,address_hash))
                db().commit()
            except Exception:
                app.logger.exception('Auditregistratie mislukt')
        return response

    @app.get('/')
    def index():
        return render_template('index.html')

    @app.get('/privacy')
    def privacy_page():
        legal=legal_context();club=db().execute("SELECT value FROM settings WHERE key='club_name'").fetchone()
        legal['association']=club['value'] if club else '[Vul voetbalvereniging in]'
        return render_template('legal_privacy.html',legal=legal)

    @app.get('/verwerkersovereenkomst')
    def processor_page():
        legal=legal_context();club=db().execute("SELECT value FROM settings WHERE key='club_name'").fetchone()
        legal['association']=club['value'] if club else '[Vul voetbalvereniging in]'
        return render_template('legal_dpa.html',legal=legal)

    @app.get('/manifest.webmanifest')
    def web_manifest():
        return send_file(ROOT/'static'/'manifest.webmanifest',mimetype='application/manifest+json')

    @app.get('/sw.js')
    def service_worker():
        response=send_file(ROOT/'static'/'sw.js',mimetype='text/javascript')
        response.headers['Service-Worker-Allowed']='/'
        return response

    @app.post('/api/login')
    def login():
        origin = request.headers.get('Origin')
        if origin and origin.rstrip('/') != request.host_url.rstrip('/'):
            abort(403, 'Ongeldige herkomst.')
        if not request.is_json:
            abort(400, 'JSON vereist.')
        payload = request.get_json()
        address = request.remote_addr
        attempt = db().execute('SELECT * FROM login_attempts WHERE address=?', (address,)).fetchone()
        if attempt and attempt['failures'] >= 8 and attempt['until'] > time.time():
            abort(429, 'Te veel pogingen. Probeer het over 15 minuten opnieuw.')
        row = db().execute('SELECT * FROM users WHERE username=? AND active=1', (str(payload.get('username','')).strip(),)).fetchone()
        password = payload.get('password', '')
        # Always run a password check, also for unknown accounts.
        candidate = row['password'] if row else app.config['DUMMY_HASH']
        valid = isinstance(password, str) and len(password) <= 256 and check_password_hash(candidate, password)
        if not row or not valid:
            failures = attempt['failures'] + 1 if attempt and attempt['until'] > time.time() else 1
            db().execute('INSERT OR REPLACE INTO login_attempts VALUES (?,?,?)', (address, failures, time.time()+900))
            db().commit()
            abort(401, 'Gebruikersnaam of wachtwoord onjuist.')
        token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        db().execute('DELETE FROM sessions WHERE expires<?', (time.time(),))
        db().execute('INSERT INTO sessions VALUES (?,?,?,?)', (hashlib.sha256(token.encode()).hexdigest(), row['id'], csrf, time.time()+8*3600))
        db().execute('DELETE FROM login_attempts WHERE address=?', (address,))
        db().commit()
        response = jsonify(ok=True)
        response.set_cookie('team_session', token, httponly=True, samesite='Strict', secure=os.environ.get('TEAM_HTTPS') == '1', max_age=8*3600, path='/')
        return response

    app.config['DUMMY_HASH'] = generate_password_hash(secrets.token_urlsafe(32))

    @app.get('/api/me')
    @protect
    def me():
        return jsonify(id=g.user['id'], player_id=g.user['player_id'], username=g.user['username'], role=g.user['role'], csrf=g.user['csrf'], permissions=resolve_permissions(g.user))

    @app.post('/api/logout')
    @protect
    def logout():
        key = hashlib.sha256(request.cookies['team_session'].encode()).hexdigest()
        db().execute('DELETE FROM sessions WHERE token=?', (key,))
        db().commit()
        response = jsonify(ok=True)
        response.delete_cookie('team_session')
        return response

    @app.get('/api/dashboard')
    @protect
    def dashboard():
        needs_team_context = any(permitted(m) for m in ('teams','players','videos','analysis','presentations','matches','training','availability','selections','plans','reports','tracking','staff','medical'))
        teams = [dict(t) for t in db().execute('SELECT * FROM teams ORDER BY name') if needs_team_context and team_allowed(t['id'])]
        ids = {t['id'] for t in teams}
        players = [dict(p) for p in db().execute('SELECT p.id,p.name,p.photo,p.photo_updated,m.team_id,m.shirt_number,m.position,m.goal FROM players p JOIN season_players m ON m.player_id=p.id WHERE m.season_id=? ORDER BY p.name',(g.season_id,)) if (permitted('players') or permitted('tracking')) and p['team_id'] in ids and (g.user['role'] != 'player' or p['id'] == g.user['player_id'])]
        for player in players:
            player['has_photo']=bool(player.pop('photo'))
        player_ids = {p['id'] for p in players}
        videos = []
        for row in db().execute('SELECT * FROM videos WHERE season_id=? ORDER BY created DESC',(g.season_id,)):
            if not permitted('videos') or row['team_id'] not in ids or (g.user['role'] == 'player' and row['kind'] != 'match' and row['player_id'] != g.user['player_id']):
                continue
            v = dict(row)
            v.pop('filename')
            v['analysis'] = json.loads(v['analysis'])
            videos.append(v)
        observations = [dict(o) for o in db().execute('SELECT * FROM observations WHERE season_id=? AND deleted=0 ORDER BY created DESC',(g.season_id,)) if o['player_id'] in player_ids]
        video_ids = {v['id'] for v in videos}
        moments = [dict(m) for m in db().execute('SELECT * FROM moments ORDER BY second') if m['video_id'] in video_ids and (g.user['role'] != 'player' or m['player_id'] == g.user['player_id'])]
        settings = dict(db().execute('SELECT key,value FROM settings'))
        extra = extensions_dashboard()
        extra.update(planning_dashboard())
        extra.update(season_summary())
        extra.update(care_summary())
        extra.update(smart_match_summary())
        extra.update(club_suite_summary())
        extra.update(documents_summary())
        extra.update(superstar_summary())
        extra.update(tracking_summary())
        settings['season']=g.season['name']
        return jsonify(teams=teams, players=players, videos=videos, observations=observations, moments=moments, functions=FUNCTIONS, tasks=TASKS, settings=settings, **extra)

    @app.post('/api/teams')
    @protect
    def teams_create():
        admin()
        payload = request.get_json()
        if payload.get('id'):
            cursor = db().execute('UPDATE teams SET name=? WHERE id=?', (text(payload, 'name'), int(payload['id'])))
            if not cursor.rowcount:
                abort(404, 'Team niet gevonden.')
        else:
            db().execute('INSERT INTO teams(name) VALUES (?)', (text(payload, 'name'),))
        db().commit()
        return jsonify(ok=True)

    @app.post('/api/players')
    @protect
    def players_create():
        require('players', True)
        payload = request.get_json()
        team_id = int(payload.get('team_id', 0))
        if g.user['role'] == 'player' or not team_allowed(team_id):
            abort(403, 'Geen schrijfrechten voor dit team.')
        name, position, goal = text(payload, 'name'), text(payload, 'position', required=False), text(payload, 'goal', 2000, False)
        number = payload.get('shirt_number')
        number = int(number) if number is not None and str(number).strip() else None
        if number is not None and not 1 <= number <= 99:
            abort(400, 'Rugnummer moet tussen 1 en 99 liggen.')
        if payload.get('id'):
            old = player_allowed(int(payload['id']), write=True)
            if team_id != old['team_id']:
                admin()
            key=old['id']
            db().execute('UPDATE players SET name=?,shirt_number=NULL WHERE id=?',(name,key))
        else:
            key=db().execute('INSERT INTO players(team_id,name,position,goal,shirt_number) VALUES (?,?,?,?,NULL)',(team_id,name,position,goal)).lastrowid
        db().execute('INSERT INTO season_players VALUES (?,?,?,?,?,?) ON CONFLICT(season_id,player_id) DO UPDATE SET team_id=excluded.team_id,shirt_number=excluded.shirt_number,position=excluded.position,goal=excluded.goal',
                     (g.season_id,key,team_id,number,position,goal))
        db().commit()
        return jsonify(ok=True)

    @app.post('/api/players/bulk')
    @protect
    def players_bulk():
        require('players',True)
        if g.user['role']=='player':abort(403,'Geen schrijfrechten.')
        payload=request.get_json();team_id=int(payload.get('team_id') or 0)
        if not team_allowed(team_id):abort(403,'Geen toegang tot dit team.')
        rows=payload.get('rows')
        if not isinstance(rows,list) or not 1<=len(rows)<=100:abort(400,'Voeg 1 tot 100 spelers tegelijk toe.')
        clean=[];numbers=set()
        for row in rows:
            if not isinstance(row,dict):abort(400,'Ongeldige spelerslijst.')
            name=str(row.get('name','')).strip();position=str(row.get('position','')).strip();raw=row.get('shirt_number');number=int(raw) if str(raw or '').strip() else None
            if not name or len(name)>200 or len(position)>200 or number is not None and not 1<=number<=99:abort(400,'Controleer naam, positie en rugnummer.')
            if number is not None and number in numbers:abort(400,'Een rugnummer staat dubbel in de lijst.')
            numbers.add(number);clean.append((name,position,number))
        existing={r[0] for r in db().execute('SELECT shirt_number FROM season_players WHERE season_id=? AND team_id=? AND shirt_number IS NOT NULL',(g.season_id,team_id))}
        if any(number in existing for _,_,number in clean if number is not None):abort(400,'Een rugnummer bestaat al in dit team.')
        ids=[]
        for name,position,number in clean:
            key=db().execute('INSERT INTO players(team_id,name,position,goal,shirt_number) VALUES (?,?,?,\'\',NULL)',(team_id,name,position)).lastrowid;db().execute('INSERT INTO season_players VALUES (?,?,?,?,?,\'\')',(g.season_id,key,team_id,number,position));ids.append(key)
        db().commit();return jsonify(ok=True,count=len(ids),ids=ids)

    @app.post('/api/players/<int:player_id>/photo')
    @protect
    def player_photo_upload(player_id):
        old=player_allowed(player_id,write=True)
        try:
            from PIL import Image, ImageOps, UnidentifiedImageError
        except ImportError:
            abort(503,'Fotoverwerking is nog niet geïnstalleerd. Laat de beheerder requirements.txt installeren en de webapp herladen.')
        if request.content_length and request.content_length>6*1024*1024:
            abort(400,'Maximaal 5 MB per spelersfoto.')
        upload=request.files.get('file')
        if not upload:
            abort(400,'Kies een JPG-, PNG- of WebP-foto.')
        raw=upload.stream.read(5*1024*1024+1)
        if len(raw)>5*1024*1024:
            abort(400,'Maximaal 5 MB per spelersfoto.')
        try:
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('error',Image.DecompressionBombWarning)
                with Image.open(io.BytesIO(raw)) as check:
                    if check.format not in ('JPEG','PNG','WEBP') or check.width*check.height>20_000_000:
                        abort(400,'Gebruik een JPG, PNG of WebP met maximaal 20 megapixels.')
                    check.verify()
                with Image.open(io.BytesIO(raw)) as source:
                    normalized=ImageOps.exif_transpose(source)
                    normalized.thumbnail((640,640))
                    if normalized.mode in ('RGBA','LA') or 'transparency' in normalized.info:
                        rgba=normalized.convert('RGBA')
                        normalized=Image.new('RGB',rgba.size,'white')
                        normalized.paste(rgba,mask=rgba.getchannel('A'))
                    else:
                        normalized=normalized.convert('RGB')
                    encoded=io.BytesIO()
                    normalized.save(encoded,format='JPEG',quality=88,optimize=True)
        except (UnidentifiedImageError,OSError,ValueError,Image.DecompressionBombWarning,Image.DecompressionBombError):
            abort(400,'Deze afbeelding kan niet worden gelezen. Kies een geldige JPG, PNG of WebP.')
        filename=uuid.uuid4().hex+'.jpg'
        path=data/'photos'/filename
        path.write_bytes(encoded.getvalue())
        try:
            db().execute('UPDATE players SET photo=?,photo_updated=? WHERE id=?',(filename,time.time(),player_id))
            db().commit()
        except Exception:
            path.unlink(missing_ok=True)
            raise
        if old['photo']:
            (data/'photos'/old['photo']).unlink(missing_ok=True)
        return jsonify(ok=True)

    @app.get('/photos/<int:player_id>')
    @protect
    def player_photo(player_id):
        player=player_allowed(player_id)
        if not player['photo']:
            abort(404,'Spelersfoto niet gevonden.')
        return send_file(data/'photos'/player['photo'],mimetype='image/jpeg',conditional=True)

    @app.get('/api/users')
    @protect
    def users_list():
        admin()
        rows = [dict(u) for u in db().execute('SELECT id,username,role,player_id,active,permissions FROM users ORDER BY username')]
        for row in rows:
            row['permissions'] = resolve_permissions(row)
            row['team_ids'] = [t[0] for t in db().execute('SELECT team_id FROM access WHERE user_id=?', (row['id'],))]
        return jsonify(rows)

    @app.post('/api/users')
    @protect
    def users_create():
        admin()
        payload = request.get_json()
        username, password = text(payload, 'username', 80), payload.get('password')
        password_ok(password)
        role = payload.get('role')
        if role not in ('trainer', 'player'):
            abort(400, 'Kies trainer of speler.')
        player_id = int(payload['player_id']) if role == 'player' and payload.get('player_id') else None
        if role == 'player' and not player_id:
            abort(400, 'Koppel een speler aan dit account.')
        permissions = validate_permissions(payload['permissions'], role, {r[0] for r in db().execute('SELECT id FROM teams')}) if 'permissions' in payload else ''
        cursor = db().execute('INSERT INTO users(username,password,role,player_id,permissions) VALUES (?,?,?,?,?)', (username, generate_password_hash(password), role, player_id, permissions))
        if role == 'trainer':
            for team_id in set(payload.get('team_ids', [])):
                db().execute('INSERT INTO access VALUES (?,?)', (cursor.lastrowid, int(team_id)))
        db().commit()
        return jsonify(ok=True)

    @app.post('/api/users/<int:user_id>/manage')
    @protect
    def users_manage(user_id):
        admin()
        row = db().execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
        if not row or row['role'] == 'admin':
            abort(400, 'Beheerdersaccount kan hier niet worden gewijzigd.')
        payload = request.get_json()
        if 'permissions' in payload:
            permissions = validate_permissions(payload['permissions'], row['role'], {r[0] for r in db().execute('SELECT id FROM teams')})
            db().execute('UPDATE users SET permissions=? WHERE id=?', (permissions, user_id))
        if payload.get('password'):
            password_ok(payload['password'])
            db().execute('UPDATE users SET password=? WHERE id=?', (generate_password_hash(payload['password']), user_id))
        if 'active' in payload:
            db().execute('UPDATE users SET active=? WHERE id=?', (int(bool(payload['active'])), user_id))
        db().execute('DELETE FROM sessions WHERE user_id=?', (user_id,))
        db().commit()
        return jsonify(ok=True)

    @app.post('/api/observations')
    @protect
    def observation_create():
        payload = request.get_json()
        player = player_allowed(int(payload.get('player_id', 0)), write=True)
        rating = int(payload.get('rating', 0))
        if not 1 <= rating <= 5:
            abort(400, 'Beoordeling moet tussen 1 en 5 liggen.')
        key=int(payload.get('id') or 0)
        stamp=time.time()
        if key:
            old=db().execute('SELECT * FROM observations WHERE id=?',(key,)).fetchone()
            if not old or old['season_id']!=g.season_id or old['deleted']:
                abort(404,'Beoordeling niet gevonden.')
            player_allowed(old['player_id'],write=True)
            if old['player_id']!=player['id']:
                abort(400,'Een beoordeling kan niet naar een andere speler worden verplaatst.')
            db().execute('UPDATE observations SET category=?,rating=?,note=?,updated=?,updated_by=? WHERE id=?',
                         (text(payload,'category'),rating,text(payload,'note',2000),stamp,g.user['id'],key))
        else:
            key=db().execute('INSERT INTO observations(player_id,user_id,category,rating,note,created,updated,updated_by,season_id) VALUES (?,?,?,?,?,?,?,?,?)',
                             (player['id'],g.user['id'],text(payload,'category'),rating,text(payload,'note',2000),stamp,stamp,g.user['id'],g.season_id)).lastrowid
        db().commit()
        return jsonify(ok=True,id=key)

    @app.post('/api/observations/<int:key>/<action>')
    @protect
    def observation_remove(key,action):
        if action not in ('delete','restore'):
            abort(404,'Actie niet gevonden.')
        row=db().execute('SELECT * FROM observations WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not row:
            abort(404,'Observatie niet gevonden.')
        player_allowed(row['player_id'],write=True)
        db().execute('UPDATE observations SET deleted=?,updated=?,updated_by=? WHERE id=?',(int(action=='delete'),time.time(),g.user['id'],key))
        db().commit()
        return jsonify(ok=True,id=key)

    def video_allowed(video_id):
        require('videos')
        row = db().execute('SELECT * FROM videos WHERE id=?', (video_id,)).fetchone()
        if not row or row['season_id']!=g.season_id:
            abort(404, 'Video niet gevonden.')
        if not team_allowed(row['team_id']) or (g.user['role'] == 'player' and row['kind'] != 'match' and row['player_id'] != g.user['player_id']):
            abort(403, 'Geen toegang tot deze video.')
        return row

    @app.post('/api/moments')
    @protect
    def moments_create():
        require('videos', True)
        if g.user['role'] == 'player':
            abort(403, 'Alleen trainers en beheerder kunnen momenten vastleggen.')
        payload = request.get_json()
        video = video_allowed(str(payload.get('video_id', '')))
        second = float(payload.get('second', -1))
        import math
        if not math.isfinite(second) or second < 0:
            abort(400, 'Geef een geldig tijdstip op.')
        analysis = json.loads(video['analysis'])
        duration = analysis.get('duration')
        if not duration:
            duration = probe(str(data / 'videos' / video['filename']))['duration']
        if second > duration:
            abort(400, 'Dit tijdstip ligt na het einde van de video.')
        player_id = int(payload['player_id']) if payload.get('player_id') else None
        if player_id and player_allowed(player_id)['team_id'] != video['team_id']:
            abort(400, 'Speler hoort niet bij het team van deze video.')
        outcome = payload.get('outcome', 'neutraal')
        if outcome not in ('geslaagd', 'verbeterpunt', 'neutraal'):
            abort(400, 'Kies een geldige beoordeling.')
        db().execute('INSERT INTO moments(video_id,player_id,user_id,second,label,outcome,note,created) VALUES (?,?,?,?,?,?,?,?)',
                     (video['id'], player_id, g.user['id'], second, text(payload, 'label'), outcome, text(payload, 'note', 2000, False), time.time()))
        db().commit()
        return jsonify(ok=True)

    @app.post('/api/videos/<video_id>/details')
    @protect
    def video_details(video_id):
        require('videos', True)
        if g.user['role'] == 'player':
            abort(403, 'Geen schrijfrechten.')
        row = video_allowed(video_id)
        payload = request.get_json()
        function = payload.get('function') or ''
        kind = payload.get('kind')
        if (function and function not in FUNCTIONS) or kind not in ('clip', 'match'):
            abort(400, 'Kies een geldige teamfunctie en videosoort.')
        player_id = int(payload['player_id']) if payload.get('player_id') else None
        if player_id and player_allowed(player_id)['team_id'] != row['team_id']:
            abort(400, 'Speler hoort niet bij dit team.')
        db().execute('UPDATE videos SET title=?,task=?,function=?,kind=?,player_id=?,category=? WHERE id=?',
                     (text(payload,'title'), task_name(text(payload,'task',required=False), row['task']), function, kind, player_id, text(payload,'category',120,False), video_id))
        db().commit()
        return jsonify(ok=True)

    @app.get('/api/system')
    @protect
    def system_info():
        admin()
        import shutil
        total_bytes = sum(p.stat().st_size for p in (data / 'videos').iterdir() if p.is_file())
        return jsonify(video_bytes=total_bytes, ffmpeg=bool(shutil.which('ffmpeg')), ffprobe=bool(shutil.which('ffprobe')), analysis_mode=analysis_mode,
                       accounts=db().execute('SELECT COUNT(*) FROM users').fetchone()[0],
                       active_accounts=db().execute('SELECT COUNT(*) FROM users WHERE active=1').fetchone()[0])

    @app.get('/api/audit')
    @protect
    def audit_overview():
        admin()
        try:
            limit=min(max(int(request.args.get('limit',100)),1),500)
        except ValueError:
            abort(400,'Ongeldige limiet.')
        rows=[dict(r) for r in db().execute('SELECT id,created,request_id,user_id,username,method,path,status FROM audit_log ORDER BY id DESC LIMIT ?',(limit,))]
        return jsonify(rows=rows,retention_days=int(os.environ.get('TEAM_AUDIT_RETENTION_DAYS','365')))

    @app.post('/api/settings')
    @protect
    def settings_update():
        admin()
        payload = request.get_json()
        for key in ('club_name', 'season'):
            value = text(payload, key, limit=120, required=False)
            db().execute('INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)', (key, value))
        db().commit()
        return jsonify(ok=True)

    def analyse(video_id):
        with app.app_context():
            row = db().execute('SELECT * FROM videos WHERE id=?', (video_id,)).fetchone()
            path = str(data / 'videos' / row['filename'])
            db().execute("UPDATE videos SET state='processing' WHERE id=?", (video_id,))
            db().commit()
            try:
                result = probe(path)
                # Actual visual analysis, limited to 120 seconds: frame differences, not football action recognition.
                frames = subprocess.run(['ffmpeg','-v','error','-protocol_whitelist','file,pipe','-format_whitelist','mov,matroska,webm','-i',path,'-t','120','-vf','fps=1,scale=64:36','-pix_fmt','gray','-f','rawvideo','-an','pipe:1'], capture_output=True, timeout=90, check=True).stdout
                size = 64*36
                diffs = []
                for offset in range(size, len(frames)-size+1, size):
                    before, after = frames[offset-size:offset], frames[offset:offset+size]
                    diffs.append(sum(abs(a-b) for a,b in zip(before,after))/(size*255)*100)
                result['frame_change_percent'] = round(sum(diffs)/len(diffs), 2) if diffs else None
                result['sample_seconds'] = min(120, int(result['duration']))
                result['scope'] = 'Technische beeldanalyse. Beeldverandering omvat ook camerabeweging; dit is geen spelers- of actieherkenning.'
                db().execute("UPDATE videos SET state='done', analysis=? WHERE id=?", (json.dumps(result), video_id))
            except Exception:
                app.logger.exception('Videoanalyse mislukt voor %s', video_id)
                db().execute("UPDATE videos SET state='failed', analysis=? WHERE id=?", (json.dumps({'error':'Analyse mislukt. Controleer of de video afspeelbaar is en probeer opnieuw.'}),video_id))
            db().commit()

    app.analyse = analyse

    workers = ThreadPoolExecutor(max_workers=2, thread_name_prefix='video-analysis')
    app.analysis_workers = workers

    def schedule(video_id):
        if analysis_mode == 'background':
            workers.submit(analyse, video_id)

    @app.post('/api/videos')
    @protect
    def videos_create():
        require('videos', True)
        if g.user['role'] == 'player':
            abort(403, 'Alleen trainers en beheerder kunnen uploaden.')
        team_id = int(request.form.get('team_id', 0))
        if not team_allowed(team_id):
            abort(403, 'Geen toegang tot dit team.')
        player_id = int(request.form['player_id']) if request.form.get('player_id') else None
        if player_id and player_allowed(player_id)['team_id'] != team_id:
            abort(400, 'Speler hoort niet bij dit team.')
        function = request.form.get('function') or ''
        kind = request.form.get('kind', 'clip')
        if kind not in ('clip', 'match'):
            abort(400, 'Kies clip of volledige wedstrijd.')
        if function and function not in FUNCTIONS:
            abort(400, 'Kies een teamfunctie.')
        title, task = text(request.form, 'title'), task_name(text(request.form, 'task',required=False))
        upload = request.files.get('file')
        if not upload or Path(upload.filename).suffix.lower() not in ('.mp4','.webm','.mov'):
            abort(400, 'Upload een MP4-, WebM- of MOV-video.')
        video_id = uuid.uuid4().hex
        filename = video_id + Path(upload.filename).suffix.lower()
        path = data / 'videos' / filename
        try:
            upload.save(path)
            probe(str(path))
            db().execute('INSERT INTO videos(id,team_id,player_id,title,task,function,kind,filename,created,category,season_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)', (video_id, team_id, player_id, title, task, function, kind, filename, time.time(),text(request.form,'category',120,False),g.season_id))
            db().commit()
        except Exception as exc:
            path.unlink(missing_ok=True)
            if isinstance(exc, FileNotFoundError):
                abort(503, 'Videoverwerking is niet beschikbaar op deze server. De beheerder moet FFmpeg en FFprobe installeren.')
            if isinstance(exc, (subprocess.SubprocessError, ValueError, KeyError)):
                abort(400, 'Geen leesbare video gevonden. Gebruik een geldige MP4, WebM of MOV.')
            raise
        schedule(video_id)
        return jsonify(ok=True, id=video_id), 201

    @app.post('/api/videos/<video_id>/retry')
    @protect
    def retry(video_id):
        require('videos', True)
        row = video_allowed(video_id)
        if g.user['role'] == 'player':
            abort(403, 'Geen schrijfrechten.')
        if row['state'] not in ('done','failed'):
            abort(409, 'Deze analyse loopt al.')
        db().execute("UPDATE videos SET state='queued' WHERE id=?", (video_id,))
        db().commit()
        schedule(video_id)
        return jsonify(ok=True)

    @app.get('/media/<video_id>')
    @protect
    def media(video_id):
        row = video_allowed(video_id)
        return send_file(data / 'videos' / row['filename'], conditional=True)

    from extensions import register_extensions
    extensions_dashboard = register_extensions(app, db, protect, require, permitted, team_allowed, admin, text)
    from planning import register_planning
    planning_dashboard = register_planning(app, db, protect, require, permitted, team_allowed, text)
    from seasons import register_seasons
    season_context,season_summary = register_seasons(app,db,protect,admin,text)
    from care import register_care
    care_summary = register_care(app,db,protect,require,permitted,team_allowed,text)
    from smart_match import register_smart_match
    smart_match_summary = register_smart_match(app,db,protect,require,permitted,team_allowed,admin,text)
    from club_suite import register_club_suite
    club_suite_summary = register_club_suite(app,db,protect,require,permitted,team_allowed,text)
    from communications import register_communications
    register_communications(app,db,protect,require,permitted,team_allowed,text)
    from documents import register_documents
    documents_summary=register_documents(app,db,protect,require,permitted,team_allowed,text)
    from superstar import register_superstar
    superstar_summary=register_superstar(app,db,protect,require,permitted,team_allowed,admin,text)
    from player_tracking import register_tracking
    tracking_summary=register_tracking(app,db,protect,require,permitted,team_allowed,text)
    from business import register_business
    register_business(app,db)

    @app.get('/api/business-leads')
    @protect
    def business_leads():
        admin();return jsonify(rows=[dict(r) for r in db().execute('SELECT * FROM business_leads ORDER BY created DESC')])

    return app


def probe(path):
    completed = subprocess.run(['ffprobe','-v','error','-protocol_whitelist','file,pipe','-format_whitelist','mov,matroska,webm','-show_entries','format=duration:stream=codec_type,width,height,avg_frame_rate','-of','json',path], capture_output=True, timeout=30, check=True)
    result = json.loads(completed.stdout)
    stream = next((s for s in result['streams'] if s.get('codec_type')=='video'), None)
    if not stream:
        raise ValueError('Geen videostream.')
    return {'duration': round(float(result['format']['duration']),2), 'width':stream['width'], 'height':stream['height'], 'frame_rate':stream.get('avg_frame_rate','')}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', nargs='?', choices=['serve','create-admin','analyse-pending','backup'], default='serve')
    parser.add_argument('--username')
    parser.add_argument('--output', help='Bestandspad voor een nieuwe back-up (ZIP)')
    args = parser.parse_args()
    application = create_app(recover_jobs=args.command == 'serve')
    if args.command == 'create-admin':
        with application.app_context():
            username = (args.username or input('Gebruikersnaam beheerder: ')).strip()
            password = getpass.getpass('Wachtwoord (minimaal 12 tekens): ')
            if password != getpass.getpass('Herhaal wachtwoord: '):
                raise SystemExit('Wachtwoorden verschillen.')
            if not username or len(username)>80:
                raise SystemExit('Gebruikersnaam is verplicht (maximaal 80 tekens).')
            application.password_ok(password)
            application.db().execute("INSERT INTO users(username,password,role) VALUES (?,?,'admin')", (username, generate_password_hash(password)))
            application.db().commit()
            print('Beheerdersaccount aangemaakt.')
    elif args.command == 'analyse-pending':
        with application.app_context():
            keys = [r[0] for r in application.db().execute("SELECT id FROM videos WHERE state='queued' ORDER BY created")]
        for key in keys:
            application.analyse(key)
        print(f'{len(keys)} videoanalyses verwerkt. Controleer de status in de videobibliotheek.')
    elif args.command == 'backup':
        if not args.output:
            raise SystemExit('Gebruik --output met een nieuwe ZIP-bestandsnaam buiten de datamap.')
        from maintenance import backup
        backup(application.config['DATA'], Path(args.output))
        print('Back-up opgeslagen. Bewaar dit bestand privé; het bevat accounts en teamgegevens.')
    else:
        application.run(host=os.environ.get('TEAM_HOST','127.0.0.1'), port=int(os.environ.get('TEAM_PORT','8001')), debug=False)
