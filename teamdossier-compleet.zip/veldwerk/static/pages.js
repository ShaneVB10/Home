// Extra workspace pages share the authenticated data and form helpers from app.js.
let selectedTeam = null, systemInfo = null, auditRows = [], watchingVideo = null;
function settingsView(){return settingsCore()+`<article class="panel"><div class="panel-head"><div><h2>Beveiligingslogboek</h2><p>Wijzigingen met gebruiker, tijdstip, actie en verzoeknummer. Formulier- en medische inhoud wordt niet gelogd.</p></div></div><div class="table-wrap"><table><thead><tr><th>Tijd</th><th>Gebruiker</th><th>Actie</th><th>Status</th><th>Verzoek</th></tr></thead><tbody>${auditRows.map(row=>`<tr><td>${new Date(row.created*1000).toLocaleString('nl-NL')}</td><td>${esc(row.username||'Niet ingelogd')}</td><td>${esc(row.method+' '+row.path)}</td><td>${row.status}</td><td><code>${esc(row.request_id)}</code></td></tr>`).join('')||'<tr><td colspan="5">Nog geen wijzigingen geregistreerd.</td></tr>'}</tbody></table></div><p class="hint">Standaard bewaartermijn: ${systemInfo?.audit_retention_days||365} dagen.</p></article>`;}
const timecode = seconds => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;

function observationForm(playerId,id=null){
  const o=data.observations.find(o=>o.id===id);
  const categories=['Techniek','Tactiek','Fysiek','Mentaliteit'];
  if(o&&!categories.includes(o.category))categories.push(o.category);
  openForm(o?'Beoordeling aanpassen':'Observatie toevoegen',`${o?`<input name="id" type="hidden" value="${o.id}">`:''}<input name="player_id" type="hidden" value="${playerId}">${select('category','Onderdeel',options(categories,o?.category||'Techniek'))}${select('rating','Trainersbeoordeling',[1,2,3,4,5].map(n=>`<option value="${n}" ${n===(o?.rating||3)?'selected':''}>${n} / 5</option>`).join(''))}<label>Observatie en volgende stap<textarea name="note" required maxlength="2000">${esc(o?.note||'')}</textarea></label>`,f=>post('/api/observations',Object.fromEntries(f)));
}

function playerPhotoForm(id){
  const p=data.players.find(p=>p.id===Number(id));
  openForm('Spelersfoto · '+p.name,`${p.has_photo?`<img class="photo-preview" src="/photos/${p.id}?v=${p.photo_updated}" alt="Huidige foto van ${esc(p.name)}">`:''}${field('file','Kies een JPG-, PNG- of WebP-foto (maximaal 5 MB)','file','','required accept="image/jpeg,image/png,image/webp"')}<p class="hint">De foto verschijnt op de spelerskaart en het profiel. Alleen accounts die dit spelersprofiel mogen bekijken kunnen de foto openen.</p>`,f=>{const file=f.get('file');if(file.size>5*1024*1024)throw Error('Maximaal 5 MB per spelersfoto.');return api('/api/players/'+p.id+'/photo',{method:'POST',body:f});},p.has_photo?'Foto vervangen':'Foto toevoegen');
}

function teamsView() {
  if (selectedTeam) return teamDetail();
  return `<div class="cards">${data.teams.map(t => {
    const players = data.players.filter(p => p.team_id === t.id);
    const videos = data.videos.filter(v => v.team_id === t.id);
    return `<article class="team-card"><div class="team-card-top"><div class="team-icon">⚑</div><span class="tag">${esc(data.settings.season || 'TEAM')}</span></div><h2>${esc(t.name)}</h2><p>${players.length} spelers · ${videos.length} video's</p><div class="team-roster">${players.slice(0, 6).map(p => `<span title="${esc(p.name)}">${p.shirt_number || '–'}</span>`).join('') || '<small>Nog geen spelers toegevoegd</small>'}</div><div class="actions">${button('team-detail', 'Open team →', true, `data-id="${t.id}"`)}${me.role === 'admin' ? button('team-edit', 'Wijzigen', false, `data-id="${t.id}"`) : ''}</div></article>`;
  }).join('')}</div>${data.teams.length ? '' : empty('Je eerste elftal begint hier.', 'Maak een team aan en voeg daarna spelers en beelden toe.', me.role === 'admin' ? button('team', '＋ Team toevoegen', true) : '')}`;
}

function teamDetail() {
  const t = data.teams.find(t => t.id === selectedTeam);
  if (!t) { selectedTeam = null; return teamsView(); }
  const players = data.players.filter(p => p.team_id === t.id), videos = data.videos.filter(v => v.team_id === t.id);
  return `<div class="actions page-back">${button('teams-back', '← Alle teams')}${me.role === 'admin' ? button('team-edit', 'Team wijzigen', false, `data-id="${t.id}"`) : ''}</div><section class="team-banner"><span class="tag">${esc(data.settings.season || 'JOUW TEAM')}</span><h2>${esc(t.name)}</h2><p>${players.length} spelers · ${videos.filter(v => v.kind === 'match').length} volledige wedstrijden · ${videos.filter(v => v.kind === 'clip').length} clips</p></section><div class="section-heading"><div><h2>De spelersgroep</h2><p>Doelen, observaties en beelden per speler.</p></div>${can('players',true) ? button('player', '＋ Speler toevoegen') : ''}</div><div class="cards">${players.map(playerCard).join('')}</div>${players.length ? '' : empty('Nog geen spelers in dit team.', 'Voeg je spelers toe om hun ontwikkeling te volgen.')}<div class="section-heading"><div><h2>Teambeelden</h2><p>Wedstrijden en clips uit de bibliotheek.</p></div>${can('videos',true) ? button('upload', '↑ Video uploaden') : ''}</div><div class="cards">${videos.slice(0, 9).map(videoCard).join('')}</div>${videos.length > 9 ? button('team-library', 'Alle teambeelden bekijken', false, `data-id="${t.id}"`) : ''}${videos.length ? '' : empty('Nog geen beelden.', 'Upload een wedstrijd of clip voor dit team.')}`;
}

function analysisView() {
  const players = data.players.filter(p => !team || String(p.team_id) === team);
  const ids = new Set(players.map(p => p.id));
  const observations = data.observations.filter(o => ids.has(o.player_id));
  const videoIds = new Set(data.videos.filter(v => !team || String(v.team_id) === team).map(v => v.id));
  const moments = data.moments.filter(m => videoIds.has(m.video_id));
  const categories = [...new Set(observations.map(o => o.category))];
  const average = observations.length ? (observations.reduce((sum, o) => sum + o.rating, 0) / observations.length).toFixed(1) : '—';
  return `<div class="toolbar"><select id="team-filter" aria-label="Filter op team"><option value="">Alle teams</option>${teamOptions()}</select></div><section class="stats">${[['Spelers', players.length, 'binnen je selectie'], ['Trainersobservaties', observations.length, 'vastgelegde beoordelingen'], ['Gemiddelde beoordeling', average, 'trainersscore op schaal 1–5'], ['Videomomenten', moments.length, 'handmatig gemarkeerd']].map(([label, n, hint]) => `<div class="stat"><span>${label}</span><strong>${n}</strong><small>${hint}</small></div>`).join('')}</section><div class="split"><article class="panel"><div class="panel-head"><div><h2>Ontwikkeling per onderdeel</h2><p>Gemiddelde van vastgelegde trainersbeoordelingen.</p></div></div>${categories.length ? `<div class="category-scores">${categories.map(c => {
    const rows = observations.filter(o => o.category === c), avg = rows.reduce((sum, o) => sum + o.rating, 0) / rows.length;
    return `<div class="category-score"><div><strong>${esc(c)}</strong><span>${avg.toFixed(1)} / 5</span></div><meter min="0" max="5" value="${avg}" aria-label="${esc(c)}"></meter><small>${rows.length} observaties</small></div>`;
  }).join('')}</div>` : empty('Nog geen beoordelingen.', 'Voeg observaties toe via een spelersprofiel. Dan verschijnt hier het overzicht.')}</article><article class="panel"><div class="panel-head"><div><h2>Vastgelegde videomomenten</h2><p>Beoordeling door je trainers.</p></div></div><div class="outcome-grid">${['geslaagd', 'verbeterpunt', 'neutraal'].map(k => `<div><strong>${moments.filter(m => m.outcome === k).length}</strong><span>${k}</span></div>`).join('')}</div><div class="notice">Dit overzicht is gebaseerd op trainersobservaties en gemarkeerde momenten. Het is geen automatische beoordeling van spelers of teamgedrag.</div></article></div><article class="panel"><div class="panel-head"><div><h2>Per speler</h2><p>Een ingang naar iedere ontwikkellijn.</p></div></div><div class="table-wrap"><table><thead><tr><th>Speler</th><th>Team</th><th>Observaties</th><th>Beoordeling</th><th>Profiel</th></tr></thead><tbody>${players.map(p => {
    const rows = observations.filter(o => o.player_id === p.id), avg = rows.length ? (rows.reduce((sum, o) => sum + o.rating, 0) / rows.length).toFixed(1) : '—';
    return `<tr><td><strong>${p.shirt_number ? '#' + p.shirt_number + ' · ' : ''}${esc(p.name)}</strong></td><td>${esc(teamName(p.team_id))}</td><td>${rows.length}</td><td>${avg}</td><td>${button('analysis-profile', 'Bekijken', false, `data-id="${p.id}"`)}</td></tr>`;
  }).join('') || '<tr><td colspan="5">Nog geen spelers in deze selectie.</td></tr>'}</tbody></table></div></article>`;
}

function settingsCore() {
  return `<div class="split"><article class="panel"><div class="panel-head"><div><h2>Je clubomgeving</h2><p>Herkenbaar voor jouw spelers en trainers.</p></div>${button('club-settings', 'Wijzigen')}</div><dl class="settings-list"><div><dt>Clubnaam</dt><dd>${esc(data.settings.club_name || 'Nog niet ingesteld')}</dd></div><div><dt>Seizoen</dt><dd>${esc(data.settings.season || 'Nog niet ingesteld')}</dd></div><div><dt>Accounts</dt><dd>${systemInfo ? systemInfo.active_accounts + ' actief / ' + systemInfo.accounts + ' totaal' : '—'}</dd></div><div><dt>Opgeslagen video's</dt><dd>${systemInfo ? (systemInfo.video_bytes / (1024 * 1024)).toFixed(1) + ' MB' : '—'}</dd></div></dl></article><article class="insight"><div class="eyebrow">JOUW OMGEVING BEHEREN</div><h3>Toegang blijft in jouw handen.</h3><p>Maak zelf accounts aan en stel opnieuw een wachtwoord in wanneer iemand dat nodig heeft. Gebruikers kunnen zich niet zelfstandig registreren.</p>${button('go-accounts', 'Naar toegangsbeheer →')}</article></div><div class="section-heading"><div><h2>Koppelingen & verwerking</h2><p>Wat je vandaag kunt gebruiken en wat nog gekoppeld moet worden.</p></div></div><div class="cards"><article class="connection-card"><span class="pill done">Beschikbaar</span><h3>Video-upload</h3><p>Upload geëxporteerde Veo-beelden en eigen video's. Orden op team, speler, teamtaak en teamfunctie.</p></article><article class="connection-card"><span class="pill ${systemInfo?.ffmpeg && systemInfo?.ffprobe ? 'done' : 'failed'}">${systemInfo?.ffmpeg && systemInfo?.ffprobe ? 'Beschikbaar' : 'Controle nodig'}</span><h3>Technische videoanalyse</h3><p>Duur, resolutie en beeldverandering worden na upload gemeten. Dit herkent geen spelers of voetbalacties.</p></article><article class="connection-card"><span class="pill queued">Nog niet gekoppeld</span><h3>Veo & spelersherkenning</h3><p>Directe Veo-import en herkenning op rugnummer vragen nog een geschikte koppeling en een getest analysemodel.</p></article></div><article class="panel"><div class="panel-head"><h2>Bewaren & bijwerken</h2></div><div class="notice">Maak voor een verhuizing of software-update een back-up van de database én de video's. Automatische software-updates en automatische back-ups zijn nog niet aangesloten. De installatiehandleiding beschrijft het online plaatsen en het maken van een lokale back-up.</div></article>`;
}

function helpView() {
  const items = [
    ['1. Teams en spelers', 'De beheerder maakt teams aan. Trainers en beheerder voegen spelers, rugnummers en ontwikkeldoelen toe. Open een spelersprofiel om observaties vast te leggen.'],
    ['2. Video’s op de juiste plek', 'Upload een clip of volledige wedstrijd en kies het team. Je kunt ook een speler koppelen. Leg de teamtaak en teamfunctie vast zodat je beelden later terugvindt.'],
    ['3. Momenten markeren', 'Open een video en zoek het juiste moment. Als trainer kun je de huidige afspeeltijd vastleggen, een speler koppelen en feedback toevoegen. Je kunt later direct naar dat moment springen.'],
    ['4. Ontwikkeling volgen', 'Het ontwikkeloverzicht bundelt observaties en gemarkeerde momenten. Beoordelingen zijn afkomstig van trainers; de technische videoanalyse doet geen voetbalinhoudelijke uitspraken.'],
    ['5. Wie ziet wat?', 'De beheerder bepaalt welke onderdelen en teams een account mag bekijken of bewerken. Spelers zien hun eigen profiel, eigen clips en volledige wedstrijden van hun eigen team. Teamclips zonder speler blijven bij de trainers.'],
    ['6. Inloggen en hulp', 'Alleen de beheerder geeft accounts uit. Wachtwoord vergeten? Vraag je beheerder een nieuw wachtwoord in te stellen. Blokkeren of een wachtwoordreset beëindigt bestaande sessies.']
  ];
  return `<div class="help-grid">${items.map(([title, content]) => `<article class="help-card"><h2>${title}</h2><p>${content}</p></article>`).join('')}</div>`;
}

function renderMoments(videoId) {
  const rows = data.moments.filter(m => m.video_id === videoId);
  $('#video-moments').innerHTML = `<div class="section-heading"><div><h3>Gemarkeerde momenten</h3><p>Feedback van je trainer, op het juiste moment.</p></div>${can('videos',true) ? button('moment', '＋ Huidig moment vastleggen', false, `data-id="${videoId}"`) : ''}</div>${rows.map(m => `<div class="moment-row"><button class="time-button" data-action="seek-moment" data-second="${m.second}">${timecode(m.second)}</button><div><strong>${esc(m.label)}</strong><small>${esc(m.player_id ? playerName(m.player_id) : 'Team')} · ${esc(m.outcome)}</small><p>${esc(m.note)}</p></div></div>`).join('') || '<p class="hint">Nog geen momenten vastgelegd.</p>'}`;
}

function openVideo(id) {
  watchingVideo = id;
  const v = data.videos.find(v => v.id === id);
  $('#video-title').textContent = v.title;
  $('#video-player').src = seasonUrl(`/media/${id}`);
  updateVideoPanel();
  $('#video-dialog').showModal();
}

function updateVideoPanel() {
  const v = data.videos.find(v => v.id === watchingVideo);
  if (!v) return;
  const a = v.analysis;
  $('#video-analysis').innerHTML = `<h3>Technische analyse</h3><span class="pill ${v.state}">${stateName[v.state]}</span>${v.state === 'done' ? `<div class="info-grid"><div><strong>${a.duration} s</strong><small>duur</small></div><div><strong>${a.width} × ${a.height}</strong><small>resolutie</small></div><div><strong>${a.frame_change_percent === null ? '—' : a.frame_change_percent + '%'}</strong><small>gemiddelde beeldverandering</small></div></div><p class="notice">${esc(a.scope)} De eerste ${a.sample_seconds} seconden zijn bemonsterd. Er wordt geen voetbalinhoudelijk oordeel gegeven.</p>` : `<p>${esc(a.error || 'De technische analyse wordt op de achtergrond uitgevoerd. Het resultaat verschijnt hier automatisch.')}</p>`}`;
  renderMoments(v.id);
}

async function extraAction(action, id, buttonEl) {
  if (action === 'team-detail') { selectedTeam = Number(id); team = id; view = 'teams'; render(); }
  else if (action === 'teams-back') { selectedTeam = null; team = ''; render(); }
  else if (action === 'team-edit') {
    const t = data.teams.find(t => t.id === Number(id));
    openForm('Team wijzigen', `<input type="hidden" name="id" value="${t.id}">${field('name', 'Teamnaam', 'text', t.name, 'required maxlength="200"')}`, f => post('/api/teams', Object.fromEntries(f)));
  } else if (action === 'team-library') { team = id; player = null; view = 'videos'; search = ''; functionFilter = ''; render(); }
  else if (action === 'analysis-profile') { player = Number(id); view = 'players'; render(); }
  else if (action === 'go-accounts') { view = 'accounts'; await refresh(); }
  else if (action === 'club-settings') openForm('Clubinstellingen', `${field('club_name', 'Clubnaam', 'text', data.settings.club_name || '', 'maxlength="120"')}<p>Beheer seizoenen via de knop ‘Seizoenen beheren’ bovenaan de pagina.</p>`, f => post('/api/settings', Object.fromEntries(f)));
  else if (action === 'video-edit') {
    const v = data.videos.find(v => v.id === id);
    const options = data.players.filter(p => p.team_id === v.team_id).map(p => `<option value="${p.id}" ${p.id === v.player_id ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    openForm('Videogegevens wijzigen', `${field('title', 'Titel', 'text', v.title, 'required maxlength="200"')}${select('player_id', 'Speler', '<option value="">Teambeelden (geen individuele speler)</option>' + options)}${select('kind', 'Zichtbaarheid', `<option value="clip" ${v.kind === 'clip' ? 'selected' : ''}>Clip · gekoppelde speler en trainers</option><option value="match" ${v.kind === 'match' ? 'selected' : ''}>Volledige wedstrijd · alle spelers van dit team</option>`)}${select('function', 'Teamfunctie', '<option value="">Geen teamfunctie</option>'+data.functions.map(f => `<option ${f === v.function ? 'selected' : ''}>${esc(f)}</option>`).join(''))}${select('task', 'Teamtaakmap (optioneel)', taskOptions(v.task))}${field('category','Extra categorie (optioneel)','text',v.category||'','maxlength="120"')}<p class="hint">Een volledige wedstrijd wordt zichtbaar voor alle spelers van dit team. Clips zonder gekoppelde speler zijn alleen voor trainers en beheerder.</p>`, f => post(`/api/videos/${id}/details`, Object.fromEntries(f)));
  } else if (action === 'moment') {
    const v = data.videos.find(v => v.id === id), second = $('#video-player').currentTime || 0;
    $('#video-player').pause();
    openForm('Videomoment vastleggen', `<input name="video_id" type="hidden" value="${id}">${field('second', 'Tijdstip in seconden', 'number', second.toFixed(1), 'required min="0" step="0.1"')}${select('player_id', 'Speler (optioneel)', '<option value="">Teammoment</option>' + data.players.filter(p => p.team_id === v.team_id).map(p => `<option value="${p.id}" ${v.player_id === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join(''))}${select('label', 'Actie of teamgedrag', ['Pass', 'Duel', 'Schot', 'Interceptie', 'Vrijlopen', 'Drukzetten', 'Opbouwen', 'Omschakelen', 'Overig'].map(label => `<option>${label}</option>`).join(''))}${select('outcome', 'Beoordeling', '<option value="neutraal">Neutraal</option><option value="geslaagd">Geslaagd</option><option value="verbeterpunt">Verbeterpunt</option>')}<label>Feedback<textarea name="note" maxlength="2000"></textarea></label>`, async f => { await post('/api/moments', Object.fromEntries(f)); await refresh(); renderMoments(id); });
  } else if (action === 'seek-moment') { $('#video-player').currentTime = Number(buttonEl.dataset.second); }
  else return false;
  return true;
}
