"""WSGI entry point for HTTPS hosting. No accounts are created on import."""
import os

os.environ.setdefault('TEAM_HTTPS', '1')
# Free/shared hosts may not support persistent background threads.
# On a host with a durable worker, use the documented queue processing command.
os.environ.setdefault('TEAM_ANALYSIS_MODE', 'deferred')

from server import create_app

application = create_app()
