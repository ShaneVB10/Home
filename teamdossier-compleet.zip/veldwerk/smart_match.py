"""Reviewable video-event workflow and manual/live-ready competition data."""
import csv
import io
import os
import time
from datetime import datetime
from urllib.parse import urlsplit

from flask import abort, g, jsonify, request

from permissions import TASKS

FUNCTIONS=('Aanvallen','Verdedigen','Omschakelen naar aanval','Omschakelen naar verdediging')
STATUSES=('voorstel','goedgekeurd','afgewezen')


def register_smart_match(app,db,protect,require,permitted,team_allowed,admin,text):
    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS video_sources(video_id TEXT PRIMARY KEY REFERENCES videos(id),
          provider TEXT NOT NULL,external_url TEXT NOT NULL,external_id TEXT NOT NULL DEFAULT '',created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS analysis_suggestions(id INTEGER PRIMARY KEY,video_id TEXT NOT NULL REFERENCES videos(id),
          player_id INTEGER REFERENCES players(id),shirt_number INTEGER,start_second REAL NOT NULL,end_second REAL NOT NULL,
          label TEXT NOT NULL,task TEXT NOT NULL,function TEXT NOT NULL,confidence REAL,source TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'voorstel',moment_id INTEGER REFERENCES moments(id),created REAL NOT NULL,
          season_id INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS integration_settings(provider TEXT PRIMARY KEY,mode TEXT NOT NULL,
          account_label TEXT NOT NULL DEFAULT '',updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS connections(id INTEGER PRIMARY KEY,name TEXT NOT NULL,kind TEXT NOT NULL,
          purpose TEXT NOT NULL,endpoint TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,
          team_ids TEXT NOT NULL DEFAULT '[]',last_sync TEXT NOT NULL DEFAULT '',last_error TEXT NOT NULL DEFAULT '',
          created REAL NOT NULL,updated REAL NOT NULL);
        ''')
        fixture_columns={r[1] for r in db().execute('PRAGMA table_info(fixtures)')}
        for name,definition in (('status',"TEXT NOT NULL DEFAULT 'gepland'"),('minute','INTEGER'),('updated','REAL NOT NULL DEFAULT 0')):
            if name not in fixture_columns:db().execute(f'ALTER TABLE fixtures ADD COLUMN {name} {definition}')
        db().commit()

    @app.post('/api/integrations/veo')
    @protect
    def configure_veo():
        admin();payload=request.get_json();mode=str(payload.get('mode',''))
        if mode not in ('account','export','api'):abort(400,'Kies normaal VEO-account, export of officiële API.')
        label=text(payload,'account_label',200,False)
        db().execute("INSERT INTO integration_settings(provider,mode,account_label,updated) VALUES ('veo',?,?,?) ON CONFLICT(provider) DO UPDATE SET mode=excluded.mode,account_label=excluded.account_label,updated=excluded.updated",(mode,label,time.time()))
        db().commit();return jsonify(ok=True,api_ready=bool(os.environ.get('TEAM_VEO_API_TOKEN')) if mode=='api' else False)

    @app.post('/api/integrations/veo/delete')
    @protect
    def delete_veo():
        admin();db().execute("DELETE FROM integration_settings WHERE provider='veo'");db().commit();return jsonify(ok=True)

    @app.post('/api/connections')
    @protect
    def save_connection():
        admin();p=request.get_json();key=int(p.get('id') or 0);name=text(p,'name',120);purpose=text(p,'purpose',500,False)
        kind=str(p.get('kind',''))
        if kind not in ('uitslagen','video','e-mail','agenda','opslag','overig'):abort(400,'Kies een geldig soort koppeling.')
        endpoint=str(p.get('endpoint','')).strip()
        if endpoint:
            try:parsed=urlsplit(endpoint)
            except ValueError:parsed=None
            if not parsed or parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or len(endpoint)>2000:
                abort(400,'Gebruik een geldige openbare HTTPS-API-link zonder gebruikersnaam of wachtwoord.')
        active=p.get('active',True)
        if type(active) is not bool:abort(400,'Kies actief of gepauzeerd.')
        team_ids=p.get('team_ids',[])
        known={r[0] for r in db().execute('SELECT id FROM teams')}
        if not isinstance(team_ids,list) or not all(type(i) is int and i in known for i in team_ids):abort(400,'Kies bestaande teams.')
        now=time.time();values=(name,kind,purpose,endpoint,int(active),__import__('json').dumps(sorted(set(team_ids))),now)
        if key:
            if not db().execute('SELECT 1 FROM connections WHERE id=?',(key,)).fetchone():abort(404,'Koppeling niet gevonden.')
            db().execute('UPDATE connections SET name=?,kind=?,purpose=?,endpoint=?,active=?,team_ids=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO connections(name,kind,purpose,endpoint,active,team_ids,created,updated) VALUES (?,?,?,?,?,?,?,?)',(*values,now)).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/connections/<int:key>/test')
    @protect
    def test_connection(key):
        admin();row=db().execute('SELECT * FROM connections WHERE id=?',(key,)).fetchone()
        if not row:abort(404,'Koppeling niet gevonden.')
        if not row['active']:abort(409,'Activeer de koppeling voordat je deze controleert.')
        if not row['endpoint']:return jsonify(ok=True,status='configuratie-gereed',message='Koppeling is vastgelegd; voeg voor automatische synchronisatie de leveranciersadapter toe.')
        return jsonify(ok=True,status='configuratie-gereed',message='HTTPS-adres is geldig. Een leveranciersadapter en API-sleutel zijn nodig voor een echte gegevenscontrole.')

    @app.post('/api/connections/<int:key>/delete')
    @protect
    def delete_connection(key):
        admin();cursor=db().execute('DELETE FROM connections WHERE id=?',(key,))
        if not cursor.rowcount:abort(404,'Koppeling niet gevonden.')
        db().commit();return jsonify(ok=True)

    def video(video_id,write=False):
        require('videos',write)
        row=db().execute('SELECT * FROM videos WHERE id=? AND season_id=?',(video_id,g.season_id)).fetchone()
        if not row:abort(404,'Wedstrijdvideo niet gevonden.')
        if not team_allowed(row['team_id']):abort(403,'Geen toegang tot dit team.')
        return row

    @app.post('/api/smart-analysis/source')
    @protect
    def link_source():
        require('videos',True);payload=request.get_json();row=video(str(payload.get('video_id','')),True)
        raw=str(payload.get('url','')).strip()
        try:parsed=urlsplit(raw)
        except ValueError:parsed=None
        if not parsed or parsed.scheme!='https' or not parsed.hostname or not (parsed.hostname=='veo.co' or parsed.hostname.endswith('.veo.co')):
            abort(400,'Gebruik een geldige HTTPS-wedstrijdlink van VEO.')
        db().execute('INSERT INTO video_sources(video_id,provider,external_url,created) VALUES (?,\'veo\',?,?) ON CONFLICT(video_id) DO UPDATE SET external_url=excluded.external_url,created=excluded.created',(row['id'],raw,time.time()))
        db().commit();return jsonify(ok=True)

    @app.post('/api/smart-analysis/import')
    @protect
    def import_events():
        require('videos',True);row=video(str(request.form.get('video_id','')),True)
        upload=request.files.get('file')
        if not upload or request.content_length and request.content_length>2*1024*1024:abort(400,'Kies een CSV-bestand van maximaal 1 MB.')
        try:
            content=upload.stream.read(1024*1024+1)
            if len(content)>1024*1024:raise ValueError
            reader=csv.DictReader(io.StringIO(content.decode('utf-8-sig')),delimiter=';')
            required={'start','eind','rugnummer','actie','teamtaak','teamfunctie','betrouwbaarheid'}
            if not reader.fieldnames or not required.issubset({h.strip().lower() for h in reader.fieldnames}):raise ValueError
            records=[]
            for item in reader:
                item={str(k).strip().lower():str(v or '').strip() for k,v in item.items()}
                start=float(item['start'].replace(',','.'));end=float(item['eind'].replace(',','.'))
                if start<0 or end<=start or end-start>180:raise ValueError
                number=int(item['rugnummer']) if item['rugnummer'] else None
                player_id=None
                if number is not None:
                    player=db().execute('SELECT player_id FROM season_players WHERE season_id=? AND team_id=? AND shirt_number=?',(g.season_id,row['team_id'],number)).fetchone()
                    player_id=player['player_id'] if player else None
                task=item['teamtaak'];function=item['teamfunctie']
                if task and task not in TASKS:raise ValueError
                if function and function not in FUNCTIONS:raise ValueError
                confidence=float(item['betrouwbaarheid'].replace(',','.')) if item['betrouwbaarheid'] else None
                if confidence is not None and not 0<=confidence<=100:raise ValueError
                label=item['actie'][:200]
                if not label:raise ValueError
                records.append((row['id'],player_id,number,start,end,label,task,function,confidence,'VEO-export',time.time(),g.season_id))
            if not records or len(records)>5000:raise ValueError
        except (UnicodeError,ValueError,TypeError):abort(400,'CSV niet herkend. Gebruik de getoonde kolommen en geldige tijden/categorieën.')
        db().executemany('INSERT INTO analysis_suggestions(video_id,player_id,shirt_number,start_second,end_second,label,task,function,confidence,source,created,season_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',records)
        db().commit();return jsonify(ok=True,count=len(records),unmatched=sum(r[1] is None and r[2] is not None for r in records))

    @app.post('/api/smart-analysis/suggestions/<int:key>')
    @protect
    def review_suggestion(key):
        require('videos',True);suggestion=db().execute('SELECT * FROM analysis_suggestions WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not suggestion:abort(404,'Analysevoorstel niet gevonden.')
        video(suggestion['video_id'],True);status=str(request.get_json().get('status',''))
        if status not in ('goedgekeurd','afgewezen'):abort(400,'Kies goedkeuren of afwijzen.')
        moment_id=suggestion['moment_id']
        if status=='goedgekeurd' and not moment_id:
            moment_id=db().execute('INSERT INTO moments(video_id,player_id,user_id,second,label,outcome,note,created) VALUES (?,?,?,?,?,?,?,?)',
              (suggestion['video_id'],suggestion['player_id'],g.user['id'],suggestion['start_second'],suggestion['label'],'neutraal',f"{suggestion['task']} · {suggestion['function']} · bron {suggestion['source']}",time.time())).lastrowid
        db().execute('UPDATE analysis_suggestions SET status=?,moment_id=? WHERE id=?',(status,moment_id,key));db().commit()
        return jsonify(ok=True,moment_id=moment_id)

    @app.post('/api/matches/manual')
    @protect
    def manual_match():
        require('matches',True);p=request.get_json();team_id=int(p.get('team_id') or 0)
        if not team_allowed(team_id) or not db().execute('SELECT 1 FROM teams WHERE id=?',(team_id,)).fetchone():abort(403,'Geen toegang tot dit team.')
        date=text(p,'date',16);home=text(p,'home');away=text(p,'away')
        try:datetime.fromisoformat(date)
        except ValueError:abort(400,'Kies een geldige datum en tijd.')
        status=str(p.get('status','gepland'))
        if status not in ('gepland','live','rust','afgelopen','uitgesteld','afgelast'):abort(400,'Kies een geldige wedstrijdstatus.')
        def score(name):
            value=p.get(name)
            if value in (None,''):return None
            value=int(value)
            if not 0<=value<=99:abort(400,'Gebruik een score tussen 0 en 99.')
            return value
        home_score,away_score=score('score_home'),score('score_away')
        minute=int(p['minute']) if p.get('minute') not in (None,'') else None
        if minute is not None and not 0<=minute<=150:abort(400,'Gebruik een minuut tussen 0 en 150.')
        key=int(p.get('id') or 0)
        values=(team_id,date,home,away,home_score,away_score,'Handmatig',status,minute,time.time(),g.season_id)
        if key:
            old=db().execute('SELECT * FROM fixtures WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
            if not old:abort(404,'Wedstrijd niet gevonden.')
            if not team_allowed(old['team_id']):abort(403,'Geen toegang tot dit team.')
            db().execute('UPDATE fixtures SET team_id=?,date=?,home=?,away=?,score_home=?,score_away=?,source=?,status=?,minute=?,updated=?,season_id=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO fixtures(team_id,date,home,away,score_home,score_away,source,status,minute,updated,season_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)',values).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    def summary():
        suggestions=[];sources=[]
        if permitted('videos') and g.user['role']!='player':
            allowed={r['id'] for r in db().execute('SELECT * FROM videos WHERE season_id=?',(g.season_id,)) if team_allowed(r['team_id'])}
            suggestions=[dict(r) for r in db().execute('SELECT * FROM analysis_suggestions WHERE season_id=? ORDER BY created DESC,id DESC',(g.season_id,)) if r['video_id'] in allowed]
            sources=[dict(r) for r in db().execute('SELECT * FROM video_sources') if r['video_id'] in allowed]
        provider=os.environ.get('TEAM_SCORES_PROVIDER','').strip();veo=db().execute("SELECT * FROM integration_settings WHERE provider='veo'").fetchone()
        veo_state=dict(veo) if veo else {'mode':'account','account_label':'','updated':0}
        veo_state.update(api_ready=bool(os.environ.get('TEAM_VEO_API_TOKEN')),login_url='https://app.veo.co/')
        connections=[]
        if g.user['role']=='admin':
            import json
            connections=[dict(r) for r in db().execute('SELECT * FROM connections ORDER BY active DESC,name')]
            for item in connections:item['team_ids']=json.loads(item['team_ids'])
        return dict(analysis_suggestions=suggestions,video_sources=sources,veo_integration=veo_state,connections=connections,score_integration={
          'connected':bool(provider),'provider':provider or 'Nog niet gekozen','last_sync':os.environ.get('TEAM_SCORES_LAST_SYNC',''),
          'message':'Automatische synchronisatie beschikbaar zodra de officiële leverancier en API-sleutel zijn ingesteld.'})

    return summary
