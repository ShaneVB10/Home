# Productie-installatie op een Nederlandse VPS

Dit document is bedoeld voor een systeembeheerder. Gebruik Ubuntu LTS, een afzonderlijke Linux-gebruiker `teamdossier`, firewallregels voor uitsluitend SSH/HTTP/HTTPS en automatische beveiligingsupdates.

1. Plaats de applicatie in `/opt/teamdossier/app` en maak een virtualenv in `/opt/teamdossier/venv`.
2. Installeer `requirements.txt`, Nginx, FFmpeg en FFprobe.
3. Maak `/var/lib/teamdossier/platform`, `/var/lib/teamdossier/tenants`, `/var/log/teamdossier` en een externe/gemounte `/var/backups/teamdossier`, eigendom van de servicegebruiker en niet leesbaar voor andere gebruikers.
4. Kopieer `teamdossier.env.example` naar `/etc/teamdossier.env`, zet eigenaar op `root:teamdossier` en rechten op `0640`, en vul alle secrets en contractgegevens in. Bewaar `TEAM_BACKUP_KEY` ook buiten de VPS in een wachtwoordkluis. Voer met deze omgevingsvariabelen `python deployment_check.py` uit; de service weigert te starten zolang verplichte productievelden ontbreken.
5. Maak de platformbeheerder met `saas.py create-platform-admin`.
6. Configureer bij de DNS-provider een `A`-record voor `@` en een wildcard `A`-record voor `*`, beide naar het publieke IPv4-adres van de VPS. Voeg bij IPv6 ook overeenkomstige `AAAA`-records toe. `www` valt onder de wildcard of kan als afzonderlijke CNAME naar `@`. Controleer met `dig +short teamdossier.nl` en `dig +short test.teamdossier.nl`.
7. Vraag via de officiële Certbot DNS-plugin van de DNS-provider een certificaat aan met `certbot certonly --dns-<provider> -d teamdossier.nl -d '*.teamdossier.nl'`. Een wildcard-certificaat kan niet met de gewone HTTP-challenge worden uitgegeven. Gebruik een beperkt DNS-API-token, bewaar het bestand als `0600`, voer `certbot renew --dry-run` uit en laat Nginx na vernieuwing herladen. Vul `<provider>` pas in nadat de DNS-provider is gekozen.
8. Installeer de Nginx- en systemd-bestanden. Test eerst `nginx -t`, start daarna de app en de back-uptimer.
9. Controleer HTTPS, HSTS, een testklant, blokkeren/activeren, auditlogs, bestandsrechten en een hersteltest naar een nieuwe map.
10. Kopieer versleutelde `.tdbk`-bestanden automatisch naar een tweede leverancier of opslaglocatie met versiebeheer/retentie. Een back-up op alleen dezelfde VPS beschermt niet tegen verlies van de VPS.

## Verplichte gegevens vóór livegang

Vul in `/etc/teamdossier.env` het correspondentieadres en privacy-e-mailadres in, plus de productiehost, hostinglocatie, externe back-uppartij en locatie, e-mail- en betaalprovider (of “niet van toepassing”) en de termijnen voor accounts, medische dossiers, foto’s/video’s en back-ups. `TEAM_LEGAL_NAME` is de leverancier van Teamdossier; de afzonderlijke voetbalvereniging wordt per klantomgeving als verwerkingsverantwoordelijke getoond. Een KvK-nummer is niet vereist door deze applicatie.

Maak de gekozen termijnen onderdeel van het contract en van werkelijk uitgevoerde verwijderprocessen. De timer ruimt lokale versleutelde `.tdbk`-bestanden op volgens `TEAM_BACKUP_RETENTION_DAYS`; stel dezelfde of een aantoonbaar passende retentie in bij de externe opslagleverancier. Plan minimaal elk kwartaal een hersteltest naar een nieuwe map.

## Oplevercontrole

- `systemctl status teamdossier` en `systemctl status teamdossier-backup.timer` zijn actief.
- `curl -I https://teamdossier.nl` en een testsubdomein leveren HTTPS en HSTS.
- Een tweede willekeurig subdomein komt niet in de testklantomgeving terecht.
- Een testklant kan inloggen; blokkeren in platformbeheer maakt het subdomein direct onbereikbaar.
- Een gemaakte `.tdbk` doorstaat `saas_backup.py verify` en kan naar een nieuwe map worden hersteld.
- Privacy- en verwerkerspagina bevatten nergens `Vul` of blokhaken.
- Verwerkingsovereenkomsten met hosting-, back-up-, e-mail- en betaalproviders zijn opgeslagen.
- De conceptteksten zijn door een AVG-jurist gecontroleerd voordat verkoop start.

Een bestaande enkele Teamdossier-installatie wordt niet automatisch als klant geïmporteerd. Maak een doelomgeving, stop schrijfacties, maak een volledige back-up, herstel naar de nieuwe klantmap en valideer accounts, bestanden en seizoenen voordat DNS wordt omgezet.

De meegeleverde privacyverklaring en verwerkersovereenkomst zijn concepten. Vul leveranciers, locaties, termijnen, contactgegevens en contractafspraken in en laat ze juridisch controleren vóór commerciële ingebruikname.
