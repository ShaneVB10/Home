"""Original club-wide curriculum: 50 distinct exercises tailored to 13 age groups."""
import json
import time

AGES={
 'O8':('10–14 spelers','12 min','18×14 m','2v2/3v3','ontdekken, veel balcontacten en korte uitleg'),
 'O9':('10–14 spelers','12 min','20×15 m','3v3/4v4','herhalen met eenvoudige keuzes en beide voeten'),
 'O10':('10–16 spelers','14 min','22×16 m','4v4','kijken vóór de actie en techniek onder lichte druk'),
 'O11':('10–16 spelers','15 min','24×18 m','4v4/5v5','herkennen van ruimte, samenspelen en direct omschakelen'),
 'O12':('12–16 spelers','16 min','26×20 m','5v5/6v6','handelingssnelheid en keuzes met weerstand'),
 'O13':('12–18 spelers','18 min','30×22 m','6v6','principes per teamtaak en samenwerken in linies'),
 'O14':('12–18 spelers','18 min','32×24 m','6v6/7v7','positie kiezen ten opzichte van bal, medespeler en tegenstander'),
 'O15':('14–20 spelers','20 min','36×28 m','7v7/8v8','tempo, onderlinge coaching en herkennen van wedstrijdsignalen'),
 'O16':('14–20 spelers','20 min','40×30 m','8v8','uitvoeren onder hoge druk en verantwoordelijkheid per positie'),
 'O17':('14–22 spelers','22 min','44×34 m','8v8/9v9','wedstrijdrealistische afstanden, timing en samenwerking tussen linies'),
 'O18':('14–22 spelers','22 min','48×36 m','9v9','hoog tempo, tactische details en keuzes vanuit het wedstrijdplan'),
 'O19':('16–22 spelers','24 min','52×40 m','9v9/10v10','intensiteit, rolvastheid en collectieve wedstrijdprincipes'),
 'O23':('16–24 spelers','25 min','55×42 m','10v10/11v11','seniorentempo, rendement en zelfstandig oplossen van wedstrijdproblemen'),
}

# titel, teamtaak, thema, doel, organisatie, coachaccent
FORMS=(
 ('Poortjesdribbel','Opbouwen','Techniek','Bal beheersen en gericht van richting veranderen','Verspreid gekleurde poortjes; iedere speler heeft een bal en scoort door gecontroleerd door een vrij poortje te dribbelen','Kleine balcontacten, hoofd omhoog en versnellen na het poortje'),
 ('Binnen-buitenkant-circuit','Opbouwen','Techniek','Beide voeten functioneel gebruiken tijdens het dribbelen','Maak vier korte techniekstroken met pionnen, een keerpunt en een pass naar de volgende speler','Raak de bal met verschillende voetdelen en houd het bovenlichaam in balans'),
 ('Kappen en wegdraaien','Opbouwen','Techniek','Onder druk loskomen met een kap- of draaibeweging','Spelers dribbelen naar een verdediger of pion, voeren een afgesproken beweging uit en spelen door','Zet de steunvoet goed, scherm de bal af en versnel uit de beweging'),
 ('Open eerste aanname','Opbouwen','Balvaardigheid','Met de eerste aanname vooruit of uit de druk spelen','Drietallen in driehoeken passen door; na iedere pass opent de ontvanger naar een volgend station','Kijk vóór ontvangst, sta halfopen en neem mee naar de vrije kant'),
 ('Balgevoel-challenge','Opbouwen','Balvaardigheid','Coördinatie en vertrouwen aan de bal vergroten','Werk in korte rondes met jongleren, voet op de bal, zoolrollen en gecontroleerde combinaties','Kwaliteit boven snelheid, beide benen en persoonlijke haalbare uitdaging'),
 ('Passpoortjes in duo’s','Opbouwen','Passing','Zuiver passen en de juiste afstand tot een medespeler houden','Duo’s bewegen door een vak en verdienen een punt voor iedere pass door een vrij poortje','Standbeen naast de bal, pass op het juiste been en na de pass direct vrijlopen'),
 ('Kaatsen uit de dekking','Opbouwen','Samenspel','Een kaats gebruiken om druk te omspelen','Een centrale speler komt los van een passieve of actieve verdediger, kaatst en draait door naar een nieuw vak','Kom op het juiste moment, speel strak in en kaats met richting'),
 ('Zwakke-been-route','Opbouwen','Techniek','Het minder sterke been functioneel inzetten','Circuit met aannemen, dribbelen, passen en afronden waarbij het minder sterke been verplicht is','Rust in de uitvoering, juiste lichaamshouding en fouten gebruiken om opnieuw te proberen'),
 ('Draaien en doorspelen','Opbouwen','Oriëntatie','Na een vooractie opendraaien en een nieuwe lijn vinden','Vier spelers vormen een ruit; de middenontvanger kiest kaatsen of opendraaien afhankelijk van een kleur- of coachsignaal','Scan beide schouders en laat de eerste aanname de volgende handeling voorbereiden'),
 ('Dribbelestafette met keuze','Omschakelen A-V','Snelheid','Op snelheid balcontrole houden en beslissen','Twee routes eindigen in een kleurkeuze, pass of schot; de trainer wisselt het signaal vlak vóór het keuzepunt','Versnel met controle, kijk tijdens de dribbel en rem technisch af'),
 ('Rondo 3 tegen 1','Opbouwen','Positiespel','Een overtal benutten met goede steunhoeken','Drie aanvallers houden balbezit rond één verdediger; wissel na onderschepping of een vastgesteld aantal acties','Maak het veld groot, speel op het verre been en reageer direct na balverlies'),
 ('Rondo 4 tegen 2','Opbouwen','Positiespel','Onder gezamenlijke druk een vrije speler vinden','Vier spelers buiten en twee verdedigers binnen; punten voor een pass tussen de verdedigers','Voorinformatie, juiste balsnelheid en de derde man herkennen'),
 ('Positierondo met middenman','Opbouwen','Positiespel','Via een speler tussen de linies van kant wisselen','Twee buitenvakken met een verbindende middenzone; balbezit scoort via de middenman naar de overzijde','Middenman uit de dekkingsschaduw, open staan en niet te vroeg in de bal komen'),
 ('Eindzone-balbezit','Kansen creëren','Positiespel','Balbezit omzetten in diepte en terreinwinst','Twee teams scoren door een medespeler gecontroleerd in de eindzone aan te spelen','Breedte houden, lokken en op het juiste moment achter de laatste lijn komen'),
 ('Neutrale spelers benutten','Kansen creëren','Overtal','Met neutrale spelers snel een overtal uitspelen','Twee teams spelen balbezit met één of twee neutralen die altijd bij de balbezittende partij horen','Vooruit spelen wanneer het kan en na de pass een nieuwe steunpositie kiezen'),
 ('Vijf passes en doorbreken','Kansen creëren','Balbezit','Geduldig balbezit afwisselen met een versnelling vooruit','Na vijf opeenvolgende passes mag een team scoren in één van twee doelen of eindzones','Niet tellen zonder bedoeling; herken wanneer de tegenstander uit positie is'),
 ('Ruitcirculatie onder druk','Opbouwen','Opbouw','In een ruit de vrije man en juiste speelrichting vinden','Ruit tegen actieve verdedigers met een doelspeler aan beide zijden; iedere succesvolle doorgang levert een punt op','Diepte en breedte tegelijk, passlijn openen en doordekken na balverlies'),
 ('Derde-man-combinatie','Kansen creëren','Samenspel','Een tegenstander passeren via de derde speler','Werk in zones met A speelt B, B kaatst op C, waarna vrije voortzetting naar doel of eindzone volgt','Timing van C, kaats uit de druk en versnellen zodra de lijn is gebroken'),
 ('Spel verplaatsen','Opbouwen','Opbouw','Druk lokken en via de vrije kant verder spelen','Twee zijvakken en een middenzone; een aanval telt wanneer beide buitenzones in dezelfde aanval worden gebruikt','Circuleren met tempo, verste speler blijft breed en omschakelen bij een slechte pass'),
 ('Opbouwen vanaf de keeper','Opbouwen','Opbouw','Herkenbare oplossingen vinden voor de eerste opbouwfase','Start iedere aanval bij de keeper tegen een passende eerste druklijn en speel naar een doelzone over de middenlijn','Veld groot maken, centrale en buitenste oplossing tegelijk aanbieden en keeper laten coachen'),
 ('Twee tegen één naar doel','Kansen creëren','Aanvallen','Een overtal met tempo en juiste timing uitspelen','Aanvallers starten naast elkaar tegen één verdediger en ronden binnen beperkte tijd af','Balbezitter bindt de verdediger, medespeler blijft uit de lijn en laatste pass komt op tijd'),
 ('Drie tegen twee-golf','Kansen creëren','Aanvallen','Snel kiezen tussen combinatie, dribbel en schot','Na iedere aanval start vanuit de andere kant direct een nieuwe 3-tegen-2-situatie','Eerste blik vooruit, looplijnen uit elkaar en aanval met een doelpoging beëindigen'),
 ('Voorzet en bezetting','Kansen creëren','Afwerken','Voorzet, teruggetrokken bal en bezetting voor het doel afstemmen','Aanval via een flankstation; spelers bezetten eerste paal, tweede paal en zone rond de strafschopstip','Kijk vóór de voorzet, arriveer in plaats van wachten en kies gericht afwerkvlak'),
 ('Cutback-afwerking','Kansen creëren','Afwerken','Teruggetrokken voorzetten vanuit de achterlijn benutten','Buitenspeler bereikt de achterlijn en speelt terug naar verschillende aankomende zones','Niet te vroeg inlopen, open lichaam en afronden uit de loop'),
 ('Kaats en afronden','Kansen creëren','Afwerken','Via een korte combinatie ruimte voor een schot maken','Inspelen op een aanspeelpunt, kaats om een pion of verdediger en afronden op doel','Strakke inspeelpass, kaats in de loop en snel schieten zonder extra balcontact'),
 ('Wegdraaien en schieten','Kansen creëren','Afwerken','Met rug naar doel loskomen en afronden','Spits ontvangt met een verdediger in de rug, kiest links of rechts wegdraaien en werkt af','Voel de druk, eerste contact uit de voeten en lichaam tussen bal en verdediger'),
 ('Tweede-bal-afwerking','Kansen creëren','Afwerken','Alert reageren op rebounds en afvallende ballen','Trainer of keeper brengt wisselende rebounds; aanvallers en verdedigers strijden om de tweede bal','Startpositie op scherp, reageer vooruit en blijf beheerst in de afronding'),
 ('Kleine doelen kiezen','Kansen creëren','Beslissen','Hoofd omhoog houden en de vrije scoringsrichting kiezen','Partijvorm met meerdere kleine doelen; een doel wordt tijdelijk gesloten na een score','Scan vóór ontvangst, lok naar één kant en verplaats naar het vrije doel'),
 ('Strafschopgebied aanvallen','Kansen creëren','Aanvallen','Loopacties en restverdediging bij een aanval organiseren','Aanvallend team brengt de bal vanuit een opbouwzone naar een afgebakend scoringsvak met doelen','Bezet verschillende hoogtes, één speler onder de bal en voorkom allemaal naar de bal lopen'),
 ('Vijf-seconden-aanval','Omschakelen V-A','Omschakelen','Na balwinst onmiddellijk doelgericht worden','Na iedere verovering heeft het team vijf seconden voor een doelpoging; daarna blijft doorspelen mogelijk zonder bonus','Eerste actie vooruit, diepste speler direct vertrekken en overige spelers aansluiten'),
 ('Eén-tegen-één-verdedigen','Kansen voorkomen','Verdedigen','Een aanvaller vertragen en naar een ongunstige kant sturen','Smalle kanalen met aanvaller, verdediger en scoringslijn of klein doel','Snel naderen, op tijd afremmen, zijwaartse houding en kijk naar bal en heup'),
 ('Twee tegen twee vertragen','Kansen voorkomen','Verdedigen','Samen de as beschermen en tijd winnen','Twee aanvallers proberen een eindlijn of doel te bereiken tegen twee verdedigers','Dichtstbijzijnde zet druk, tweede geeft rugdekking en onderling blijven praten'),
 ('Druksignaal herkennen','Opbouw verstoren','Pressing','Collectief drukzetten op een afgesproken signaal','Opbouwend team start steeds achterin; verdedigend team scoort bonus na balwinst op slechte aanname, terugspeelbal of pass naar de zijlijn','Eerste speler start, rest sluit door en voorkom een vrije speler achter de druk'),
 ('Compact blok verschuiven','Kansen voorkomen','Organisatie','Afstanden tussen spelers en linies bewaken','Aanvallers verplaatsen de bal tussen zones; verdedigers verdienen punten door als compact blok mee te schuiven en te onderscheppen','Balzijde insluiten, verre kant knijpt en onderlinge afstand blijft klein'),
 ('Rugdekking en balans','Kansen voorkomen','Verdedigen','Druk, rugdekking en balans gelijktijdig organiseren','Drie verdedigers beschermen twee doelen tegen drie aanvallers met een neutrale speler','Wie stapt door, wie dekt en wie bewaakt de zwakke kant; voortdurend informatie geven'),
 ('Voorzet verdedigen','Kansen voorkomen','Verdedigen','Voorzetten en bezetting voor het doel verdedigen','Aanval via de flank met voorzet; verdedigers bewaken zones, tegenstanders en tweede bal','Open staan naar bal en tegenstander, eerst gevaarlijke ruimte en na wegwerken aansluiten'),
 ('Strafschopgebied beschermen','Kansen voorkomen','Organisatie','Schoten blokkeren en centrale ruimte gesloten houden','Aanvallers combineren rond een scoringszone; verdedigers mogen pas op afgesproken momenten uitstappen','As gesloten, lichaam in schotlijn en geen onnodige overtreding'),
 ('Opbouw hoog verstoren','Opbouw verstoren','Pressing','Tegenstander naar een gekozen kant dwingen en daar veroveren','Keeper en opbouwers spelen tegen een hoge drukploeg; balwinst levert een korte aanval op groot doel op','Looplijn schermt centrum af, achterste spelers sluiten aan en druk wordt niet alleen uitgevoerd'),
 ('Tegendruk in vak','Omschakelen A-V','Omschakelen','Direct na balverlies samen het speelveld verkleinen','Balbezit in een vak; na verlies heeft het oude balbezitteam enkele seconden om terug te winnen','Dichtstbijzijnde reageert, anderen sluiten passlijnen en na mislukte tegendruk terug in organisatie'),
 ('Omschakelen naar organisatie','Omschakelen A-V','Omschakelen','Na balverlies snel doel, as en directe tegenstander beschermen','Aanval eindigt bewust met balverlies waarna tegenpartij naar een eindzone of doel countert','Eerste meters voluit terug, vertraag de bal en verdeel onderweg de tegenstanders'),
 ('Vierdoelenspel','Omschakelen V-A','Partijvorm','Na balwinst snel van speelrichting veranderen','Partijvorm met twee kleine doelen per team aan tegenoverliggende zijden','Hoofd omhoog na verovering, vrije doel herkennen en veld direct breed maken'),
 ('Lijnvoetbal','Kansen creëren','Partijvorm','Met combinatie en loopactie achter de laatste lijn komen','Teams scoren door de bal gecontroleerd over een eindlijn naar een medespeler te spelen','Niet op de lijn wachten, ruimte vrijmaken en loopactie op het passmoment'),
 ('Nummerspel','Omschakelen V-A','Reactie','Snel schakelen in wisselende overtal- en ondertalsituaties','Spelers hebben nummers; trainer roept combinaties die direct een korte wedstrijd spelen','Snel het aantal herkennen, eerste actie doelgericht en samen verdedigen'),
 ('Overtal wisselspel','Kansen creëren','Partijvorm','Een tijdelijk overtal herkennen en uitspelen','Neutrale spelers of instromers creëren steeds een wisselend overtal voor het team in balbezit','Vrije speler zoeken, tegenstander binden en tempo verhogen zodra het overtal zichtbaar is'),
 ('Buitenzones benutten','Kansen creëren','Partijvorm','Breedte gebruiken om centrale ruimte te openen','Partijvorm met buitenzones die alleen door aanvallers of neutrale spelers gebruikt worden','Niet automatisch naar buiten; eerst lokken, juiste moment kiezen en bezetting voor doel regelen'),
 ('Middenpoort doorbreken','Opbouwen','Partijvorm','Via de as of halfspace een lijn doorbreken','Plaats poorten in de middenzone; doorspelen of indribbelen door een poort levert bonus op','Speler tussen linies vrijmaken, pass met juiste snelheid en na doorbraak aansluiten'),
 ('Winnaarsveld','Omschakelen V-A','Competitie','Veel korte wedstrijden met hoge betrokkenheid spelen','Meerdere kleine velden; winnaar schuift door, andere ploeg wisselt of krijgt een nieuwe opdracht','Snel hervatten, sportief gedrag en elke nieuwe wedstrijd direct scherp starten'),
 ('Voorwaardenspel wedstrijdvorm','Opbouwen','Wedstrijdvorm','Teamprincipes toepassen in een herkenbare wedstrijdvorm','Speel de leeftijdseigen wedstrijdvorm met één gerichte bonusregel die past bij het trainingsdoel','Coach vooral tijdens natuurlijke onderbrekingen en bewaak dat de regel het echte spel ondersteunt'),
 ('Wedstrijdfasen trainen','Omschakelen A-V','Wedstrijdvorm','Verschillende momenten uit een wedstrijdplan herkennen','Start herhaald vanuit opbouw, hoge balwinst, ingooi of omschakeling en speel daarna vrij door','Iedere start heeft een duidelijk probleem; spelers benoemen na afloop hun keuze'),
 ('Spelhervattingen-carrousel','Kansen creëren','Spelhervatting','Aanvallende en verdedigende afspraken bij spelhervattingen uitvoeren','Stations voor hoekschop, vrije trap, ingooi en hervatting van de keeper; roteer na enkele herhalingen','Duidelijke rollen, startsein, tweede bal en directe organisatie na balverlies'),
)


def seed_catalog(connection):
    now=time.time();rows=[]
    for age,(players,minutes,area,match_format,focus) in AGES.items():
        for index,(title,category,theme,goal,setup,coaching) in enumerate(FORMS,1):
            key=f'club-v1-{age.lower()}-{index:02d}'
            description=f'{goal}. Leeftijdsaccent {age}: {focus}.'
            organization=f'{setup}. Richtmaat: {area}; werk met {players}. Schaal naar {match_format} en het aanwezige aantal.'
            coach=f'{coaching}. Doseer weerstand en ruimte zodat spelers van {age} veel succesvolle én uitdagende acties krijgen.'
            # A deterministic field picture gives every built-in exercise a useful visual starting point.
            count=max(4,min(14,int(''.join(c for c in players if c.isdigit())[:2] or 8)))
            items=[]
            for n in range(count):
                items.append({'type':'player-red' if n%2==0 else 'player-blue','x':15+(n%5)*17,'y':18+(n//5)*28})
            items.extend([{'type':'ball','x':48,'y':50},{'type':'cone','x':10,'y':10},{'type':'cone','x':90,'y':10},{'type':'cone','x':10,'y':90},{'type':'cone','x':90,'y':90}])
            if theme in ('Afwerken','Aanvallen','Spelhervatting'):items.extend([{'type':'goal','x':95,'y':50},{'type':'pass','x':48,'y':50,'x2':78,'y2':50}])
            elif 'Omschakelen' in category:items.append({'type':'run','x':35,'y':50,'x2':75,'y2':30})
            else:items.append({'type':'pass','x':32,'y':45,'x2':66,'y2':55})
            diagram=json.dumps({'field':'full','items':items},separators=(',',':'))
            rows.append((f'{index:02d}. {title} · {age}',category,description,organization,coach,int(minutes.split()[0]),players,'',theme,age,None,now,key,diagram))
    connection.executemany('''INSERT OR IGNORE INTO exercises
      (title,category,description,setup,coaching,minutes,players,url,theme,age_group,team_id,created,builtin_key,diagram)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',rows)
    connection.executemany("UPDATE exercises SET diagram=? WHERE builtin_key=? AND diagram=''",[(r[-1],r[-2]) for r in rows])
    return len(rows)
