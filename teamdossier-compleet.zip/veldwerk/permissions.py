"""Module permissions narrow role defaults; player privacy rules remain separate."""
import json

MODULES = ('teams', 'players', 'videos', 'analysis', 'exercises', 'presentations', 'matches',
           'training', 'availability', 'selections', 'plans', 'reports', 'staff', 'medical')
TASKS = ('Opbouwen', 'Kansen creëren', 'Opbouw verstoren', 'Kansen voorkomen', 'Omschakelen V-A', 'Omschakelen A-V')


def role_modules(role):
    if role == 'admin':
        return {m: 'write' for m in MODULES}
    if role == 'trainer':
        return {m: ('read' if m in ('teams', 'analysis', 'matches', 'reports') else 'write') for m in MODULES}
    return {m: ('none' if m in ('staff','medical') else 'write' if m == 'availability' else 'read') for m in MODULES}


def resolve(user):
    base = role_modules(user['role'])
    custom = user['permissions'] if 'permissions' in user.keys() else ''
    if user['role'] != 'admin' and not custom:
        base['medical'] = 'none'
    if user['role'] == 'admin' or not custom:
        return {'modules': base, 'all_teams': True, 'team_ids': []}
    custom = json.loads(custom)
    rank = {'none': 0, 'read': 1, 'write': 2}
    modules = {m: min((base[m], custom['modules'].get(m, 'none')), key=rank.get) for m in MODULES}
    return {'modules': modules, 'all_teams': custom['all_teams'], 'team_ids': custom['team_ids']}


def validate(value, role, team_ids):
    if not isinstance(value, dict) or not isinstance(value.get('modules'), dict):
        raise ValueError('Kies toegangsrechten per onderdeel.')
    if set(value['modules']) - set(MODULES):
        raise ValueError('Onbekend onderdeel in toegangsrechten.')
    base = role_modules(role)
    rank = {'none': 0, 'read': 1, 'write': 2}
    for module, level in value['modules'].items():
        if level not in rank or rank[level] > rank[base[module]]:
            raise ValueError('Deze rechten passen niet bij de gekozen rol.')
    selected = value.get('team_ids', [])
    if not isinstance(selected, list) or not all(type(i) is int and i in team_ids for i in selected):
        raise ValueError('Kies bestaande teams.')
    if type(value.get('all_teams')) is not bool:
        raise ValueError('Kies alle teams of specifieke teams.')
    return json.dumps({'modules': {m:value['modules'].get(m,'none') for m in MODULES}, 'all_teams':value['all_teams'], 'team_ids':sorted(set(selected))})
