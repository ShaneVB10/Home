"""Fail-fast production configuration check; prints no secret values."""
import os
import sys

REQUIRED={
    'TEAM_BASE_DOMAIN':'publiek hoofddomein',
    'TEAM_PLATFORM_DATA':'platformdatamap',
    'TEAM_TENANT_ROOT':'klantdatamap',
    'TEAM_PLATFORM_SECRET':'platformsessiesleutel',
    'TEAM_AUDIT_KEY':'auditlogsleutel',
    'TEAM_BACKUP_KEY':'back-upsleutel',
    'TEAM_LEGAL_NAME':'naam van de softwareleverancier',
    'TEAM_LEGAL_ADDRESS':'correspondentieadres',
    'TEAM_PRIVACY_EMAIL':'privacy-e-mailadres',
    'TEAM_HOSTING_PROVIDER':'hostingleverancier',
    'TEAM_HOSTING_LOCATION':'hostinglocatie',
    'TEAM_BACKUP_PROVIDER':'externe back-upleverancier',
    'TEAM_BACKUP_LOCATION':'back-uplocatie',
    'TEAM_EMAIL_PROVIDER':'e-mailleverancier of niet van toepassing',
    'TEAM_PAYMENT_PROVIDER':'betaalleverancier of niet van toepassing',
    'TEAM_ACCOUNT_RETENTION':'bewaartermijn na einde abonnement',
    'TEAM_MEDICAL_RETENTION':'bewaartermijn medische gegevens',
    'TEAM_MEDIA_RETENTION':'bewaartermijn beeldmateriaal',
    'TEAM_BACKUP_RETENTION':'leesbare back-uptermijn',
    'TEAM_BACKUP_RETENTION_DAYS':'back-uptermijn in dagen',
}
PLACEHOLDERS=('VUL_','[Vul','CHANGE','voorbeeld')


def validate(environment=None):
    environment=os.environ if environment is None else environment
    problems=[]
    for name,description in REQUIRED.items():
        value=environment.get(name,'').strip()
        if not value or any(marker.lower() in value.lower() for marker in PLACEHOLDERS):
            problems.append(f'{name}: {description} ontbreekt')
    for name in ('TEAM_HTTPS','TEAM_ENFORCE_HTTPS','TEAM_TRUST_PROXY'):
        if environment.get(name)!='1':problems.append(f'{name}: moet in productie 1 zijn')
    try:
        if int(environment.get('TEAM_BACKUP_RETENTION_DAYS','0'))<1:raise ValueError
    except ValueError:problems.append('TEAM_BACKUP_RETENTION_DAYS: gebruik een positief geheel getal')
    return problems


if __name__=='__main__':
    errors=validate()
    if errors:
        print('Productiecontrole mislukt:')
        for error in errors:print(f'- {error}')
        raise SystemExit(1)
    print('Productieconfiguratie bevat alle verplichte velden. Secrets zijn niet weergegeven.')
