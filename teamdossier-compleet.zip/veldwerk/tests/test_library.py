import io
import sqlite3
import tempfile
import unittest
import zipfile
from pathlib import Path

import test_server as fixtures
from permissions import MODULES, TASKS, role_modules
from maintenance import backup


class LibraryTests(unittest.TestCase):
    setUpClass = classmethod(fixtures.TeamTests.setUpClass.__func__)
    tearDownClass = classmethod(fixtures.TeamTests.tearDownClass.__func__)
    setUp = fixtures.TeamTests.setUp
    tearDown = fixtures.TeamTests.tearDown
    login = fixtures.TeamTests.login
    post = fixtures.TeamTests.post
    seed_video = fixtures.TeamTests.seed_video

    def restricted(self, modules=None, teams=(1,)):
        self.login()
        coach = next(u for u in self.client.get('/api/users').json if u['username']=='coach')
        policy = {'modules':{m:'none' for m in MODULES},'all_teams':False,'team_ids':list(teams)}
        policy['modules'].update(modules or {})
        response = self.post(f"/api/users/{coach['id']}/manage",{'permissions':policy})
        self.assertEqual(response.status_code,200,response.json)
        self.login('coach')

    def presentation(self, team=1, **extra):
        fields={'title':'Voorbespreking','team_id':str(team),'match_date':'2026-11-14','opponent':'Testclub','note':'Wedstrijdplan','file':(io.BytesIO(b'%PDF-1.4\n%%EOF'),'plan.pdf'),**extra}
        return self.client.post('/api/presentations',data=fields,headers={'X-CSRF-Token':self.csrf})

    def csv(self, raw, kind='fixtures', team=1):
        return self.client.post('/api/football/import',data={'team_id':str(team),'kind':kind,'file':(io.BytesIO(raw.encode()),'data.csv')},headers={'X-CSRF-Token':self.csrf})

    def test_restricted_trainer_cannot_read_hidden_modules_or_other_teams(self):
        self.seed_video('secret',1,1)
        self.restricted({'teams':'read','players':'read'})
        dashboard=self.client.get('/api/dashboard').json
        self.assertEqual([t['id'] for t in dashboard['teams']],[1])
        self.assertEqual({p['id'] for p in dashboard['players']},{1,2})
        self.assertEqual(dashboard['videos'],[])
        self.assertEqual(self.client.get('/media/secret').status_code,403)
        self.assertEqual(self.post('/api/players',{'name':'Blocked','team_id':1}).status_code,403)
        self.assertEqual(self.post('/api/observations',{'player_id':1,'rating':4,'category':'Tactiek','note':'Blocked'}).status_code,403)

    def test_exercise_only_account_does_not_receive_team_directory(self):
        self.restricted({'exercises':'read'})
        data=self.client.get('/api/dashboard').json
        self.assertEqual(data['teams'],[])
        self.assertEqual(data['players'],[])
        self.assertEqual(data['videos'],[])
        self.assertEqual(data['presentations'],[])

    def test_video_editor_can_assign_readable_player_without_player_edit_rights(self):
        self.seed_video('editable',1,1)
        self.restricted({'videos':'write','players':'read'})
        payload={'title':'Nieuwe titel','player_id':2,'kind':'clip','function':'Aanvallen','task':TASKS[0]}
        self.assertEqual(self.post('/api/videos/editable/details',payload).status_code,200)
        self.assertEqual(self.post('/api/players',{'id':1,'team_id':1,'name':'Blocked'}).status_code,403)

    def test_custom_player_permissions_cannot_expand_role_or_team(self):
        self.login()
        player=next(u for u in self.client.get('/api/users').json if u['username']=='player')
        policy={'modules':role_modules('player'),'all_teams':True,'team_ids':[]}
        policy['modules']['videos']='write'
        self.assertEqual(self.post(f"/api/users/{player['id']}/manage",{'permissions':policy}).status_code,400)
        policy['modules']['videos']='read'
        self.assertEqual(self.post(f"/api/users/{player['id']}/manage",{'permissions':policy}).status_code,200)
        self.login('player')
        self.assertEqual([t['id'] for t in self.client.get('/api/dashboard').json['teams']],[1])

    def test_exercises_round_trip_and_read_only_access(self):
        self.login()
        payload={'title':'Positiespel','category':TASKS[0],'description':'Speel vrij voor een medespeler.','setup':'Vierkant met twee vakken','coaching':'Kijk vooruit','minutes':20,'players':'8 spelers','url':'https://example.org/oefening'}
        self.assertEqual(self.post('/api/exercises',payload).status_code,200)
        row=self.client.get('/api/dashboard').json['exercises'][0]
        self.assertEqual(self.post('/api/exercises',{**payload,'id':row['id'],'minutes':25}).status_code,200)
        self.login('player')
        self.assertEqual(self.client.get('/api/dashboard').json['exercises'][0]['minutes'],25)
        self.assertEqual(self.post('/api/exercises',payload).status_code,403)

    def test_presentations_are_team_scoped_and_backed_up(self):
        self.login()
        first=self.presentation(1);second=self.presentation(2)
        self.assertEqual(first.status_code,201,first.json)
        self.assertEqual(second.status_code,201,second.json)
        key,foreign=first.json['id'],second.json['id']
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/'private.zip'
            backup(Path(self.temp.name),output)
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(len([n for n in archive.namelist() if n.startswith('data/presentations/')]),2)
        self.login('player')
        self.assertEqual(len(self.client.get('/api/dashboard').json['presentations']),1)
        response=self.client.get('/documents/'+key)
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.headers['Cache-Control'],'no-store')
        response.close()
        self.assertEqual(self.client.get('/documents/'+foreign).status_code,403)

    def test_invalid_presentations_urls_and_categories_are_rejected(self):
        self.login()
        response=self.presentation(file=(io.BytesIO(b'fake'),'bad.pdf'))
        self.assertEqual(response.status_code,400)
        response=self.presentation(file=(io.BytesIO(b'%PDF'),'bad.pdf'),url='javascript:alert(1)')
        self.assertEqual(response.status_code,400)
        self.assertEqual(list((Path(self.temp.name)/'presentations').iterdir()),[])
        self.assertEqual(self.post('/api/exercises',{'title':'Bad','category':'Other','minutes':20}).status_code,400)

    def test_six_tasks_are_available_and_video_input_is_normalized(self):
        self.login()
        self.assertEqual(self.client.get('/api/dashboard').json['tasks'],list(TASKS))
        self.seed_video('legacy',1,1)
        row={'title':'Mapindeling','task':'Kansen creeren','function':'Aanvallen','kind':'clip','player_id':1}
        self.assertEqual(self.post('/api/videos/legacy/details',row).status_code,200)
        self.assertEqual(self.client.get('/api/dashboard').json['videos'][0]['task'],'Kansen creëren')
        self.assertEqual(self.post('/api/videos/legacy/details',{**row,'task':'Onbekende nieuwe map'}).status_code,400)

    def test_football_configuration_and_atomic_csv_import(self):
        self.login()
        config={'first_team_id':1,'second_team_id':2,'first_url':'https://www.voetbal.nl/','second_url':''}
        self.assertEqual(self.post('/api/football/links',config).status_code,200)
        self.assertEqual(self.post('/api/football/links',{**config,'first_url':'https://evil.example/'}).status_code,400)
        header='datum;thuis;uit;thuisdoelpunten;uitdoelpunten\n'
        self.assertEqual(self.csv(header+'2026-11-14T14:30;A;B;;\n2026-11-07T14:30;A;C;2;1\n').status_code,200)
        self.assertEqual(len(self.client.get('/api/dashboard').json['fixtures']),2)
        self.assertEqual(self.csv(header+'2026-11-15T14:30;D;E;;\nBAD;X;Y;2;\n').status_code,400)
        self.assertEqual(len(self.client.get('/api/dashboard').json['fixtures']),2)
        standings='ploeg;positie;gespeeld;punten\nA;1;4;12\nB;2;4;9\n'
        self.assertEqual(self.csv(standings,'standings').status_code,200)
        self.assertEqual(len(self.client.get('/api/dashboard').json['standings']),2)
        self.login('coach')
        self.assertEqual(self.csv(header+'2026-11-14;A;B;;\n').status_code,403)

    def test_existing_user_survives_additive_permissions_migration(self):
        with tempfile.TemporaryDirectory() as folder:
            with sqlite3.connect(Path(folder)/'teams.db') as db:
                db.execute("CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,player_id INTEGER,active INTEGER NOT NULL DEFAULT 1)")
                db.execute("INSERT INTO users VALUES (99,'existing','preserved-hash','trainer',NULL,1)")
            upgraded=fixtures.create_app(folder,testing=True)
            try:
                with upgraded.app_context():
                    row=upgraded.db().execute('SELECT * FROM users WHERE id=99').fetchone()
                    self.assertEqual(row['password'],'preserved-hash')
                    self.assertEqual(row['permissions'],'')
            finally:
                upgraded.analysis_workers.shutdown(wait=True)
