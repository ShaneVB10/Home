import io
import tempfile
import unittest

from PIL import Image
from server import create_app


class PwaTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.app=create_app(self.temp.name,testing=True)
        self.client=self.app.test_client()

    def tearDown(self):
        self.app.analysis_workers.shutdown(wait=True)
        self.temp.cleanup()

    def test_manifest_has_installable_scope_and_actual_icons(self):
        response=self.client.get('/manifest.webmanifest')
        self.assertEqual(response.status_code,200)
        self.assertIn('application/manifest+json',response.headers['Content-Type'])
        manifest=response.get_json(force=True)
        response.close()
        self.assertEqual((manifest['start_url'],manifest['scope'],manifest['display']),('/','/','standalone'))
        self.assertTrue(any(icon['purpose']=='maskable' for icon in manifest['icons']))
        for icon in manifest['icons']:
            result=self.client.get(icon['src'])
            self.assertEqual(result.status_code,200)
            with Image.open(io.BytesIO(result.data)) as image:
                self.assertEqual(image.size,tuple(map(int,icon['sizes'].split('x'))))
            result.close()

    def test_root_worker_and_home_metadata_allow_pwa_without_unlocking_data(self):
        worker=self.client.get('/sw.js')
        self.assertEqual(worker.status_code,200)
        self.assertIn('javascript',worker.headers['Content-Type'])
        self.assertEqual(worker.headers['Service-Worker-Allowed'],'/')
        self.assertEqual(worker.headers['Cache-Control'],'no-cache')
        worker.close()
        home=self.client.get('/')
        self.assertIn(b'rel="manifest"',home.data)
        self.assertIn(b'apple-touch-icon',home.data)
        self.assertIn(b'data-pwa-install',home.data)
        self.assertIn("worker-src 'self'",home.headers['Content-Security-Policy'])
        self.assertEqual(self.client.get('/api/dashboard').status_code,401)
        self.assertEqual(self.client.get('/photos/1').status_code,401)
