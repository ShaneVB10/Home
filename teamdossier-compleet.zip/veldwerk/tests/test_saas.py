import base64
import secrets
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from cryptography.exceptions import InvalidTag
from werkzeug.security import generate_password_hash
from werkzeug.test import Client
from werkzeug.wrappers import Response

from saas import TenantDispatcher, create_platform_app
from saas_backup import backup_all, prune_backups, restore_to_new_directory, verify_file
from deployment_check import validate as validate_deployment


class SaaSTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();root=Path(self.temp.name)
        self.platform=create_platform_app(root/'platform',root/'tenants',testing=True)
        with self.platform.app_context():
            self.platform.db().execute('INSERT INTO platform_users(username,password) VALUES (?,?)',('owner',generate_password_hash('platform-test-password')))
            self.platform.db().commit()
        self.client=self.platform.test_client()
        self.client.post('/eigenaar/inloggen',data={'username':'owner','password':'platform-test-password'})
        with self.client.session_transaction() as session:self.csrf=session['platform_csrf']
        self.root=root

    def tearDown(self):
        self.temp.cleanup()

    def tenant(self,slug,name,password='temporary-password-2026'):
        response=self.client.post('/eigenaar/klanten',data={'csrf':self.csrf,'slug':slug,'name':name,'plan':'Club','trial_until':'','password':password})
        self.assertEqual(response.status_code,302)
        return password

    def test_separate_databases_host_routing_and_audit(self):
        alpha_password=self.tenant('club-alpha','Voetbalvereniging Alpha')
        beta_password=self.tenant('club-beta','Voetbalvereniging Beta')
        self.assertTrue((self.root/'tenants/club-alpha/teams.db').is_file())
        self.assertTrue((self.root/'tenants/club-beta/teams.db').is_file())
        dispatcher=TenantDispatcher(self.platform,self.root/'tenants','example.test',testing=True)
        alpha=Client(dispatcher,Response,use_cookies=True);beta=Client(dispatcher,Response,use_cookies=True)
        login=alpha.post('/api/login',json={'username':'beheerder','password':alpha_password},headers={'Host':'club-alpha.example.test'})
        self.assertEqual(login.status_code,200);csrf=alpha.get('/api/me',headers={'Host':'club-alpha.example.test'}).json['csrf']
        self.assertEqual(alpha.post('/api/teams',json={'name':'Alpha 1'},headers={'Host':'club-alpha.example.test','X-CSRF-Token':csrf}).status_code,200)
        beta_login=beta.post('/api/login',json={'username':'beheerder','password':beta_password},headers={'Host':'club-beta.example.test'})
        self.assertEqual(beta_login.status_code,200);beta_csrf=beta.get('/api/me',headers={'Host':'club-beta.example.test'}).json['csrf']
        self.assertEqual(beta.get('/api/dashboard',headers={'Host':'club-beta.example.test'}).json['teams'],[])
        self.assertEqual(alpha.get('/api/dashboard',headers={'Host':'club-alpha.example.test'}).json['teams'][0]['name'],'Alpha 1')
        audit=alpha.get('/api/audit',headers={'Host':'club-alpha.example.test'}).json['rows']
        self.assertTrue(any(row['path']=='/api/teams' and row['username']=='beheerder' for row in audit))
        unknown=Client(dispatcher,Response).get('/',headers={'Host':'unknown.example.test'})
        self.assertEqual(unknown.status_code,404)
        for app in dispatcher.apps.values():app.analysis_workers.shutdown(wait=True)

    def test_suspended_tenant_is_unavailable(self):
        self.tenant('club-gamma','Voetbalvereniging Gamma')
        with self.platform.app_context():
            self.platform.db().execute("UPDATE tenants SET status='suspended' WHERE slug='club-gamma'");self.platform.db().commit()
        dispatcher=TenantDispatcher(self.platform,self.root/'tenants','example.test',testing=True)
        response=Client(dispatcher,Response).get('/',headers={'Host':'club-gamma.example.test'})
        self.assertEqual(response.status_code,404)

    def test_encrypted_backup_verification_wrong_key_and_safe_restore(self):
        self.tenant('club-delta','Voetbalvereniging Delta')
        key=secrets.token_bytes(32);output=self.root/'external-backups'
        paths=backup_all(self.root/'platform/platform.db',self.root/'tenants',output,key)
        self.assertEqual(len(paths),1);self.assertNotIn(b'SQLite format 3',paths[0].read_bytes())
        verify_file(paths[0],key)
        with self.assertRaises(InvalidTag):verify_file(paths[0],secrets.token_bytes(32))
        restored=self.root/'restore-check';restore_to_new_directory(paths[0],restored,key)
        self.assertTrue((restored/'data/teams.db').is_file())
        with self.assertRaises(FileExistsError):restore_to_new_directory(paths[0],restored,key)

    def test_https_headers_legal_roles_and_no_kvk(self):
        self.tenant('club-epsilon','Voetbalvereniging Epsilon')
        dispatcher=TenantDispatcher(self.platform,self.root/'tenants','example.test',testing=True)
        with patch.dict('os.environ',{'TEAM_HTTPS':'1','TEAM_ENFORCE_HTTPS':'1'}):
            https_client=Client(dispatcher,Response)
            insecure=https_client.get('/privacy',base_url='http://club-epsilon.example.test')
            self.assertEqual(insecure.status_code,308);self.assertTrue(insecure.location.startswith('https://'))
            response=https_client.get('/privacy',base_url='https://club-epsilon.example.test')
        self.assertEqual(response.status_code,200)
        text=response.get_data(as_text=True)
        self.assertIn('Voetbalvereniging Epsilon',text);self.assertNotIn('KvK',text)
        self.assertIn('max-age=31536000',response.headers['Strict-Transport-Security'])
        self.assertIn('verwerkingsverantwoordelijke',text)
        for app in dispatcher.apps.values():app.analysis_workers.shutdown(wait=True)

    def test_backup_retention_removes_only_old_teamdossier_files(self):
        folder=self.root/'retention';folder.mkdir()
        old=folder/'club-20260101.tdbk';new=folder/'club-20261109.tdbk';other=folder/'keep.txt'
        for path in (old,new,other):path.write_text('x')
        import os,time
        os.utime(old,(time.time()-40*86400,time.time()-40*86400))
        removed=prune_backups(folder,35)
        self.assertEqual(removed,[old]);self.assertFalse(old.exists());self.assertTrue(new.exists());self.assertTrue(other.exists())

    def test_production_check_requires_legal_locations_and_retention(self):
        environment={name:'ingevuld' for name in (
            'TEAM_BASE_DOMAIN','TEAM_PLATFORM_DATA','TEAM_TENANT_ROOT','TEAM_PLATFORM_SECRET','TEAM_AUDIT_KEY','TEAM_BACKUP_KEY',
            'TEAM_LEGAL_NAME','TEAM_LEGAL_ADDRESS','TEAM_PRIVACY_EMAIL','TEAM_HOSTING_PROVIDER','TEAM_HOSTING_LOCATION',
            'TEAM_BACKUP_PROVIDER','TEAM_BACKUP_LOCATION','TEAM_EMAIL_PROVIDER','TEAM_PAYMENT_PROVIDER','TEAM_ACCOUNT_RETENTION',
            'TEAM_MEDICAL_RETENTION','TEAM_MEDIA_RETENTION','TEAM_BACKUP_RETENTION')}
        environment.update(TEAM_HTTPS='1',TEAM_ENFORCE_HTTPS='1',TEAM_TRUST_PROXY='1',TEAM_BACKUP_RETENTION_DAYS='35')
        self.assertEqual(validate_deployment(environment),[])
        environment['TEAM_PRIVACY_EMAIL']='VUL_PRIVACY_EMAIL_IN'
        self.assertTrue(any('TEAM_PRIVACY_EMAIL' in item for item in validate_deployment(environment)))


if __name__=='__main__':unittest.main()
