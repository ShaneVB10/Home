import io
import tempfile
import unittest
import zipfile
from pathlib import Path

from PIL import Image
import test_server as fixtures
from maintenance import backup


class PhotosReviewsTests(unittest.TestCase):
    setUpClass=classmethod(fixtures.TeamTests.setUpClass.__func__)
    tearDownClass=classmethod(fixtures.TeamTests.tearDownClass.__func__)
    setUp=fixtures.TeamTests.setUp
    tearDown=fixtures.TeamTests.tearDown
    login=fixtures.TeamTests.login
    post=fixtures.TeamTests.post

    def photo(self,player=1,color='green',raw=None):
        if raw is None:
            output=io.BytesIO()
            Image.new('RGB',(1000,800),color).save(output,format='PNG')
            raw=output.getvalue()
        return self.client.post(f'/api/players/{player}/photo',data={'file':(io.BytesIO(raw),'photo.png')},headers={'X-CSRF-Token':self.csrf})

    def test_photo_normalizes_and_obeys_profile_permissions(self):
        self.login()
        self.assertEqual(self.photo().status_code,200)
        self.assertEqual(self.photo(2).status_code,200)
        player=self.client.get('/api/dashboard').json['players'][0]
        self.assertTrue(player['has_photo'])
        self.assertNotIn('photo',player)
        response=self.client.get('/photos/1')
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.headers['Content-Type'],'image/jpeg')
        self.assertEqual(response.headers['Cache-Control'],'no-store')
        with Image.open(io.BytesIO(response.data)) as image:
            self.assertLessEqual(max(image.size),640)
            self.assertEqual(dict(image.getexif()),{})
        response.close()
        self.login('player')
        own=self.client.get('/photos/1')
        self.assertEqual(own.status_code,200);own.close()
        self.assertEqual(self.client.get('/photos/2').status_code,403)
        self.assertEqual(self.photo().status_code,403)

    def test_replacing_photo_and_backup_keep_current_photo(self):
        self.login()
        self.assertEqual(self.photo(color='red').status_code,200)
        self.assertEqual(self.photo(color='blue').status_code,200)
        self.assertEqual(len(list((Path(self.temp.name)/'photos').iterdir())),1)
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/'backup.zip'
            backup(Path(self.temp.name),output)
            with zipfile.ZipFile(output) as archive:
                photos=[n for n in archive.namelist() if n.startswith('data/photos/')]
                self.assertEqual(len(photos),1)

    def test_invalid_photo_does_not_change_player(self):
        self.login()
        self.assertEqual(self.photo(raw=b'<svg><script>alert(1)</script></svg>').status_code,400)
        self.assertEqual(self.photo(raw=b'not a photo').status_code,400)
        self.assertEqual(list((Path(self.temp.name)/'photos').iterdir()),[])
        self.assertFalse(self.client.get('/api/dashboard').json['players'][0]['has_photo'])

    def test_existing_observation_can_be_edited_without_duplicating_or_changing_creation(self):
        self.login()
        payload={'player_id':1,'category':'Tactiek','rating':3,'note':'Eerste beoordeling'}
        response=self.post('/api/observations',payload)
        key=response.json['id']
        before=self.client.get('/api/dashboard').json['observations'][0]
        self.login('coach')
        self.assertEqual(self.post('/api/observations',{**payload,'id':key,'rating':5,'note':'Beoordeling bijgewerkt'}).status_code,200)
        rows=self.client.get('/api/dashboard').json['observations']
        self.assertEqual(len(rows),1)
        self.assertEqual((rows[0]['rating'],rows[0]['note']),(5,'Beoordeling bijgewerkt'))
        self.assertEqual(rows[0]['created'],before['created'])
        self.assertEqual(rows[0]['user_id'],before['user_id'])
        self.assertNotEqual(rows[0]['updated_by'],before['user_id'])
        self.assertEqual(self.client.get('/api/reports').json['rows'][0]['rating'],5)
        self.login('player')
        self.assertEqual(self.post('/api/observations',{**payload,'id':key}).status_code,403)

    def test_review_cannot_be_moved_to_other_player_or_edited_with_read_only_rights(self):
        self.login()
        payload={'player_id':1,'category':'Techniek','rating':4,'note':'Goed'}
        key=self.post('/api/observations',payload).json['id']
        self.assertEqual(self.post('/api/observations',{**payload,'id':key,'player_id':2}).status_code,400)
        coach=next(u for u in self.client.get('/api/users').json if u['username']=='coach')
        self.assertEqual(self.post(f"/api/users/{coach['id']}/manage",{'permissions':{'modules':{'players':'read'},'all_teams':True,'team_ids':[]}}).status_code,200)
        self.login('coach')
        self.assertEqual(self.post('/api/observations',{**payload,'id':key,'rating':1}).status_code,403)

    def test_pptx_upload_and_protected_download_round_trip(self):
        self.login()
        output=io.BytesIO()
        with zipfile.ZipFile(output,'w') as archive:
            archive.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
            archive.writestr('ppt/presentation.xml','<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>')
        raw=output.getvalue()
        response=self.client.post('/api/presentations',data={'title':'Wedstrijdplan','team_id':'1','match_date':'2026-11-15','opponent':'Testclub','file':(io.BytesIO(raw),'wedstrijdplan.pptx')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,201,response.json)
        file=self.client.get('/documents/'+response.json['id'])
        self.assertEqual(file.status_code,200)
        self.assertEqual(file.data,raw)
        self.assertIn('wedstrijdplan.pptx',file.headers['Content-Disposition'])
        file.close()

    def test_large_presentation_has_json_error_and_link_alternative_works(self):
        self.login()
        fields={'title':'Grote presentatie','team_id':'1','match_date':'2026-11-15','opponent':'Testclub'}
        response=self.client.post('/api/presentations',data={**fields,'file':(io.BytesIO(b'x'*(25*1024*1024+1)),'large.pptx')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,400)
        self.assertIn('25 MB',response.json['error'])
        response.request.input_stream.close()
        response.close()
        response=self.client.post('/api/presentations',data={**fields,'url':'https://example.org/shared-presentation'},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(response.status_code,201,response.json)
        row=self.client.get('/api/dashboard').json['presentations'][0]
        self.assertFalse(row['has_file'])
        self.assertEqual(row['url'],'https://example.org/shared-presentation')
