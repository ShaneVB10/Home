"""Training library, private presentations and club match-data preparation."""
import csv
import io
import json
import time
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

from flask import abort, g, jsonify, request, send_file
from permissions import TASKS
from exercise_catalog import seed_catalog


def register_extensions(app, db, protect, require, permitted, team_allowed, admin, text):
    root = app.config['DATA'] / 'presentations'
    root.mkdir(exist_ok=True, mode=0o700)
    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS exercises(id INTEGER PRIMARY KEY, title TEXT NOT NULL, category TEXT NOT NULL,
          description TEXT NOT NULL, setup TEXT NOT NULL, coaching TEXT NOT NULL, minutes INTEGER NOT NULL,
          players TEXT NOT NULL, url TEXT NOT NULL DEFAULT '', created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS presentations(id TEXT PRIMARY KEY, title TEXT NOT NULL, team_id INTEGER NOT NULL REFERENCES teams(id),
          match_date TEXT NOT NULL, opponent TEXT NOT NULL, note TEXT NOT NULL, filename TEXT NOT NULL DEFAULT '',
          original_name TEXT NOT NULL DEFAULT '', url TEXT NOT NULL DEFAULT '', created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS fixtures(id INTEGER PRIMARY KEY, team_id INTEGER NOT NULL REFERENCES teams(id),
          date TEXT NOT NULL, home TEXT NOT NULL, away TEXT NOT NULL, score_home INTEGER, score_away INTEGER,
          source TEXT NOT NULL DEFAULT 'CSV-import', UNIQUE(team_id,date,home,away));
        CREATE TABLE IF NOT EXISTS standings(id INTEGER PRIMARY KEY, team_id INTEGER NOT NULL REFERENCES teams(id),
          club TEXT NOT NULL, position INTEGER NOT NULL, played INTEGER NOT NULL, points INTEGER NOT NULL,
          source TEXT NOT NULL DEFAULT 'CSV-import', UNIQUE(team_id,club));
        CREATE TABLE IF NOT EXISTS football_links(team_id INTEGER PRIMARY KEY REFERENCES teams(id), url TEXT NOT NULL);
        ''')
        columns={r[1] for r in db().execute('PRAGMA table_info(exercises)')}
        for name in ('theme','age_group','diagram'):
            if name not in columns:
                db().execute(f"ALTER TABLE exercises ADD COLUMN {name} TEXT NOT NULL DEFAULT ''")
        if 'team_id' not in columns:
            db().execute('ALTER TABLE exercises ADD COLUMN team_id INTEGER REFERENCES teams(id)')
        if 'builtin_key' not in columns:
            db().execute("ALTER TABLE exercises ADD COLUMN builtin_key TEXT")
        db().execute('CREATE UNIQUE INDEX IF NOT EXISTS exercises_builtin_key ON exercises(builtin_key) WHERE builtin_key IS NOT NULL')
        seed_catalog(db())
        db().commit()

    @app.post('/api/exercises/diagram')
    @protect
    def save_exercise_diagram():
        require('exercises',True);payload=request.get_json();key=int(payload.get('id') or 0)
        row=db().execute('SELECT * FROM exercises WHERE id=?',(key,)).fetchone()
        if not row:abort(404,'Oefening niet gevonden.')
        if row['builtin_key']:abort(403,'Maak eerst een eigen oefening om een veldtekening op te slaan.')
        if row['team_id'] is not None and not team_allowed(row['team_id']):abort(403,'Geen toegang tot deze oefening.')
        diagram=payload.get('diagram')
        if not isinstance(diagram,dict) or diagram.get('field') not in ('full','half') or not isinstance(diagram.get('items'),list) or len(diagram['items'])>100:
            abort(400,'Ongeldige veldtekening.')
        allowed={'player-red','player-blue','ball','cone','goal','pass','run'}
        clean={'field':diagram['field'],'items':[]}
        for item in diagram['items']:
            if not isinstance(item,dict) or item.get('type') not in allowed:abort(400,'Ongeldig tekenobject.')
            obj={'type':item['type']}
            keys=('x','y','x2','y2') if item['type'] in ('pass','run') else ('x','y')
            for name in keys:
                try:value=round(float(item[name]),2)
                except (KeyError,TypeError,ValueError):abort(400,'Ongeldige positie in veldtekening.')
                if not 0<=value<=100:abort(400,'Tekenobject valt buiten het veld.')
                obj[name]=value
            clean['items'].append(obj)
        encoded=json.dumps(clean,separators=(',',':'))
        db().execute('UPDATE exercises SET diagram=? WHERE id=?',(encoded,key));db().commit()
        return jsonify(ok=True)

    def url(value, voetbal=False):
        value = str(value or '').strip()
        if not value:
            return ''
        try:
            parsed = urlsplit(value)
            valid = parsed.scheme == 'https' and parsed.hostname and not parsed.username and not parsed.password and len(value) <= 2000
            if voetbal:
                valid = valid and (parsed.hostname == 'voetbal.nl' or parsed.hostname.endswith('.voetbal.nl'))
            if not valid:
                raise ValueError()
        except ValueError:
            abort(400, 'Gebruik een geldige HTTPS-link' + (' van Voetbal.nl.' if voetbal else '.'))
        return value

    @app.post('/api/exercises')
    @protect
    def save_exercise():
        require('exercises', True)
        payload = request.get_json()
        category = payload.get('category') or ''
        if category and category not in TASKS:
            abort(400, 'Kies een van de zes teamtaken.')
        team_id=int(payload['team_id']) if payload.get('team_id') else None
        if team_id is not None and (not team_allowed(team_id) or not db().execute('SELECT 1 FROM teams WHERE id=?',(team_id,)).fetchone()):
            abort(403,'Geen toegang tot dit elftal.')
        minutes = int(payload.get('minutes', 0))
        if not 1 <= minutes <= 240:
            abort(400, 'Kies een duur tussen 1 en 240 minuten.')
        values = (text(payload,'title'), category, text(payload,'description',5000), text(payload,'setup',3000,False),
                  text(payload,'coaching',3000,False), minutes, text(payload,'players',100,False), url(payload.get('url')),text(payload,'theme',120,False),text(payload,'age_group',120,False),team_id)
        if payload.get('id'):
            old=db().execute('SELECT * FROM exercises WHERE id=?',(int(payload['id']),)).fetchone()
            if old and old['builtin_key']:
                abort(403,'De clubbibliotheek is alleen-lezen. Maak een eigen kopie om deze oefening aan te passen.')
            if old and old['team_id'] is not None and not team_allowed(old['team_id']):
                abort(403,'Geen toegang tot deze oefening.')
            result = db().execute('UPDATE exercises SET title=?,category=?,description=?,setup=?,coaching=?,minutes=?,players=?,url=?,theme=?,age_group=?,team_id=? WHERE id=?', (*values,int(payload['id'])))
            if not result.rowcount:
                abort(404, 'Oefening niet gevonden.')
        else:
            exercise_id=db().execute('INSERT INTO exercises(title,category,description,setup,coaching,minutes,players,url,theme,age_group,team_id,created) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', (*values,time.time())).lastrowid
        db().commit()
        return jsonify(ok=True,id=int(payload['id']) if payload.get('id') else exercise_id)

    @app.get('/api/exercise-catalog')
    @protect
    def exercise_catalog():
        require('exercises')
        age=str(request.args.get('age','')).strip()
        if age and age not in ('O8','O9','O10','O11','O12','O13','O14','O15','O16','O17','O18','O19','O23'):
            abort(400,'Kies een geldige leeftijdscategorie.')
        query='SELECT * FROM exercises WHERE builtin_key IS NOT NULL'
        values=[]
        if age:query+=' AND age_group=?';values.append(age)
        query+=' ORDER BY age_group,title'
        return jsonify(rows=[dict(r) for r in db().execute(query,values)])

    @app.post('/api/presentations')
    @protect
    def save_presentation():
        require('presentations', True)
        team_id = int(request.form.get('team_id',0))
        if not team_allowed(team_id):
            abort(403, 'Geen toegang tot dit team.')
        if not db().execute('SELECT 1 FROM teams WHERE id=?',(team_id,)).fetchone():
            abort(400, 'Team niet gevonden.')
        title, opponent = text(request.form,'title'), text(request.form,'opponent')
        match_date = text(request.form,'match_date')
        try:
            datetime.strptime(match_date,'%Y-%m-%d')
        except ValueError:
            abort(400, 'Kies een geldige wedstrijddatum.')
        note = text(request.form,'note',3000,False)
        external = url(request.form.get('url'))
        upload = request.files.get('file')
        if not external and (not upload or not upload.filename):
            abort(400, 'Upload een PDF/PPTX of voeg een HTTPS-link toe.')
        key = uuid.uuid4().hex
        filename, original = '', ''
        if upload and upload.filename:
            suffix = Path(upload.filename).suffix.lower()
            raw = upload.stream.read(25*1024*1024+1)
            if len(raw) > 25*1024*1024:
                abort(400, 'Maximaal 25 MB per presentatie.')
            if suffix == '.pdf':
                if not raw.startswith(b'%PDF-'):
                    abort(400, 'Geen geldig PDF-bestand.')
            elif suffix == '.pptx':
                try:
                    with zipfile.ZipFile(io.BytesIO(raw)) as book:
                        if not {'[Content_Types].xml','ppt/presentation.xml'}.issubset(book.namelist()) or sum(f.file_size for f in book.infolist())>100*1024*1024 or any('vbaproject' in n.lower() for n in book.namelist()):
                            raise ValueError()
                except (zipfile.BadZipFile, ValueError):
                    abort(400, 'Geen geldig PPTX-bestand zonder macro’s.')
            else:
                abort(400, 'Alleen PDF en PPTX worden ondersteund.')
            filename, original = key+suffix, Path(upload.filename).name[:200]
            (root / filename).write_bytes(raw)
        try:
            db().execute('INSERT INTO presentations(id,title,team_id,match_date,opponent,note,filename,original_name,url,created,season_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)', (key,title,team_id,match_date,opponent,note,filename,original,external,time.time(),g.season_id))
            db().commit()
        except Exception:
            if filename:
                (root / filename).unlink(missing_ok=True)
            raise
        return jsonify(ok=True,id=key), 201

    @app.get('/documents/<key>')
    @protect
    def presentation_file(key):
        require('presentations')
        row = db().execute('SELECT * FROM presentations WHERE id=?',(key,)).fetchone()
        if not row or row['season_id']!=g.season_id:
            abort(404, 'Presentatie niet gevonden.')
        if not team_allowed(row['team_id']):
            abort(403, 'Geen toegang tot deze presentatie.')
        if not row['filename']:
            abort(404, 'Deze presentatie bevat alleen een externe link.')
        return send_file(root / row['filename'], as_attachment=True, download_name=row['original_name'], conditional=True)

    @app.post('/api/football/links')
    @protect
    def football_link():
        admin()
        payload = request.get_json()
        first, second = int(payload.get('first_team_id',0)), int(payload.get('second_team_id',0))
        existing = {r[0] for r in db().execute('SELECT id FROM teams')}
        if first not in existing or second not in existing or first == second:
            abort(400, 'Kies twee verschillende bestaande teams voor het 1e en 2e elftal.')
        for key,team_id in (('first',first),('second',second)):
            link = url(payload.get(key+'_url'),voetbal=True)
            db().execute('INSERT OR REPLACE INTO football_links VALUES (?,?)',(team_id,link))
            db().execute('INSERT OR REPLACE INTO settings VALUES (?,?)',('football_'+key+'_team',str(team_id)))
        db().commit()
        return jsonify(ok=True)

    @app.post('/api/football/import')
    @protect
    def import_football():
        admin()
        team_id = int(request.form.get('team_id',0))
        if not db().execute('SELECT 1 FROM teams WHERE id=?',(team_id,)).fetchone():
            abort(400, 'Kies een bestaand team.')
        kind = request.form.get('kind')
        if kind not in ('fixtures','standings'):
            abort(400, 'Kies programma/uitslagen of stand.')
        upload = request.files.get('file')
        if not upload:
            abort(400, 'Selecteer een CSV-bestand.')
        raw = upload.stream.read(1_000_001)
        if len(raw)>1_000_000:
            abort(400, 'Maximaal 1 MB per CSV-bestand.')
        try:
            content=raw.decode('utf-8-sig')
            dialect=csv.Sniffer().sniff(content[:4096],delimiters=',;\t')
            rows=list(csv.DictReader(io.StringIO(content),dialect=dialect))
            if not rows or len(rows)>3000:
                abort(400, 'Gebruik een CSV met 1 tot 3000 gegevensregels.')
            required = {'datum','thuis','uit','thuisdoelpunten','uitdoelpunten'} if kind=='fixtures' else {'ploeg','positie','gespeeld','punten'}
            if not required.issubset(rows[0]):
                abort(400, 'Vereiste kolommen: '+', '.join(sorted(required)))
            validated=[]
            for number,row in enumerate(rows,2):
                if kind=='fixtures':
                    stamp=row['datum'].strip()
                    stamp=datetime.fromisoformat(stamp).isoformat(timespec='minutes')
                    home,away=row['thuis'].strip(),row['uit'].strip()
                    a=int(row['thuisdoelpunten']) if row['thuisdoelpunten'].strip() else None
                    b=int(row['uitdoelpunten']) if row['uitdoelpunten'].strip() else None
                    if not home or not away or len(home)>200 or len(away)>200 or (a is None)!=(b is None) or any(n is not None and not 0<=n<=99 for n in (a,b)):
                        raise ValueError()
                    validated.append((team_id,stamp,home,away,a,b))
                else:
                    club=row['ploeg'].strip()
                    position,played,points=int(row['positie']),int(row['gespeeld']),int(row['punten'])
                    if not club or len(club)>200 or not 1<=position<=100 or not 0<=played<=200 or not -100<=points<=1000:
                        raise ValueError()
                    validated.append((team_id,club,position,played,points))
        except (ValueError,TypeError,AttributeError,csv.Error,UnicodeError):
            abort(400, 'Ongeldige CSV-inhoud. Controleer de kolommen, datum en getallen; er is niets geïmporteerd.')
        if kind=='fixtures':
            for row in validated:
                db().execute('INSERT INTO fixtures(team_id,date,home,away,score_home,score_away,season_id) VALUES (?,?,?,?,?,?,?) ON CONFLICT(season_id,team_id,date,home,away) DO UPDATE SET score_home=excluded.score_home,score_away=excluded.score_away',(*row,g.season_id))
        else:
            if len({r[1] for r in validated}) != len(validated):
                abort(400, 'Dubbele ploeg in stand; er is niets geïmporteerd.')
            db().execute('DELETE FROM standings WHERE team_id=? AND season_id=?',(team_id,g.season_id))
            db().executemany('INSERT INTO standings(team_id,club,position,played,points,season_id) VALUES (?,?,?,?,?,?)',[(*r,g.season_id) for r in validated])
        db().commit()
        return jsonify(ok=True,count=len(validated))

    def dashboard():
        exercises=[]
        if permitted('exercises'):
            linked={r[0] for r in db().execute('SELECT te.exercise_id FROM training_exercises te JOIN trainings t ON t.id=te.training_id WHERE t.season_id=?',(g.season_id,))}
            exercises=[dict(r) for r in db().execute('SELECT * FROM exercises WHERE builtin_key IS NULL ORDER BY title') if r['team_id'] is None or team_allowed(r['team_id'])]
            if linked:
                placeholders=','.join('?' for _ in linked)
                exercises.extend(dict(r) for r in db().execute(f'SELECT * FROM exercises WHERE id IN ({placeholders}) ORDER BY title',tuple(linked)) if r['id'] not in {e['id'] for e in exercises})
        presentations=[]
        if permitted('presentations'):
            for row in db().execute('SELECT * FROM presentations WHERE season_id=? ORDER BY match_date DESC,created DESC',(g.season_id,)):
                if team_allowed(row['team_id']):
                    item=dict(row)
                    item['has_file']=bool(item.pop('filename'))
                    presentations.append(item)
        fixtures=[dict(r) for r in db().execute('SELECT * FROM fixtures WHERE season_id=? ORDER BY date DESC',(g.season_id,)) if team_allowed(r['team_id'])] if permitted('matches') else []
        standings=[dict(r) for r in db().execute('SELECT * FROM standings WHERE season_id=? ORDER BY team_id,position',(g.season_id,)) if team_allowed(r['team_id'])] if permitted('matches') else []
        links=[dict(r) for r in db().execute('SELECT * FROM football_links') if team_allowed(r['team_id'])] if permitted('matches') else []
        folders=[dict(r) for r in db().execute('SELECT id,name FROM teams ORDER BY name') if team_allowed(r['id'])] if permitted('exercises') else []
        return dict(exercises=exercises,exercise_teams=folders,presentations=presentations,fixtures=fixtures,standings=standings,football_links=links)

    return dashboard
