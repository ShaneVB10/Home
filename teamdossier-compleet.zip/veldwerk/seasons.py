"""Explicit season boundaries. Historical records and files are never removed."""
from datetime import datetime
from zoneinfo import ZoneInfo

from flask import abort, g, jsonify, request

SEASON_TABLES=('videos','observations','presentations','fixtures','standings','trainings','selections','development_plans')


def register_seasons(app,db,protect,admin,text):
    with app.app_context():
        db().executescript('''
        CREATE TABLE IF NOT EXISTS seasons(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,
          starts TEXT NOT NULL,ends TEXT NOT NULL,archived INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS season_players(season_id INTEGER NOT NULL REFERENCES seasons(id),
          player_id INTEGER NOT NULL REFERENCES players(id),team_id INTEGER NOT NULL REFERENCES teams(id),
          shirt_number INTEGER,position TEXT NOT NULL DEFAULT '',goal TEXT NOT NULL DEFAULT '',
          PRIMARY KEY(season_id,player_id),UNIQUE(season_id,team_id,shirt_number));
        ''')
        migrated=db().execute("SELECT value FROM settings WHERE key='season_migration_v1'").fetchone()
        if not db().execute('SELECT 1 FROM seasons').fetchone():
            now=datetime.now(ZoneInfo('Europe/Amsterdam'))
            year=now.year if now.month>=7 else now.year-1
            old=db().execute("SELECT value FROM settings WHERE key='season'").fetchone()
            name=old['value'].strip() if old and old['value'].strip() else f'{year}/{year+1}'
            db().execute('INSERT INTO seasons(id,name,starts,ends) VALUES (1,?,?,?)',(name,f'{year}-07-01',f'{year+1}-06-30'))
        db().execute("INSERT OR IGNORE INTO settings(key,value) VALUES ('active_season','1')")
        for table in SEASON_TABLES:
            if 'season_id' not in {r[1] for r in db().execute(f'PRAGMA table_info({table})')}:
                db().execute(f'ALTER TABLE {table} ADD COLUMN season_id INTEGER NOT NULL DEFAULT 1')
        if not migrated:
            db().execute('INSERT OR IGNORE INTO season_players SELECT 1,id,team_id,shirt_number,position,goal FROM players')
            # Replace only the two old global uniqueness constraints; IDs and data are retained.
            db().execute('''CREATE TABLE fixtures_season(id INTEGER PRIMARY KEY,team_id INTEGER NOT NULL REFERENCES teams(id),
              date TEXT NOT NULL,home TEXT NOT NULL,away TEXT NOT NULL,score_home INTEGER,score_away INTEGER,
              source TEXT NOT NULL DEFAULT 'CSV-import',season_id INTEGER NOT NULL DEFAULT 1,
              UNIQUE(season_id,team_id,date,home,away))''')
            db().execute('INSERT INTO fixtures_season SELECT id,team_id,date,home,away,score_home,score_away,source,season_id FROM fixtures')
            db().execute('DROP TABLE fixtures')
            db().execute('ALTER TABLE fixtures_season RENAME TO fixtures')
            db().execute('''CREATE TABLE standings_season(id INTEGER PRIMARY KEY,team_id INTEGER NOT NULL REFERENCES teams(id),
              club TEXT NOT NULL,position INTEGER NOT NULL,played INTEGER NOT NULL,points INTEGER NOT NULL,
              source TEXT NOT NULL DEFAULT 'CSV-import',season_id INTEGER NOT NULL DEFAULT 1,UNIQUE(season_id,team_id,club))''')
            db().execute('INSERT INTO standings_season SELECT id,team_id,club,position,played,points,source,season_id FROM standings')
            db().execute('DROP TABLE standings')
            db().execute('ALTER TABLE standings_season RENAME TO standings')
            db().execute("INSERT OR REPLACE INTO settings VALUES ('season_migration_v1','1')")
        db().commit()

    def context():
        default=db().execute("SELECT value FROM settings WHERE key='active_season'").fetchone()['value']
        try:
            key=int(request.args.get('season') or default)
        except ValueError:
            abort(400,'Kies een geldig seizoen.')
        row=db().execute('SELECT * FROM seasons WHERE id=?',(key,)).fetchone()
        if not row:
            abort(404,'Seizoen niet gevonden.')
        g.season_id=key
        g.season=dict(row)
        scoped=request.path.startswith(('/api/trainings','/api/attendance','/api/selections','/api/plans','/api/videos','/api/observations','/api/presentations','/api/football/import','/api/players','/api/medical','/api/staff','/api/moments','/api/smart-analysis','/api/matches/manual','/api/club-suite'))
        if request.method!='GET' and row['archived'] and scoped:
            abort(403,'Dit seizoen is gearchiveerd. De beheerder kan het heropenen om gegevens te corrigeren.')

    def summary():
        active=int(db().execute("SELECT value FROM settings WHERE key='active_season'").fetchone()['value'])
        return dict(seasons=[dict(r) for r in db().execute('SELECT * FROM seasons ORDER BY starts DESC,id DESC')],selected_season=g.season,active_season=active)

    @app.post('/api/seasons')
    @protect
    def create_season():
        admin()
        payload=request.get_json()
        name=text(payload,'name',80)
        starts,ends=text(payload,'starts',10),text(payload,'ends',10)
        try:
            datetime.strptime(starts,'%Y-%m-%d');datetime.strptime(ends,'%Y-%m-%d')
        except ValueError:
            abort(400,'Kies een geldige begin- en einddatum.')
        if ends<starts:
            abort(400,'De einddatum moet op of na de begindatum liggen.')
        source=int(payload.get('copy_roster_from') or 0)
        if source and not db().execute('SELECT 1 FROM seasons WHERE id=?',(source,)).fetchone():
            abort(400,'Het bronseizoen bestaat niet.')
        active=payload.get('active',False)
        if type(active) is not bool:
            abort(400,'Kies of het seizoen actief wordt.')
        key=db().execute('INSERT INTO seasons(name,starts,ends) VALUES (?,?,?)',(name,starts,ends)).lastrowid
        if source:
            db().execute('INSERT INTO season_players SELECT ?,player_id,team_id,shirt_number,position,goal FROM season_players WHERE season_id=?',(key,source))
        if source and db().execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='season_staff'").fetchone():
            db().execute('INSERT INTO season_staff SELECT ?,staff_id,team_id FROM season_staff WHERE season_id=?',(key,source))
        if active:
            db().execute("UPDATE settings SET value=? WHERE key='active_season'",(str(key),))
        db().commit()
        return jsonify(ok=True,id=key)

    @app.post('/api/seasons/<int:key>')
    @protect
    def season_update(key):
        admin()
        old=db().execute('SELECT * FROM seasons WHERE id=?',(key,)).fetchone()
        if not old:
            abort(404,'Seizoen niet gevonden.')
        payload=request.get_json()
        active=int(db().execute("SELECT value FROM settings WHERE key='active_season'").fetchone()['value'])
        if 'archived' in payload:
            if type(payload['archived']) is not bool:
                abort(400,'Ongeldige archiefkeuze.')
            if payload['archived'] and key==active:
                abort(400,'Maak eerst een ander seizoen actief voordat je dit seizoen archiveert.')
            db().execute('UPDATE seasons SET archived=? WHERE id=?',(int(payload['archived']),key))
        if payload.get('active'):
            if old['archived']:
                abort(400,'Heropen het seizoen voordat je het actief maakt.')
            db().execute("UPDATE settings SET value=? WHERE key='active_season'",(str(key),))
        db().commit()
        return jsonify(ok=True)

    return context,summary
