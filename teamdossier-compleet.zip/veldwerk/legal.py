import os


def legal_context():
    return dict(
        provider=os.environ.get('TEAM_LEGAL_NAME','Teamdossier.nl'),
        address=os.environ.get('TEAM_LEGAL_ADDRESS','[Vul correspondentieadres in]'),
        email=os.environ.get('TEAM_PRIVACY_EMAIL','[Vul privacy-e-mailadres in]'),
        association='[Vul voetbalvereniging in]',
        base_domain=os.environ.get('TEAM_BASE_DOMAIN','teamdossier.nl'),
        subprocessors=os.environ.get('TEAM_SUBPROCESSORS','[Vul hosting-, e-mail-, betaal- en back-upleveranciers in]'),
        hosting_provider=os.environ.get('TEAM_HOSTING_PROVIDER','[Vul hostingleverancier in]'),
        hosting_location=os.environ.get('TEAM_HOSTING_LOCATION','[Vul land en datacenterregio in]'),
        backup_provider=os.environ.get('TEAM_BACKUP_PROVIDER','[Vul externe back-upleverancier in]'),
        backup_location=os.environ.get('TEAM_BACKUP_LOCATION','[Vul land van back-upopslag in]'),
        email_provider=os.environ.get('TEAM_EMAIL_PROVIDER','[Vul e-mailleverancier in of niet van toepassing]'),
        payment_provider=os.environ.get('TEAM_PAYMENT_PROVIDER','[Vul betaalprovider in of niet van toepassing]'),
        account_retention=os.environ.get('TEAM_ACCOUNT_RETENTION','30 dagen na beëindiging'),
        medical_retention=os.environ.get('TEAM_MEDICAL_RETENTION','[Vul bewaartermijn medische gegevens in]'),
        media_retention=os.environ.get('TEAM_MEDIA_RETENTION','[Vul bewaartermijn foto’s en video’s in]'),
        backup_retention=os.environ.get('TEAM_BACKUP_RETENTION','35 dagen'),
        version='Concept 1.0 · 9 november 2026')
