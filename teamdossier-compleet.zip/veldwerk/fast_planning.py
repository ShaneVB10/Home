"""Bulk operations keep normal permissions and never overwrite existing registrations."""
import json
import time
import uuid
from datetime import datetime,timedelta

from flask import abort,g,jsonify,request


def register_fast_planning(app,db,protect,staff,scoped_team,permitted,require,text):
    with app.app_context():
        if 'series_id' not in {r[1] for r in db().execute('PRAGMA table_info(trainings)')}:
            db().execute("ALTER TABLE trainings ADD COLUMN series_id TEXT NOT NULL DEFAULT ''")
        db().commit()

    def day(value):
        try:
            return datetime.strptime(str(value),'%Y-%m-%d').date()
        except ValueError:
            abort(400,'Kies een geldige datum.')

    def clock(value):
        try:
            return datetime.strptime(str(value),'%H:%M').strftime('%H:%M')
        except ValueError:
            abort(400,'Kies een geldige tijd.')

    def plan(payload):
        start,end=day(payload.get('from')),day(payload.get('until'))
        if end<start or (end-start).days>731:
            abort(400,'Kies een periode van maximaal twee jaar, met einddatum na begindatum.')
        schedules=payload.get('schedules')
        if not isinstance(schedules,list) or not 1<=len(schedules)<=20:
            abort(400,'Kies minimaal één en maximaal twintig teams.')
        exclusions=payload.get('exclude_dates',[])
        if not isinstance(exclusions,list) or len(exclusions)>200:
            abort(400,'Geef maximaal 200 uitzonderingsdatums op.')
        exclusions={day(d) for d in exclusions}
        title,notes=text(payload,'title'),text(payload,'notes',4000,False)
        seen,rows,excluded=set(),[],0
        for schedule in schedules:
            if not isinstance(schedule,dict):
                abort(400,'Ongeldig teamschema.')
            team=int(schedule.get('team_id',0))
            scoped_team(team)
            if team in seen:
                abort(400,'Kies ieder team eenmaal.')
            seen.add(team)
            weekdays=schedule.get('weekdays')
            if not isinstance(weekdays,list) or not weekdays or not all(type(d) is int and 0<=d<=6 for d in weekdays):
                abort(400,'Vink minimaal één geldige trainingsdag per gekozen team aan.')
            begin,finish=clock(schedule.get('start_time')),clock(schedule.get('end_time'))
            if finish<=begin:
                abort(400,'De eindtijd moet na de begintijd liggen.')
            location=text(schedule,'location',200,False)
            for offset in range((end-start).days+1):
                date=start+timedelta(days=offset)
                if date.weekday() not in weekdays:
                    continue
                if date in exclusions:
                    excluded+=1
                    continue
                rows.append(dict(team_id=team,starts=f'{date.isoformat()}T{begin}',ends=f'{date.isoformat()}T{finish}',title=title,notes=notes,location=location))
        if not rows or len(rows)>1000:
            abort(400,'Deze keuze levert geen trainingen of meer dan 1000 trainingen op. Pas de periode aan.')
        return rows,excluded

    def compare(rows,excluded):
        existing={(r['team_id'],r['starts']) for r in db().execute('SELECT team_id,starts FROM trainings WHERE season_id=?',(g.season_id,))}
        new=[r for r in rows if (r['team_id'],r['starts']) not in existing]
        counts={team:sum(r['team_id']==team for r in new) for team in {r['team_id'] for r in rows}}
        summary=dict(requested=len(rows),create_count=len(new),skipped_existing=len(rows)-len(new),excluded_count=excluded,
                     first=min(r['starts'] for r in rows),last=max(r['starts'] for r in rows),teams=[dict(team_id=t,count=c) for t,c in sorted(counts.items())])
        return new,summary

    @app.post('/api/trainings/series/preview')
    @protect
    def series_preview():
        staff('training')
        rows,excluded=plan(request.get_json())
        _,summary=compare(rows,excluded)
        return jsonify(summary)

    @app.post('/api/trainings/series')
    @protect
    def series_create():
        staff('training')
        rows,excluded=plan(request.get_json())
        db().execute('BEGIN IMMEDIATE')
        rows,summary=compare(rows,excluded)
        series=uuid.uuid4().hex
        ids=[]
        for row in rows:
            key=db().execute('INSERT INTO trainings(team_id,title,starts,ends,location,notes,cancelled,created,season_id,series_id) VALUES (?,?,?,?,?,?,0,?,?,?)',
                (row['team_id'],row['title'],row['starts'],row['ends'],row['location'],row['notes'],time.time(),g.season_id,series)).lastrowid
            db().execute('INSERT INTO attendance(training_id,player_id,updated) SELECT ?,player_id,? FROM season_players WHERE season_id=? AND team_id=?',(key,time.time(),g.season_id,row['team_id']))
            ids.append(key)
        db().commit()
        return jsonify(ok=True,series_id=series if ids else '',created_ids=ids,**summary)

    @app.post('/api/trainings/series/<series>/edit')
    @protect
    def series_edit(series):
        staff('training')
        payload=request.get_json()
        after=day(payload.get('from')).isoformat()
        teams=payload.get('team_ids')
        if not isinstance(teams,list) or not teams or not all(type(i) is int for i in teams):
            abort(400,'Kies de teams waarvoor je de reeks wilt aanpassen.')
        for team in teams:scoped_team(team)
        start,end=clock(payload.get('start_time')),clock(payload.get('end_time'))
        if end<=start:abort(400,'De eindtijd moet na de begintijd liggen.')
        cancelled=payload.get('cancelled',False)
        if type(cancelled) is not bool:abort(400,'Ongeldige status.')
        values=(text(payload,'title'),text(payload,'location',200,False),text(payload,'notes',4000,False),int(cancelled))
        db().execute('BEGIN IMMEDIATE')
        rows=[dict(r) for r in db().execute('SELECT * FROM trainings WHERE series_id=? AND season_id=? AND starts>=?',(series,g.season_id,after)) if r['team_id'] in teams]
        if not rows:abort(404,'Geen trainingen gevonden voor deze reeks en periode.')
        ids={r['id'] for r in rows}
        occupied={(r['team_id'],r['starts']) for r in db().execute('SELECT id,team_id,starts FROM trainings WHERE season_id=?',(g.season_id,)) if r['id'] not in ids}
        for row in rows:
            stamp=row['starts'][:10]+'T'+start
            if (row['team_id'],stamp) in occupied:abort(409,'Deze tijd botst met een andere training. Er is niets gewijzigd.')
            occupied.add((row['team_id'],stamp))
        for row in rows:
            db().execute('UPDATE trainings SET title=?,location=?,notes=?,cancelled=?,starts=?,ends=? WHERE id=?',(*values,row['starts'][:10]+'T'+start,row['starts'][:10]+'T'+end,row['id']))
        db().commit()
        return jsonify(ok=True,count=len(rows))

    @app.post('/api/attendance/bulk')
    @protect
    def attendance_bulk():
        staff('availability')
        payload=request.get_json()
        key=int(payload.get('training_id',0))
        training=db().execute('SELECT * FROM trainings WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not training:abort(404,'Training niet gevonden.')
        scoped_team(training['team_id'])
        if training['cancelled']:abort(400,'Deze training is geannuleerd.')
        action=payload.get('action')
        if action not in ('present_unmarked','undo'):abort(400,'Ongeldige groepsactie.')
        db().execute('BEGIN IMMEDIATE')
        rows={r['player_id']:dict(r) for r in db().execute('SELECT a.* FROM attendance a JOIN season_players m ON m.player_id=a.player_id WHERE a.training_id=? AND m.season_id=? AND m.team_id=?',(key,g.season_id,training['team_id']))}
        changes=[]
        if action=='present_unmarked':
            for pid,row in rows.items():
                if row['attendance']=='onbekend' and row['availability'] not in ('afgemeld','geblesseerd'):
                    stamp=max(time.time(),row['updated']+0.000001)
                    db().execute("UPDATE attendance SET attendance='aanwezig',updated=? WHERE training_id=? AND player_id=?",(stamp,key,pid))
                    changes.append(dict(player_id=pid,previous='onbekend',expected_updated=stamp))
        else:
            requested=payload.get('changes')
            if not isinstance(requested,list) or not 1<=len(requested)<=500:abort(400,'Ongeldige herstelactie.')
            seen=set()
            for change in requested:
                pid=int(change.get('player_id',0))
                if pid in seen or pid not in rows or change.get('previous')!='onbekend':abort(400,'Ongeldige herstelrij.')
                seen.add(pid)
                if rows[pid]['updated']!=change.get('expected_updated') or rows[pid]['attendance']!='aanwezig':
                    abort(409,'Een rij is inmiddels gewijzigd. Vernieuw het overzicht; er is niets ongedaan gemaakt.')
            for change in requested:
                pid=change['player_id'];stamp=max(time.time(),rows[pid]['updated']+0.000001)
                db().execute("UPDATE attendance SET attendance='onbekend',updated=? WHERE training_id=? AND player_id=?",(stamp,key,pid))
        db().commit()
        return jsonify(ok=True,count=len(changes) if action=='present_unmarked' else len(requested),changes=changes)
