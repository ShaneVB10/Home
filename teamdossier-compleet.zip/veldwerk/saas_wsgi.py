import os
from werkzeug.middleware.proxy_fix import ProxyFix
from saas import build_application

os.environ.setdefault('TEAM_ENFORCE_HTTPS','1')
application=build_application()
if os.environ.get('TEAM_TRUST_PROXY')=='1':
    application=ProxyFix(application,x_for=1,x_proto=1,x_host=1)

