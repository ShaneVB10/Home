"""Compact club-organisation workspace shared by nine related workflows."""
import time
from flask import abort,g,jsonify,request

KINDS=('task','message','academy','scouting','opponent','training_suggestion','player_report','parent','resource')

def register_club_suite(app,db,protect,require,permitted,team_allowed,text):
    with app.app_context():
        db().execute('''CREATE TABLE IF NOT EXISTS club_suite_items(id INTEGER PRIMARY KEY,kind TEXT NOT NULL,
          team_id INTEGER REFERENCES teams(id),player_id INTEGER REFERENCES players(id),title TEXT NOT NULL,body TEXT NOT NULL,
          due TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'open',created_by INTEGER NOT NULL REFERENCES users(id),
          created REAL NOT NULL,updated REAL NOT NULL,season_id INTEGER NOT NULL DEFAULT 1)''');db().commit()

    def allowed_team(team_id):return team_id is None or team_allowed(team_id)

    @app.post('/api/club-suite/items')
    @protect
    def save_item():
        require('training',True)
        if g.user['role']=='player':abort(403,'Alleen staf kan clubonderdelen beheren.')
        p=request.get_json();kind=str(p.get('kind',''))
        if kind not in KINDS:abort(400,'Kies een geldig onderdeel.')
        team_id=int(p['team_id']) if p.get('team_id') else None
        if not allowed_team(team_id):abort(403,'Geen toegang tot dit team.')
        player_id=int(p['player_id']) if p.get('player_id') else None
        if player_id:
            row=db().execute('SELECT team_id FROM season_players WHERE season_id=? AND player_id=?',(g.season_id,player_id)).fetchone()
            if not row or not allowed_team(row['team_id']) or team_id and row['team_id']!=team_id:abort(400,'Speler valt niet binnen het gekozen team.')
        status=str(p.get('status','open'))
        if status not in ('open','bezig','gereed','gearchiveerd'):abort(400,'Kies een geldige status.')
        values=(kind,team_id,player_id,text(p,'title'),text(p,'body',5000,False),text(p,'due',40,False),status,time.time())
        key=int(p.get('id') or 0)
        if key:
            old=db().execute('SELECT * FROM club_suite_items WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
            if not old or not allowed_team(old['team_id']):abort(404,'Onderdeel niet gevonden.')
            db().execute('UPDATE club_suite_items SET kind=?,team_id=?,player_id=?,title=?,body=?,due=?,status=?,updated=? WHERE id=?',(*values,key))
        else:key=db().execute('INSERT INTO club_suite_items(kind,team_id,player_id,title,body,due,status,created_by,created,updated,season_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)',(*values,g.user['id'],time.time(),time.time(),g.season_id)).lastrowid
        db().commit();return jsonify(ok=True,id=key)

    @app.post('/api/club-suite/items/<int:key>/delete')
    @protect
    def delete_item(key):
        require('training',True);row=db().execute('SELECT * FROM club_suite_items WHERE id=? AND season_id=?',(key,g.season_id)).fetchone()
        if not row or not allowed_team(row['team_id']):abort(404,'Onderdeel niet gevonden.')
        db().execute('DELETE FROM club_suite_items WHERE id=?',(key,));db().commit();return jsonify(ok=True)

    def summary():
        rows=[]
        if permitted('training'):
            for row in db().execute('SELECT * FROM club_suite_items WHERE season_id=? ORDER BY updated DESC',(g.season_id,)):
                if not allowed_team(row['team_id']):continue
                if g.user['role']=='player' and not (row['kind'] in ('task','message','parent') and row['player_id']==g.user['player_id']):continue
                rows.append(dict(row))
        return {'club_suite_items':rows}
    return summary
