"""Public product page and interest form shared by single-club and SaaS apps."""
import os,time
from flask import abort,redirect,render_template,request,url_for

FEATURES=(
 ('planning','Trainingsplanning en aanwezigheid'),('selections','Selecties en opstellingen'),
 ('development','Spelersontwikkeling en rapporten'),('exercises','Oefenstof en tekenbord'),
 ('video','Video en wedstrijdanalyse'),('messages','Berichten en helpdesk'),
 ('medical','Medische staf en blessures'),('scouting','Scouting en spelersvolgsysteem'),
 ('hjo','HJO en cluborganisatie'),('documents','Documenten en presentaties'),
 ('multi_team','Meerdere teams en seizoenen'),('branding','Eigen clubuiterlijk'))
DEFAULTS={
 'pilot':{'planning','selections','development','exercises','messages'},
 'trainer':{'planning','selections','development','exercises','video','documents'},
 'team':{'planning','selections','development','exercises','video','messages','medical','documents','branding'},
 'club':{key for key,_ in FEATURES}}

def register_business(app,db):
    with app.app_context():
        db().execute('''CREATE TABLE IF NOT EXISTS business_leads(id INTEGER PRIMARY KEY,created REAL NOT NULL,name TEXT NOT NULL,
          organisation TEXT NOT NULL,email TEXT NOT NULL,phone TEXT NOT NULL,package TEXT NOT NULL,message TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'nieuw')''');db().commit()
        db().execute('''CREATE TABLE IF NOT EXISTS package_features(package TEXT NOT NULL,feature TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,
          PRIMARY KEY(package,feature))''')
        for package,enabled in DEFAULTS.items():
            for feature,_ in FEATURES:db().execute('INSERT OR IGNORE INTO package_features(package,feature,enabled) VALUES (?,?,?)',(package,feature,int(feature in enabled)))
        db().commit()
    @app.get('/zakelijk')
    def business_page():
        prices={'pilot':os.environ.get('TEAM_PRICE_PILOT','Gratis · 30 dagen'),'trainer':os.environ.get('TEAM_PRICE_TRAINER','€ 12,50 p/m'),'team':os.environ.get('TEAM_PRICE_TEAM','€ 24,95 p/m'),'club':os.environ.get('TEAM_PRICE_CLUB','Op aanvraag')}
        rows=db().execute('SELECT package,feature,enabled FROM package_features').fetchall()
        enabled={(r['package'],r['feature']) for r in rows if r['enabled']}
        package_features={package:[label for key,label in FEATURES if (package,key) in enabled] for package in DEFAULTS}
        return render_template('business.html',prices=prices,package_features=package_features,sent=request.args.get('verstuurd')=='1')
    @app.post('/zakelijk/interesse')
    def business_interest():
        if request.form.get('website'):return redirect(url_for('business_page',verstuurd=1))
        values=[request.form.get(k,'').strip() for k in ('name','organisation','email','phone','package','message')]
        if not values[0] or not values[1] or '@' not in values[2] or values[4] not in ('Pilot','Trainer','Team','Club') or any(len(v)>2000 for v in values):abort(400,'Controleer het contactformulier.')
        db().execute('INSERT INTO business_leads(created,name,organisation,email,phone,package,message) VALUES (?,?,?,?,?,?,?)',(time.time(),*values));db().commit()
        if db().execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='mail_messages'").fetchone():
            now=time.time();db().execute('INSERT INTO mail_messages(direction,status,from_address,to_address,subject,body,created,updated) VALUES (?,?,?,?,?,?,?,?)',('notification','nieuw',values[2],'','Nieuwe pakketaanvraag · '+values[1],f'Naam: {values[0]}\nPakket: {values[4]}\nTelefoon: {values[3]}\n\n{values[5]}',now,now));db().commit()
        return redirect(url_for('business_page',verstuurd=1))
